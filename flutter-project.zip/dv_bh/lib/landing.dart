// landing.dart — Tr4sFight v8.0 SINGULARITY EDITION
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dv_theme.dart';
import 'bh_painter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  late AnimationController _entry, _pulse, _stars;
  late Animation<double> _fade, _pulseAnim;
  late Animation<Offset> _slide;
  int _phraseIdx = 0;
  String _typed = '';
  Timer? _typeTimer;
  final _phrases = ['SINGULARITY', 'EVENT HORIZON', 'BUG SENDER', 'VOID ENGINE', 'Tr4sFight v8'];

  @override
  void initState() {
    super.initState();
    _entry  = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..forward();
    _pulse  = AnimationController(vsync: this, duration: const Duration(milliseconds: 2500))..repeat(reverse: true);
    _stars  = AnimationController(vsync: this, duration: const Duration(seconds: 40))..repeat();
    _fade   = CurvedAnimation(parent: _entry, curve: Curves.easeOut);
    _slide  = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entry, curve: Curves.easeOutCubic));
    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(_pulse);
    _type();
  }

  void _type() {
    _typeTimer = Timer.periodic(const Duration(milliseconds: 65), (_) {
      final t = _phrases[_phraseIdx];
      if (_typed.length < t.length) {
        setState(() => _typed = t.substring(0, _typed.length + 1));
      } else {
        _typeTimer?.cancel();
        Future.delayed(const Duration(milliseconds: 2200), () {
          if (!mounted) return;
          setState(() { _typed = ''; _phraseIdx = (_phraseIdx + 1) % _phrases.length; });
          _type();
        });
      }
    });
  }

  @override
  void dispose() {
    _entry.dispose(); _pulse.dispose(); _stars.dispose();
    _typeTimer?.cancel();
    super.dispose();
  }

  void _open(String url) => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: DV.bg0,
      body: Stack(children: [
        // Deep space background
        Positioned.fill(child: AnimatedBuilder(animation: _stars,
          builder: (_, __) => CustomPaint(painter: _DeepSpacePainter(t: _stars.value)))),
        // Faint disk glow on background edges
        Positioned(top: -40, left: -40, child: AnimatedBuilder(animation: _pulseAnim,
          builder: (_, __) => Container(width: 220, height: 220, decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [
              DV.diskCore.withOpacity(0.06 + _pulseAnim.value * 0.04), Colors.transparent]))))),
        Positioned(bottom: -60, right: -60, child: AnimatedBuilder(animation: _pulseAnim,
          builder: (_, __) => Container(width: 280, height: 280, decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [
              DV.diskMid.withOpacity(0.05 + _pulseAnim.value * 0.03), Colors.transparent]))))),
        SafeArea(child: FadeTransition(opacity: _fade,
          child: SlideTransition(position: _slide,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(children: [
                _topBar(),
                _heroSection(w),
                _statsRow(),
                _featureGrid(),
                _ctaButtons(),
                _socialRow(),
                const SizedBox(height: 48),
              ]))))),
      ]),
    );
  }

  Widget _topBar() => Padding(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
    child: Row(children: [
      // Logo — tiny black hole
      AnimatedBuilder(animation: _pulseAnim, builder: (_, __) => Container(
        width: 48, height: 48,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.black,
          border: Border.all(color: DV.diskMid.withOpacity(0.65 + _pulseAnim.value * 0.35), width: 1.5),
          boxShadow: [
            BoxShadow(color: DV.diskMid.withOpacity(0.7), blurRadius: 22, spreadRadius: -4),
            BoxShadow(color: DV.diskOuter.withOpacity(0.3), blurRadius: 40, spreadRadius: -10),
          ]),
        child: const Icon(Icons.blur_circular_rounded, color: Colors.white, size: 26))),
      const SizedBox(width: 12),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        ShaderMask(shaderCallback: (b) => DV.diskGradient.createShader(b),
          child: const Text('Tr4sFight', style: TextStyle(color: Colors.white,
              fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 21, letterSpacing: 3))),
        Row(children: [
          Container(width: 4, height: 4, decoration: BoxDecoration(shape: BoxShape.circle,
            color: DV.jetBlue, boxShadow: [BoxShadow(color: DV.jetBlue.withOpacity(0.9), blurRadius: 5)])),
          const SizedBox(width: 5),
          const Text('SINGULARITY v8.0', style: TextStyle(color: DV.textHint, fontSize: 8, letterSpacing: 2)),
        ]),
      ]),
      const Spacer(),
      AnimatedBuilder(animation: _pulseAnim, builder: (_, __) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: DV.success.withOpacity(0.05),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: DV.success.withOpacity(0.18 + _pulseAnim.value * 0.12))),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle,
            color: DV.success, boxShadow: [BoxShadow(color: DV.success.withOpacity(0.9), blurRadius: 8, spreadRadius: 1)])),
          const SizedBox(width: 7),
          const Text('LIVE', style: TextStyle(color: DV.success, fontSize: 9,
              fontWeight: FontWeight.w800, letterSpacing: 2.5, fontFamily: 'Orbitron')),
        ]))),
    ]),
  );

  Widget _heroSection(double w) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
    child: Container(
      width: double.infinity, height: 340,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        color: Colors.black,
        border: Border.all(color: DV.diskMid.withOpacity(0.22), width: 1),
        boxShadow: [
          BoxShadow(color: DV.diskCore.withOpacity(0.35), blurRadius: 55, spreadRadius: -5, offset: const Offset(0, 12)),
          BoxShadow(color: DV.jetBlue.withOpacity(0.08), blurRadius: 70),
        ]),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(27),
        child: Stack(children: [
          // Black hole — full center
          Positioned.fill(child: BlackHoleWidget(size: 340, scale: 1.1)),
          // Top faint image blend
          Positioned.fill(child: Stack(children: [
            Image.asset('assets/images/reze.png', fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox()),
            Container(decoration: BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Colors.black.withOpacity(0.6), Colors.black.withOpacity(0.92)]))),
          ])),
          // BH re-drawn on top of image
          Positioned.fill(child: BlackHoleWidget(size: 340, scale: 1.1)),
          // Bottom text overlay
          Positioned(bottom: 0, left: 0, right: 0, child: Container(
            padding: const EdgeInsets.fromLTRB(22, 30, 22, 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter,
                colors: [Colors.black, Colors.black.withOpacity(0.7), Colors.transparent])),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // HUD label
              Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.8),
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: DV.diskMid.withOpacity(0.55))),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Container(width: 5, height: 5, decoration: BoxDecoration(shape: BoxShape.circle,
                      color: DV.diskMid, boxShadow: [BoxShadow(color: DV.diskMid, blurRadius: 6)])),
                    const SizedBox(width: 7),
                    const Text('M87★ MASS: 6.5×10⁹ M☉', style: TextStyle(
                      color: DV.textGlow, fontSize: 8, letterSpacing: 1.8, fontFamily: 'Orbitron')),
                  ])),
                const Spacer(),
                AnimatedBuilder(animation: _pulseAnim, builder: (_, __) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: DV.jetBlue.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: DV.jetBlue.withOpacity(0.3 + _pulseAnim.value * 0.2))),
                  child: const Text('JET ↑↓', style: TextStyle(color: DV.jetBlue,
                      fontSize: 8, letterSpacing: 2, fontFamily: 'Orbitron')))),
              ]),
              const SizedBox(height: 10),
              // Typewriter
              Row(children: [
                Text(_typed, style: const TextStyle(color: DV.textPrimary, fontSize: 22,
                    fontWeight: FontWeight.w900, fontFamily: 'Orbitron', letterSpacing: 1.5)),
                AnimatedBuilder(animation: _pulseAnim, builder: (_, __) =>
                  Opacity(opacity: _pulseAnim.value,
                    child: ShaderMask(shaderCallback: (b) => DV.diskGradient.createShader(b),
                      child: const Text('_', style: TextStyle(color: Colors.white,
                          fontSize: 22, fontFamily: 'Orbitron'))))),
              ]),
              Text('ESCAPE VELOCITY: c // GRAVITY: ∞',
                style: TextStyle(color: DV.textSecondary.withOpacity(0.55), fontSize: 9, letterSpacing: 1.2)),
            ])),
          ),
        ]),
      ),
    ),
  );

  Widget _statsRow() => Padding(
    padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
    child: Row(children: [
      _stat('1K+', 'USERS', DV.diskMid, Icons.people_rounded),
      const SizedBox(width: 10),
      _stat('22', 'MODULES', DV.jetBlue, Icons.terminal_rounded),
      const SizedBox(width: 10),
      _stat('v8.0', 'HORIZON', DV.lensViolet, Icons.blur_circular_rounded),
    ]),
  );

  Widget _stat(String val, String label, Color color, IconData icon) => Expanded(child: Container(
    padding: const EdgeInsets.symmetric(vertical: 14),
    decoration: BoxDecoration(
      color: Colors.black,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: color.withOpacity(0.22)),
      boxShadow: [BoxShadow(color: color.withOpacity(0.10), blurRadius: 16)]),
    child: Column(children: [
      Icon(icon, color: color, size: 18),
      const SizedBox(height: 6),
      Text(val, style: TextStyle(color: color, fontSize: 15,
          fontWeight: FontWeight.w900, fontFamily: 'Orbitron')),
      Text(label, style: const TextStyle(color: DV.textHint, fontSize: 8, letterSpacing: 1.5)),
    ])));

  Widget _featureGrid() {
    final List<_FeatItem> items = <_FeatItem>[
      _FeatItem(Icons.bug_report_rounded,     'Bug Sender',   'WA Crasher',    DV.diskMid),
      _FeatItem(Icons.bolt_rounded,           'DDoS Panel',   'Stress Test',   DV.radHot),
      _FeatItem(Icons.manage_search_rounded,  'OSINT',        'NIK & Domain',  DV.jetBlue),
      _FeatItem(Icons.electric_bolt_rounded,  'Zyhrx',        'Blast Engine',  DV.lensViolet),
      _FeatItem(Icons.music_note_rounded,     'Spotify',      'Music Player',  DV.success),
      _FeatItem(Icons.sports_esports_rounded, 'Games',        'Mini Games',    DV.diskGold),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 3, height: 18, decoration: BoxDecoration(
            gradient: DV.diskGradient, borderRadius: BorderRadius.circular(2),
            boxShadow: [BoxShadow(color: DV.diskMid.withOpacity(0.7), blurRadius: 8)])),
          const SizedBox(width: 10),
          ShaderMask(shaderCallback: (b) => DV.diskGradient.createShader(b),
            child: const Text('CLASSIFIED MODULES', style: TextStyle(color: Colors.white,
                fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 2.5, fontFamily: 'Orbitron'))),
        ]),
        const SizedBox(height: 14),
        GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.90,
          children: items.map<Widget>((e) => _tile(e.icon, e.title, e.sub, e.color)).toList()),
      ]),
    );
  }

  Widget _tile(IconData icon, String title, String sub, Color color) => Container(
    decoration: BoxDecoration(
      color: Colors.black,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: color.withOpacity(0.25)),
      boxShadow: [BoxShadow(color: color.withOpacity(0.12), blurRadius: 16)]),
    child: Stack(children: [
      Positioned(bottom: -8, right: -8, child: Container(width: 56, height: 56,
        decoration: BoxDecoration(shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color.withOpacity(0.18), Colors.transparent])))),
      Padding(padding: const EdgeInsets.all(14), child: Column(
        mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(width: 42, height: 42,
            decoration: BoxDecoration(color: color.withOpacity(0.10),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withOpacity(0.4)),
              boxShadow: [BoxShadow(color: color.withOpacity(0.35), blurRadius: 10)]),
            child: Icon(icon, color: color, size: 20)),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(color: DV.textPrimary, fontSize: 11, fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(sub, style: TextStyle(color: color.withOpacity(0.65), fontSize: 9)),
        ])),
    ]));

  Widget _ctaButtons() => Padding(
    padding: const EdgeInsets.fromLTRB(20, 26, 20, 0),
    child: Column(children: [
      // Main CTA — accretion disk fire
      GestureDetector(
        onTap: () => Navigator.pushNamed(context, '/login'),
        child: AnimatedBuilder(animation: _pulseAnim, builder: (_, __) => Container(
          height: 64,
          decoration: BoxDecoration(
            gradient: DV.diskGradient,
            borderRadius: BorderRadius.circular(22),
            boxShadow: [
              BoxShadow(color: DV.diskCore.withOpacity(0.55 + _pulseAnim.value * 0.20),
                blurRadius: 35 + _pulseAnim.value * 14, offset: const Offset(0, 10)),
              BoxShadow(color: DV.diskOuter.withOpacity(0.25), blurRadius: 55),
            ]),
          child: const Center(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.blur_circular_rounded, color: Colors.white, size: 26),
            SizedBox(width: 12),
            Text('MASUK KE SINGULARITY', style: TextStyle(color: Colors.white,
                fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 2, fontFamily: 'Orbitron')),
          ])))),
      ),
      const SizedBox(height: 12),
      // Secondary — jet blue outline
      GestureDetector(
        onTap: () => _open('https://t.me/InfoChDarkness/292'),
        child: Container(
          height: 54,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22), color: Colors.black,
            border: Border.all(color: DV.jetBlue.withOpacity(0.45), width: 1.5),
            boxShadow: [BoxShadow(color: DV.jetBlue.withOpacity(0.12), blurRadius: 18)]),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.shopping_cart_outlined, color: DV.jetBlue, size: 20),
            const SizedBox(width: 10),
            ShaderMask(shaderCallback: (b) => DV.jetGradient.createShader(b),
              child: const Text('BELI AKSES', style: TextStyle(color: Colors.white,
                  fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2.5, fontFamily: 'Orbitron'))),
          ])),
      ),
    ]),
  );

  Widget _socialRow() => Padding(
    padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
    child: Row(children: [
      Expanded(child: _social(FontAwesomeIcons.telegram, 'Telegram', const Color(0xFF229ED9), 'https://t.me/InfoChDarkness')),
      const SizedBox(width: 12),
      Expanded(child: _social(FontAwesomeIcons.whatsapp, 'WhatsApp', const Color(0xFF25D366), 'https://wa.me/6283165770011')),
    ]),
  );

  Widget _social(IconData icon, String label, Color color, String url) => GestureDetector(
    onTap: () => _open(url),
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 15),
      decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.22))),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        FaIcon(icon, color: color, size: 15),
        const SizedBox(width: 8),
        Text(label, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w600)),
      ])));
}

class _FeatItem {
  final IconData icon; final String title, sub; final Color color;
  const _FeatItem(this.icon, this.title, this.sub, this.color);
}

class _DeepSpacePainter extends CustomPainter {
  final double t;
  _DeepSpacePainter({required this.t});
  @override
  void paint(Canvas canvas, Size size) {
    final rng = math.Random(77);
    final p = Paint()..style = PaintingStyle.fill;
    for (int i = 0; i < 160; i++) {
      final x = rng.nextDouble() * size.width;
      final y = rng.nextDouble() * size.height;
      final sz = rng.nextDouble() * 1.3;
      final tw = (math.sin(t * math.pi * 2 * 5 + i * 1.7) * 0.5 + 0.5);
      final bright = 0.04 + tw * 0.22;
      final isBlue = i % 9 == 0;
      final isOrange = i % 13 == 0;
      p.color = (isBlue ? DV.jetBlue : isOrange ? DV.diskOuter : Colors.white).withOpacity(bright);
      canvas.drawCircle(Offset(x, y), sz, p);
    }
  }
  @override bool shouldRepaint(_DeepSpacePainter o) => o.t != t;
}
