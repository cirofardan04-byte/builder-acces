// dashboard_page.dart — Tr4sFight v8.0 SINGULARITY
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as wsStatus;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dv_theme.dart';
import 'bh_painter.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'zyhrx_paranel.dart';
import 'zyhrx_controller.dart';

class DashboardPage extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;
  const DashboardPage({super.key,
    required this.username, required this.password, required this.role,
    required this.expiredDate, required this.listBug, required this.listDoos,
    required this.sessionKey, required this.news});
  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with TickerProviderStateMixin {
  late AnimationController _fadeCtrl, _pulseCtrl, _scanCtrl;
  late Animation<double> _fadeAnim, _pulseAnim;
  WebSocketChannel? _channel;

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  String androidId = 'unknown';
  File? _profileImage;
  VideoPlayerController? _bannerCtrl;
  int _navIdx = 0;
  Widget _body = const _LoadingBody();
  int onlineUsers = 0, activeConns = 0;
  bool _wsConnected = false;
  int _newsPage = 0;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey; username = widget.username;
    password    = widget.password;  role     = widget.role;
    expiredDate = widget.expiredDate; listBug = widget.listBug;
    listDoos    = widget.listDoos;   newsList = widget.news;

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 350));
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))..repeat(reverse: true);
    _scanCtrl  = AnimationController(vsync: this, duration: const Duration(seconds: 5))..repeat();

    _fadeAnim  = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeIn);
    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(_pulseCtrl);
    _fadeCtrl.forward();

    _body = _homeDash();
    _initDevice();
    _loadProfile();
    _initBanner();
  }

  Future<void> _loadProfile() async {
    final p = await SharedPreferences.getInstance();
    final path = p.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) setState(() => _profileImage = File(path));
  }

  void _initBanner() {
    _bannerCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {}); _bannerCtrl?.setLooping(true); _bannerCtrl?.setVolume(0); _bannerCtrl?.play();
      }).catchError((_) {});
  }

  Future<void> _initDevice() async {
    try { final d = await DeviceInfoPlugin().androidInfo; androidId = d.id; }
    catch (_) { androidId = 'unknown'; }
    _connectWS();
  }

  void _connectWS() {
    try {
      _channel = WebSocketChannel.connect(Uri.parse('wss://ws-rezacloundlegal.sistems.tech'));
      _channel!.sink.add(jsonEncode({'type': 'validate', 'key': sessionKey, 'androidId': androidId}));
      _channel!.sink.add(jsonEncode({'type': 'stats'}));
      _channel!.stream.listen((event) {
        final d = jsonDecode(event as String);
        if (d['type'] == 'myInfo' && d['valid'] == false) {
          _kickSession(d['reason'] == 'androidIdMismatch' ? 'Akun login di perangkat lain.' : 'Key tidak valid.');
        }
        if (d['type'] == 'stats' && mounted) setState(() {
          onlineUsers = d['onlineUsers'] ?? 0; activeConns = d['activeConnections'] ?? 0; _wsConnected = true;
        });
      }, onError: (_) { if (mounted) setState(() => _wsConnected = false); });
    } catch (_) { if (mounted) setState(() => _wsConnected = false); }
  }

  void _kickSession(String msg) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final p = await SharedPreferences.getInstance(); await p.clear();
    if (!mounted) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
      backgroundColor: DV.bg2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: DV.diskMid.withOpacity(0.45))),
      title: const Text('⚠️ Session Terminated', style: TextStyle(color: DV.textPrimary, fontWeight: FontWeight.bold)),
      content: Text(msg, style: const TextStyle(color: DV.textSecondary)),
      actions: [TextButton(onPressed: () => Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
        child: const Text('OK', style: TextStyle(color: DV.diskMid)))],
    ));
  }

  void _go(Widget page) => setState(() { _fadeCtrl.reset(); _fadeCtrl.forward(); _body = page; _navIdx = -1; });

  void _switchTab(int i) => setState(() {
    _navIdx = i; _fadeCtrl.reset(); _fadeCtrl.forward();
    _body = switch (i) {
      0 => _homeDash(),
      1 => HomePage(username: username, password: password, listBug: listBug, role: role, expiredDate: expiredDate, sessionKey: sessionKey),
      2 => InfoPage(sessionKey: sessionKey),
      3 => ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos),
      _ => _homeDash(),
    };
  });

  void _openUrl(String url) => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  @override
  void dispose() {
    try { _channel?.sink.close(wsStatus.goingAway); } catch (_) {}
    _fadeCtrl.dispose(); _pulseCtrl.dispose(); _scanCtrl.dispose();
    _bannerCtrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: DV.bg0,
    body: Stack(children: [
      Container(color: DV.bg0),
      // Scan line
      AnimatedBuilder(animation: _scanCtrl, builder: (_, __) => Positioned(
        top: MediaQuery.of(context).size.height * _scanCtrl.value, left: 0, right: 0,
        child: Container(height: 1, decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.transparent, DV.diskMid.withOpacity(0.10),
            DV.jetBlue.withOpacity(0.06), Colors.transparent]))))),
      Column(children: [
        _topBar(),
        Expanded(child: FadeTransition(opacity: _fadeAnim, child: _body)),
      ]),
      Positioned(bottom: 0, left: 0, right: 0, child: _bottomNav()),
    ]),
    drawer: _drawer(),
  );

  Widget _topBar() => SafeArea(bottom: false, child: Container(
    padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
    decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.92),
      border: Border(bottom: BorderSide(color: DV.diskMid.withOpacity(0.14)))),
    child: ClipRect(child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 18, sigmaY: 18),
      child: Row(children: [
        Builder(builder: (ctx) => GestureDetector(
          onTap: () => Scaffold.of(ctx).openDrawer(),
          child: AnimatedBuilder(animation: _pulseAnim, builder: (_, __) => Container(
            width: 40, height: 40,
            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.black,
              border: Border.all(color: DV.diskMid.withOpacity(0.55 + _pulseAnim.value * 0.35), width: 1.5),
              boxShadow: [BoxShadow(color: DV.diskMid.withOpacity(0.45), blurRadius: 14)]),
            child: _profileImage != null
              ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover))
              : const Icon(FontAwesomeIcons.userAstronaut, color: Colors.white, size: 16))))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            ShaderMask(shaderCallback: (b) => DV.diskGradient.createShader(b),
              child: Text(username, style: const TextStyle(color: Colors.white,
                  fontWeight: FontWeight.w800, fontSize: 14, fontFamily: 'Orbitron'))),
            const SizedBox(width: 8),
            _roleBadge(),
          ]),
          Row(children: [
            Icon(Icons.schedule_rounded, size: 10, color: DV.textHint),
            const SizedBox(width: 3),
            Text('EXP: $expiredDate', style: const TextStyle(color: DV.textHint, fontSize: 9)),
          ]),
        ])),
        // WS status
        AnimatedBuilder(animation: _pulseAnim, builder: (_, __) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: (_wsConnected ? DV.success : DV.error).withOpacity(0.06),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: (_wsConnected ? DV.success : DV.error).withOpacity(0.22))),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 5, height: 5, decoration: BoxDecoration(
              shape: BoxShape.circle, color: _wsConnected ? DV.success : DV.error,
              boxShadow: [BoxShadow(color: (_wsConnected ? DV.success : DV.error).withOpacity(0.8), blurRadius: 6)])),
            const SizedBox(width: 5),
            Text('$onlineUsers', style: TextStyle(
              color: _wsConnected ? DV.success : DV.error, fontSize: 11, fontWeight: FontWeight.w700)),
          ]))),
        const SizedBox(width: 4),
        _iconBtn(Icons.headset_mic_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => ContactPage()))),
        _iconBtn(Icons.person_outline_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(
          username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey)))),
      ])))));

  Widget _iconBtn(IconData icon, VoidCallback onTap) => GestureDetector(onTap: onTap,
    child: Container(width: 36, height: 36, margin: const EdgeInsets.only(left: 4),
      decoration: BoxDecoration(color: DV.glassCard, borderRadius: BorderRadius.circular(10),
        border: Border.all(color: DV.glassBorder)),
      child: Icon(icon, color: DV.textSecondary, size: 18)));

  Widget _roleBadge() {
    final c = {'owner': DV.success, 'admin': DV.diskMid, 'reseller': DV.jetBlue, 'member': DV.textSecondary}[role.toLowerCase()] ?? DV.textSecondary;
    return Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(color: c.withOpacity(0.10), borderRadius: BorderRadius.circular(5),
        border: Border.all(color: c.withOpacity(0.4))),
      child: Text(role.toUpperCase(), style: TextStyle(color: c, fontSize: 7,
          fontWeight: FontWeight.w900, letterSpacing: 1.2, fontFamily: 'Orbitron')));
  }

  // ── HOME DASHBOARD ──────────────────────────────────────────────────────────
  Widget _homeDash() => SingleChildScrollView(
    physics: const BouncingScrollPhysics(),
    padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Black hole mini panel
      _bhPanel(),
      const SizedBox(height: 20),
      _sHead('📡', 'SIGNAL FEED', DV.jetBlue),
      const SizedBox(height: 12),
      _newsCarousel(),
      const SizedBox(height: 22),
      _sHead('⚡', 'QUICK ACCESS', DV.diskMid),
      const SizedBox(height: 12),
      _actionGrid(),
      const SizedBox(height: 22),
      if (role == 'reseller' || role == 'admin' || role == 'owner') ...[
        _sHead('🔑', 'CONTROL PANEL', DV.success),
        const SizedBox(height: 12),
        _specialPanel(),
        const SizedBox(height: 22),
      ],
      _sHead('🧩', 'ACTIVE MODULES', DV.radHot),
      const SizedBox(height: 12),
      _moduleList(),
    ]),
  );

  Widget _bhPanel() => Container(
    height: 200,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(24),
      color: Colors.black,
      border: Border.all(color: DV.diskMid.withOpacity(0.20), width: 1),
      boxShadow: [
        BoxShadow(color: DV.diskCore.withOpacity(0.30), blurRadius: 40, spreadRadius: -5, offset: const Offset(0, 8)),
        BoxShadow(color: DV.jetBlue.withOpacity(0.06), blurRadius: 50),
      ]),
    child: ClipRRect(borderRadius: BorderRadius.circular(23), child: Stack(children: [
      // Black hole visual
      Positioned.fill(child: const BlackHoleWidget(size: 200, scale: 0.65)),
      // Stats overlay — right side
      Positioned(right: 0, top: 0, bottom: 0, width: 160, child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.centerRight, end: Alignment.centerLeft,
            colors: [Colors.black.withOpacity(0.90), Colors.black.withOpacity(0.50), Colors.transparent])),
        padding: const EdgeInsets.all(18),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
          _inlineStat('$onlineUsers', 'ONLINE', DV.diskMid),
          const SizedBox(height: 12),
          _inlineStat('$activeConns', 'CONNS', DV.jetBlue),
          const SizedBox(height: 12),
          _inlineStat(_daysLeft(), 'DAYS', DV.success),
        ]))),
      // Bottom left — user greeting
      Positioned(left: 16, bottom: 16, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        ShaderMask(shaderCallback: (b) => DV.diskGradient.createShader(b),
          child: Text(username, style: const TextStyle(color: Colors.white,
              fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1))),
        Text('SINGULARITY ACTIVE', style: TextStyle(color: DV.textSecondary.withOpacity(0.6),
            fontSize: 8, letterSpacing: 2)),
      ])),
    ])),
  );

  Widget _inlineStat(String val, String label, Color color) => Column(
    crossAxisAlignment: CrossAxisAlignment.end, children: [
    Text(val, style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.w900, fontFamily: 'Orbitron')),
    Text(label, style: const TextStyle(color: DV.textHint, fontSize: 7, letterSpacing: 2)),
  ]);

  Widget _sHead(String emoji, String title, Color color) => Row(children: [
    Container(width: 3, height: 16, decoration: BoxDecoration(color: color,
      borderRadius: BorderRadius.circular(2),
      boxShadow: [BoxShadow(color: color.withOpacity(0.6), blurRadius: 8)])),
    const SizedBox(width: 10),
    Text(emoji, style: const TextStyle(fontSize: 13)),
    const SizedBox(width: 7),
    ShaderMask(shaderCallback: (b) => LinearGradient(
      colors: [color, color.withOpacity(0.7)]).createShader(b),
      child: Text(title, style: const TextStyle(color: Colors.white,
          fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 3, fontFamily: 'Orbitron'))),
  ]);

  Widget _newsCarousel() {
    if (newsList.isEmpty) return Container(height: 120,
      decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(18),
        border: Border.all(color: DV.glassBorder)),
      child: const Center(child: Text('No feed available', style: TextStyle(color: DV.textHint))));
    return Column(children: [
      SizedBox(height: 175, child: PageView.builder(
        controller: PageController(viewportFraction: 0.92),
        itemCount: newsList.length,
        onPageChanged: (i) => setState(() => _newsPage = i),
        itemBuilder: (_, i) {
          final item = newsList[i];
          return Padding(padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
                border: Border.all(color: DV.diskMid.withOpacity(0.30)),
                boxShadow: [BoxShadow(color: DV.diskCore.withOpacity(0.18), blurRadius: 18)]),
              child: ClipRRect(borderRadius: BorderRadius.circular(19),
                child: Stack(fit: StackFit.expand, children: [
                  if (item['image'] != null && (item['image'] as String).isNotEmpty)
                    _NewsMedia(url: item['image'] as String),
                  DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(
                    begin: Alignment.bottomCenter, end: Alignment.topCenter,
                    colors: [Colors.black.withOpacity(0.96), Colors.transparent]))),
                  Positioned(bottom: 14, left: 16, right: 16, child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                    Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: DV.diskMid.withOpacity(0.4))),
                      child: const Text(':: FEED', style: TextStyle(color: DV.textGlow, fontSize: 8,
                          letterSpacing: 2.5, fontFamily: 'Orbitron'))),
                    const SizedBox(height: 5),
                    Text(item['title'] ?? '', style: const TextStyle(color: DV.textPrimary, fontSize: 13,
                        fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                    Text(item['desc'] ?? '', style: const TextStyle(color: DV.textSecondary, fontSize: 9),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  ])),
                ]))));
        })),
      if (newsList.length > 1) ...[
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(
          newsList.length > 5 ? 5 : newsList.length, (i) =>
          AnimatedContainer(duration: const Duration(milliseconds: 300),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: _newsPage == i ? 20 : 5, height: 3,
            decoration: BoxDecoration(
              color: _newsPage == i ? DV.diskMid : DV.textHint.withOpacity(0.3),
              borderRadius: BorderRadius.circular(2),
              boxShadow: _newsPage == i ? [BoxShadow(color: DV.diskMid.withOpacity(0.6), blurRadius: 6)] : [])))),
      ],
    ]);
  }

  Widget _actionGrid() {
    final List<Widget> tiles = <Widget>[];
    final List<_Ac> items = <_Ac>[
      _Ac(Icons.local_fire_department_rounded, 'ATTACK',  DV.diskCore,   true,  () => _switchTab(1)),
      _Ac(Icons.terminal_rounded,             'TOOLS',   DV.jetBlue,    false, () => _switchTab(3)),
      _Ac(Icons.electric_bolt_rounded,        'PARANEL', DV.diskMid,    false, () => Navigator.push(context, MaterialPageRoute(builder: (_) => ZyhrxParanelPage(sessionKey: sessionKey)))),
      _Ac(Icons.settings_remote_rounded,      'CTRL',    DV.lensViolet, false, () => Navigator.push(context, MaterialPageRoute(builder: (_) => ZyhrxControllerPage(sessionKey: sessionKey)))),
      _Ac(FontAwesomeIcons.whatsapp,          'BUG',     DV.success,    false, () => Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role)))),
      _Ac(Icons.campaign_rounded,             'TG',      DV.jetCore,    false, () => _openUrl('https://t.me/InfoChDarkness')),
    ];
    for (final _Ac a in items) {
      tiles.add(GestureDetector(
        onTap: a.onTap,
        child: Container(
          decoration: BoxDecoration(
            gradient: a.primary ? DV.diskGradient : null,
            color: a.primary ? null : Colors.black,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: a.primary ? Colors.transparent : a.color.withOpacity(0.28)),
            boxShadow: a.primary ? <BoxShadow>[
              BoxShadow(color: DV.diskCore.withOpacity(0.55), blurRadius: 22),
              BoxShadow(color: DV.diskOuter.withOpacity(0.25), blurRadius: 40),
            ] : <BoxShadow>[BoxShadow(color: a.color.withOpacity(0.06), blurRadius: 12)]),
          child: Stack(children: <Widget>[
            if (!a.primary) Positioned(top: -5, right: -5, child: Container(width: 40, height: 40,
              decoration: BoxDecoration(shape: BoxShape.circle,
                gradient: RadialGradient(colors: <Color>[a.color.withOpacity(0.14), Colors.transparent])))),
            Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
              Icon(a.icon, color: a.primary ? Colors.white : a.color, size: 22),
              const SizedBox(height: 6),
              Text(a.label, style: TextStyle(
                color: a.primary ? Colors.white : DV.textPrimary,
                fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 0.8, fontFamily: 'Orbitron'),
                textAlign: TextAlign.center),
            ]),
          ]))));
    }
    return GridView.count(
      crossAxisCount: 3, shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.05,
      children: tiles);
  }

  Widget _specialPanel() => Column(children: [
    if (role == 'reseller') _specBtn(Icons.storefront_rounded,          'SELLER PANEL', DV.success,    () => _go(SellerPage(keyToken: sessionKey))),
    if (role == 'admin')    _specBtn(Icons.admin_panel_settings_rounded, 'ADMIN PANEL',  DV.diskMid,    () => _go(AdminPage(sessionKey: sessionKey))),
    if (role == 'owner')    _specBtn(Icons.workspace_premium_rounded,    'OWNER PANEL',  DV.diskGold,   () => _go(OwnerPage(sessionKey: sessionKey, username: username))),
  ]);

  Widget _specBtn(IconData icon, String label, Color color, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(margin: const EdgeInsets.only(bottom: 10), height: 56,
      decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.40)),
        boxShadow: [BoxShadow(color: color.withOpacity(0.10), blurRadius: 18)]),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: color, size: 20), const SizedBox(width: 10),
        Text(label, style: TextStyle(color: color, fontSize: 13,
            fontWeight: FontWeight.w800, letterSpacing: 2, fontFamily: 'Orbitron')),
        const SizedBox(width: 10),
        Icon(Icons.arrow_forward_ios_rounded, color: color.withOpacity(0.5), size: 12),
      ])));

  Widget _moduleList() {
    final List<_Mod> mods = <_Mod>[
      _Mod(Icons.login_rounded,           DV.success,    'Login Active',      'Session authenticated'),
      _Mod(Icons.bug_report_rounded,      DV.diskMid,    'Bug Sender',        'WA crasher online'),
      _Mod(Icons.bolt_rounded,            DV.radHot,     'DDoS Panel',        'Stress test ready'),
      _Mod(Icons.electric_bolt_rounded,   DV.jetBlue,    'Zyhrx Paranel',     'Blast engine ready'),
      _Mod(Icons.settings_remote_rounded, DV.lensViolet, 'Zyhrx Controller',  'Session mgmt active'),
      _Mod(Icons.developer_mode_rounded,  DV.jetCore,    'RAT Control',       'Remote access ready'),
      _Mod(Icons.manage_search_rounded,   DV.diskOuter,  'OSINT Tools',       'NIK, domain, IP'),
      _Mod(Icons.wifi_off_rounded,        DV.warning,    'Wifi Tools',        'Network scanner'),
      _Mod(Icons.menu_book_rounded,       DV.success,    'Al-Qur\'an',        'Quran & translation'),
      _Mod(Icons.music_note_rounded,      DV.diskGold,   'Spotify Player',    'Music stream'),
      _Mod(Icons.sports_esports_rounded,  DV.jetSoft,    'Game Zone',         '3 games available'),
      _Mod(Icons.web_rounded,             DV.diskOuter,  'Create Website',    'Deploy to Vercel'),
    ];
    final List<Widget> rows = <Widget>[];
    for (int i = 0; i < mods.length; i++) {
      final _Mod m = mods[i];
      rows.add(Column(children: <Widget>[
        Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(children: <Widget>[
            Container(width: 38, height: 38,
              decoration: BoxDecoration(color: m.color.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: m.color.withOpacity(0.28)),
                boxShadow: i == 0 ? <BoxShadow>[BoxShadow(color: m.color.withOpacity(0.18), blurRadius: 10)] : <BoxShadow>[]),
              child: Icon(m.icon, color: m.color, size: 17)),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              Text(m.title, style: const TextStyle(color: DV.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
              Text(m.sub, style: const TextStyle(color: DV.textSecondary, fontSize: 9, height: 1.4), overflow: TextOverflow.ellipsis),
            ])),
            if (i == 0) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: DV.success.withOpacity(0.08),
                borderRadius: BorderRadius.circular(6), border: Border.all(color: DV.success.withOpacity(0.35))),
              child: Row(mainAxisSize: MainAxisSize.min, children: <Widget>[
                Container(width: 4, height: 4, decoration: BoxDecoration(shape: BoxShape.circle,
                  color: DV.success, boxShadow: <BoxShadow>[BoxShadow(color: DV.success.withOpacity(0.8), blurRadius: 4)])),
                const SizedBox(width: 4),
                const Text('ONLINE', style: TextStyle(color: DV.success, fontSize: 8,
                    fontWeight: FontWeight.w800, letterSpacing: 1, fontFamily: 'Orbitron')),
              ])),
          ])),
        if (i < mods.length - 1) Container(height: 1, margin: const EdgeInsets.only(left: 68),
          decoration: BoxDecoration(gradient: LinearGradient(colors: <Color>[
            DV.diskMid.withOpacity(0.18), DV.glassBorder, Colors.transparent]))),
      ]));
    }
    return Container(
      decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(20),
        border: Border.all(color: DV.glassBorder)),
      child: Column(children: rows));
  }
  String _daysLeft() {
    try {
      final p = expiredDate.split('-');
      if (p.length == 3) {
        final exp = DateTime(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]));
        final d = exp.difference(DateTime.now()).inDays;
        return d <= 0 ? 'EXP' : '${d}d';
      }
    } catch (_) {}
    return '--';
  }

  Widget _drawer() => Drawer(
    backgroundColor: DV.bg0,
    width: MediaQuery.of(context).size.width * 0.78,
    child: Column(children: [
      _drawerHeader(),
      Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(12, 10, 12, 0), children: [
        _dItem(Icons.home_rounded,            'Dashboard',        () { Navigator.pop(context); _switchTab(0); }),
        _dItem(FontAwesomeIcons.whatsapp,     'Bug Sender',       () { Navigator.pop(context); _switchTab(1); }),
        _dItem(Icons.notifications_rounded,   'Info & Feed',      () { Navigator.pop(context); _switchTab(2); }),
        _dItem(Icons.terminal_rounded,        'Tools Hub',        () { Navigator.pop(context); _switchTab(3); }),
        _dItem(Icons.electric_bolt_rounded,   'Zyhrx Paranel',   () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => ZyhrxParanelPage(sessionKey: sessionKey))); }),
        _dItem(Icons.settings_remote_rounded, 'Zyhrx Controller',() { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => ZyhrxControllerPage(sessionKey: sessionKey))); }),
        Container(height: 1, margin: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, DV.glassBorder, Colors.transparent]))),
        if (role == 'reseller') _dItem(Icons.storefront_rounded,          'Seller Panel', () { Navigator.pop(context); _go(SellerPage(keyToken: sessionKey)); }),
        if (role == 'admin')    _dItem(Icons.admin_panel_settings_rounded, 'Admin Panel',  () { Navigator.pop(context); _go(AdminPage(sessionKey: sessionKey)); }),
        if (role == 'owner')    _dItem(Icons.workspace_premium_rounded,    'Owner Panel',  () { Navigator.pop(context); _go(OwnerPage(sessionKey: sessionKey, username: username)); }),
        _dItem(Icons.history_rounded,         'Riwayat',          () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role))); }),
        _dItem(Icons.person_outline_rounded,  'Profile',          () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey))); }),
        _dItem(Icons.lock_outline_rounded,    'Change Password',  () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => ChangePasswordPage(username: username, sessionKey: sessionKey))); }),
        Container(height: 1, margin: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, DV.glassBorder, Colors.transparent]))),
        _dItem(Icons.logout_rounded, 'Logout', () async {
          Navigator.pop(context);
          final p = await SharedPreferences.getInstance(); await p.clear();
          if (!mounted) return;
          Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
        }, isLogout: true),
        const SizedBox(height: 24),
      ])),
    ]),
  );

  Widget _drawerHeader() => Container(
    height: 220,
    decoration: BoxDecoration(color: Colors.black, border: Border(bottom: BorderSide(color: DV.glassBorder))),
    child: Stack(children: [
      // Tiny BH in background
      Positioned(top: -40, left: -40, child: const BlackHoleWidget(size: 200, scale: 0.55)),
      // Dark overlay
      Container(decoration: BoxDecoration(gradient: LinearGradient(
        begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Colors.black.withOpacity(0.70), Colors.black.withOpacity(0.88)]))),
      if (_bannerCtrl != null && _bannerCtrl!.value.isInitialized)
        Opacity(opacity: 0.15, child: SizedBox.expand(child: FittedBox(fit: BoxFit.cover,
          child: SizedBox(width: _bannerCtrl!.value.size.width, height: _bannerCtrl!.value.size.height,
            child: VideoPlayer(_bannerCtrl!))))),
      SafeArea(bottom: false, child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        AnimatedBuilder(animation: _pulseAnim, builder: (_, __) => Stack(
          alignment: Alignment.center, children: [
          Container(width: 80, height: 80, decoration: BoxDecoration(shape: BoxShape.circle,
            border: Border.all(color: DV.diskMid.withOpacity(0.15 + _pulseAnim.value * 0.10)))),
          Container(width: 70, height: 70, padding: const EdgeInsets.all(2.5),
            decoration: BoxDecoration(shape: BoxShape.circle, gradient: DV.diskGradient,
              boxShadow: [
                BoxShadow(color: DV.diskCore.withOpacity(0.55 + _pulseAnim.value * 0.30), blurRadius: 22),
                BoxShadow(color: DV.diskOuter.withOpacity(0.20), blurRadius: 35),
              ]),
            child: ClipOval(child: _profileImage != null
              ? Image.file(_profileImage!, fit: BoxFit.cover)
              : Container(color: Colors.black, child: const Icon(FontAwesomeIcons.userAstronaut, size: 28, color: DV.diskMid)))),
        ])),
        const SizedBox(height: 10),
        ShaderMask(shaderCallback: (b) => DV.diskGradient.createShader(b),
          child: Text(username, style: const TextStyle(color: Colors.white,
              fontSize: 18, fontWeight: FontWeight.w900, fontFamily: 'Orbitron'))),
        const SizedBox(height: 5),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          _roleBadge(), const SizedBox(width: 8),
          Text('// $expiredDate', style: const TextStyle(color: DV.textHint, fontSize: 9, fontFamily: 'ShareTechMono')),
        ]),
      ]))),
    ]),
  );

  Widget _dItem(IconData icon, String label, VoidCallback onTap, {bool isLogout = false}) {
    final color = isLogout ? DV.error : DV.diskMid;
    return Container(margin: const EdgeInsets.only(bottom: 2),
      child: ListTile(dense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 1),
        leading: Container(width: 34, height: 34,
          decoration: BoxDecoration(color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withOpacity(0.18))),
          child: Icon(icon, color: color, size: 15)),
        title: Text(label, style: TextStyle(
          color: isLogout ? DV.error : DV.textPrimary, fontSize: 13, fontWeight: FontWeight.w500)),
        trailing: Icon(Icons.chevron_right_rounded, color: DV.textHint, size: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        onTap: onTap));
  }

  Widget _bottomNav() => ClipRect(child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 28, sigmaY: 28),
    child: Container(
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.94),
        border: Border(top: BorderSide(color: DV.diskMid.withOpacity(0.16))),
        boxShadow: [BoxShadow(color: DV.diskMid.withOpacity(0.10), blurRadius: 28, offset: const Offset(0, -6))]),
      child: SafeArea(top: false, child: Row(children: [
        _navItem(0, Icons.home_outlined,          Icons.home_rounded,          'HOME',  DV.diskMid),
        _navItem(1, FontAwesomeIcons.whatsapp,    FontAwesomeIcons.whatsapp,   'BUG',   DV.success),
        _navItem(2, Icons.notifications_outlined, Icons.notifications_rounded, 'FEED',  DV.jetBlue),
        _navItem(3, Icons.terminal_outlined,      Icons.terminal_rounded,      'TOOLS', DV.radHot),
      ])))));

  Widget _navItem(int idx, IconData off, IconData on, String label, Color color) {
    final active = _navIdx == idx;
    return Expanded(child: GestureDetector(onTap: () => _switchTab(idx),
      child: AnimatedContainer(duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(border: Border(top: BorderSide(
          color: active ? color : Colors.transparent, width: 2))),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          AnimatedContainer(duration: const Duration(milliseconds: 200),
            padding: EdgeInsets.all(active ? 6.0 : 0.0),
            decoration: BoxDecoration(
              color: active ? color.withOpacity(0.10) : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
              boxShadow: active ? [BoxShadow(color: color.withOpacity(0.35), blurRadius: 14)] : []),
            child: Icon(active ? on : off, color: active ? color : DV.textHint, size: 19)),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(color: active ? color : DV.textHint,
            fontSize: 8, fontWeight: active ? FontWeight.w900 : FontWeight.normal,
            fontFamily: active ? 'Orbitron' : null)),
        ]))));
  }
}

// ── Helpers ────────────────────────────────────────────────────────────────────
class _Ac {
  final IconData icon;
  final String label;
  final Color color;
  final bool primary;
  final VoidCallback onTap;
  const _Ac(this.icon, this.label, this.color, this.primary, this.onTap);
}

class _Mod {
  final IconData icon; final Color color; final String title, sub;
  const _Mod(this.icon, this.color, this.title, this.sub);
}

class _LoadingBody extends StatelessWidget {
  const _LoadingBody();
  @override Widget build(BuildContext context) => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Stack(alignment: Alignment.center, children: [
        const BlackHoleWidget(size: 180, scale: 0.6),
        SizedBox(width: 60, height: 60, child: CircularProgressIndicator(
          strokeWidth: 1.5, color: DV.diskMid.withOpacity(0.6),
          backgroundColor: DV.diskMid.withOpacity(0.08))),
      ]),
      const SizedBox(height: 16),
      const Text('ENTERING SINGULARITY...', style: TextStyle(
        color: DV.textHint, fontSize: 9, letterSpacing: 3, fontFamily: 'Orbitron')),
    ]));
}

class _NewsMedia extends StatefulWidget {
  final String url; const _NewsMedia({required this.url});
  @override State<_NewsMedia> createState() => _NewsMediaState();
}
class _NewsMediaState extends State<_NewsMedia> {
  VideoPlayerController? _ctrl;
  bool get _isVid => widget.url.endsWith('.mp4') || widget.url.endsWith('.webm');
  @override void initState() {
    super.initState();
    if (_isVid) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) { setState(() {}); _ctrl?.setLooping(true); _ctrl?.setVolume(0); _ctrl?.play(); }
        });
    }
  }
  @override void dispose() { _ctrl?.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    if (_isVid && _ctrl != null && _ctrl!.value.isInitialized)
      return FittedBox(fit: BoxFit.cover, child: SizedBox(
        width: _ctrl!.value.size.width, height: _ctrl!.value.size.height, child: VideoPlayer(_ctrl!)));
    if (_isVid) return Container(color: Colors.black,
      child: Center(child: CircularProgressIndicator(color: DV.diskMid, strokeWidth: 2)));
    return Image.network(widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(color: Colors.black,
        child: const Icon(Icons.broken_image_rounded, color: DV.textHint)));
  }
}
