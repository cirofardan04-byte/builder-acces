// bh_painter.dart — DarkVerse v8.0 Black Hole Core Visual Engine
// Renders: accretion disk, photon sphere, Schwarzschild radius, relativistic jets,
//          Hawking radiation, gravitational lensing, infalling matter streaks
import 'package:flutter/material.dart';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'dv_theme.dart';

class BlackHolePainter extends CustomPainter {
  final double diskAngle;   // 0..2π rotation of accretion disk
  final double lensStrength; // 0..1 lensing pulsation
  final double jetPower;    // 0..1 jet intensity
  final double particleT;   // 0..1 particle animation time
  final double bhScale;     // size multiplier (default 1.0)

  const BlackHolePainter({
    required this.diskAngle,
    required this.lensStrength,
    required this.jetPower,
    required this.particleT,
    this.bhScale = 1.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final bhr = 48.0 * bhScale; // event horizon radius

    _drawStarfield(canvas, size);
    _drawJets(canvas, cx, cy, bhr);
    _drawOuterDiskGlow(canvas, cx, cy, bhr);
    _drawAccretionDisk(canvas, cx, cy, bhr);
    _drawGravitationalLensing(canvas, cx, cy, bhr);
    _drawEventHorizon(canvas, cx, cy, bhr);
    _drawPhotonSphere(canvas, cx, cy, bhr);
    _drawHawkingRadiation(canvas, cx, cy, bhr);
    _drawInfallingStreaks(canvas, cx, cy, bhr);
  }

  void _drawStarfield(Canvas canvas, Size size) {
    final rng = math.Random(13);
    final p = Paint()..style = PaintingStyle.fill;
    for (int i = 0; i < 200; i++) {
      final x = rng.nextDouble() * size.width;
      final y = rng.nextDouble() * size.height;
      final sz = rng.nextDouble() * 1.4;
      final twinkle = (math.sin(particleT * math.pi * 6 + i * 1.3) * 0.5 + 0.5);
      final bright = 0.05 + twinkle * 0.30;
      final isBlue = i % 7 == 0;
      final isOrange = i % 11 == 0;
      final color = isBlue ? DV.jetBlue : (isOrange ? DV.diskOuter : Colors.white);
      p.color = color.withOpacity(bright);
      canvas.drawCircle(Offset(x, y), sz, p);
    }
  }

  void _drawJets(Canvas canvas, double cx, double cy, double bhr) {
    // Upper jet — relativistic beam
    final jetLength = 160.0 * bhScale;
    final jetWidthBase = 12.0 * bhScale;
    for (int layer = 0; layer < 5; layer++) {
      final w = jetWidthBase * (1.0 - layer * 0.16);
      final alpha = (0.45 - layer * 0.07) * (0.5 + jetPower * 0.5);
      final topY = cy - bhr - jetLength * (0.3 + layer * 0.15);
      final shader = ui.Gradient.linear(
        Offset(cx, cy - bhr),
        Offset(cx, topY),
        [DV.jetBlue.withOpacity(alpha * 1.2), DV.jetSoft.withOpacity(alpha * 0.8),
         DV.jetBlue.withOpacity(alpha * 0.3), Colors.transparent],
        [0.0, 0.3, 0.7, 1.0]);
      final p = Paint()..shader = shader..strokeWidth = w
        ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
      canvas.drawLine(Offset(cx, cy - bhr * 1.05), Offset(cx, topY), p);
    }
    // Upper jet cone spread
    final conePaint = Paint()..style = PaintingStyle.fill;
    final conePath = Path()
      ..moveTo(cx, cy - bhr)
      ..lineTo(cx - 22 * bhScale, cy - bhr - jetLength * 0.9)
      ..lineTo(cx + 22 * bhScale, cy - bhr - jetLength * 0.9)
      ..close();
    conePaint.shader = ui.Gradient.linear(
      Offset(cx, cy - bhr), Offset(cx, cy - bhr - jetLength * 0.9),
      [DV.jetBlue.withOpacity(0.10 * (0.5 + jetPower * 0.5)), Colors.transparent]);
    canvas.drawPath(conePath, conePaint);

    // Lower counter-jet (shorter, fainter)
    final djLen = 90.0 * bhScale;
    for (int layer = 0; layer < 3; layer++) {
      final w = (8.0 - layer * 2) * bhScale;
      final alpha = (0.28 - layer * 0.06) * (0.4 + jetPower * 0.6);
      final botY = cy + bhr + djLen * (0.4 + layer * 0.2);
      final shader = ui.Gradient.linear(
        Offset(cx, cy + bhr), Offset(cx, botY),
        [DV.jetCore.withOpacity(alpha), Colors.transparent]);
      final p = Paint()..shader = shader..strokeWidth = w
        ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
      canvas.drawLine(Offset(cx, cy + bhr * 1.05), Offset(cx, botY), p);
    }
  }

  void _drawOuterDiskGlow(Canvas canvas, double cx, double cy, double bhr) {
    // Big diffuse corona / outer disk atmospheric glow
    for (int i = 5; i >= 0; i--) {
      final r = bhr * (4.0 + i * 1.2);
      final ry = r * 0.28;
      final alpha = (0.04 - i * 0.005).clamp(0.0, 0.08);
      final p = Paint()
        ..shader = ui.Gradient.radial(Offset(cx, cy), r,
          [DV.diskMid.withOpacity(alpha * (0.7 + lensStrength * 0.3)), Colors.transparent],
          [0.6, 1.0])
        ..style = PaintingStyle.fill;
      canvas.drawOval(Rect.fromCenter(center: Offset(cx, cy), width: r * 2, height: ry * 2), p);
    }
  }

  void _drawAccretionDisk(Canvas canvas, double cx, double cy, double bhr) {
    // Multi-layer elliptical accretion disk with rotation
    final List<List<dynamic>> layers = <List<dynamic>>[
      <dynamic>[bhr * 1.45, bhr * 0.30, DV.diskCore.withOpacity(0.0),  DV.diskCore,  5.5],
      <dynamic>[bhr * 1.90, bhr * 0.38, DV.diskMid.withOpacity(0.0),   DV.diskMid,   4.5],
      <dynamic>[bhr * 2.60, bhr * 0.46, DV.diskOuter.withOpacity(0.0), DV.diskOuter, 3.5],
      <dynamic>[bhr * 3.50, bhr * 0.55, DV.diskGold.withOpacity(0.0),  DV.diskGold,  2.5],
      <dynamic>[bhr * 4.70, bhr * 0.62, DV.diskGold.withOpacity(0.0),  DV.diskOuter.withOpacity(0.5), 1.8],
      <dynamic>[bhr * 6.20, bhr * 0.68, Colors.transparent,            DV.diskOuter.withOpacity(0.22), 1.2],
    ];

    for (final List<dynamic> row in layers) {
      final double rx = (row[0] as num).toDouble();
      final double ry = (row[1] as num).toDouble();
      final Color cIn = row[2] as Color;
      final Color cOut = row[3] as Color;
      final double strokeW = (row[4] as num).toDouble();
      // Sweep gradient — Doppler boosting: one side brighter
      final sweepShader = ui.Gradient.sweep(
        Offset(cx, cy),
        <Color>[cOut, cIn, cOut, cOut, cIn.withOpacity(cIn.opacity * 0.5), cOut],
        <double>[0.0, 0.12, 0.35, 0.5, 0.68, 1.0],
        TileMode.clamp,
        diskAngle,
        diskAngle + math.pi * 2);

      final p = Paint()..shader = sweepShader
        ..strokeWidth = strokeW..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
      canvas.drawOval(Rect.fromCenter(center: Offset(cx, cy), width: rx * 2, height: ry * 2), p);
    }
  }

  void _drawGravitationalLensing(Canvas canvas, double cx, double cy, double bhr) {
    // Einstein ring — bright arc with gravitational lensing
    final lensR = bhr * 1.18;

    // Main bright arc (approaching side)
    final arcPaint = Paint()
      ..shader = ui.Gradient.sweep(Offset(cx, cy),
        [Colors.transparent, DV.diskGold.withOpacity(0.9 * (0.6 + lensStrength * 0.4)),
         DV.diskGold.withOpacity(0.4), Colors.transparent],
        [0.0, 0.12, 0.25, 0.4],
        TileMode.clamp,
        math.pi * 0.75 + diskAngle * 0.05,
        math.pi * 0.75 + diskAngle * 0.05 + math.pi * 2)
      ..strokeWidth = 2.8..style = PaintingStyle.stroke;
    canvas.drawCircle(Offset(cx, cy), lensR, arcPaint);

    // Secondary lensed image — opposite side, dimmer
    final arc2 = Paint()
      ..shader = ui.Gradient.sweep(Offset(cx, cy),
        [Colors.transparent, DV.diskCore.withOpacity(0.4 * (0.5 + lensStrength * 0.5)),
         Colors.transparent],
        [0.0, 0.1, 0.2],
        TileMode.clamp,
        math.pi * 1.75, math.pi * 1.75 + math.pi * 2)
      ..strokeWidth = 1.5..style = PaintingStyle.stroke;
    canvas.drawCircle(Offset(cx, cy), lensR * 1.04, arc2);

    // Thin glow rings
    for (int i = 0; i < 3; i++) {
      final r = lensR + i * 2.5;
      final ring = Paint()
        ..color = DV.diskGold.withOpacity((0.20 - i * 0.05) * (0.5 + lensStrength * 0.5))
        ..strokeWidth = 0.8..style = PaintingStyle.stroke;
      canvas.drawCircle(Offset(cx, cy), r, ring);
    }
  }

  void _drawEventHorizon(Canvas canvas, double cx, double cy, double bhr) {
    // True black — absolute void
    final p = Paint()..color = Colors.black..style = PaintingStyle.fill;
    canvas.drawCircle(Offset(cx, cy), bhr, p);

    // Very faint inner glow — light from disk reflecting on EH
    final innerReflect = Paint()
      ..shader = ui.Gradient.radial(
        Offset(cx, cy + bhr * 0.3), bhr * 0.85,
        [DV.diskCore.withOpacity(0.12), Colors.transparent],
        [0.0, 1.0]);
    canvas.drawCircle(Offset(cx, cy), bhr, innerReflect);
  }

  void _drawPhotonSphere(Canvas canvas, double cx, double cy, double bhr) {
    // Photon sphere — trapped photon orbit ring
    for (int i = 0; i < 5; i++) {
      final r = bhr + 2.0 + i * 2.5;
      final alpha = (0.55 - i * 0.10) * (0.6 + lensStrength * 0.4);
      final p = Paint()
        ..color = DV.diskGold.withOpacity(alpha.clamp(0.0, 0.6))
        ..strokeWidth = 1.8 - i * 0.25
        ..style = PaintingStyle.stroke;
      canvas.drawCircle(Offset(cx, cy), r, p);
    }
    // Hot-spot on photon sphere
    final spotPaint = Paint()
      ..shader = ui.Gradient.radial(
        Offset(cx + bhr * 0.9, cy + bhr * 0.1), bhr * 0.45,
        [DV.diskGold.withOpacity(0.7), Colors.transparent],
        [0.0, 1.0]);
    canvas.drawCircle(Offset(cx + bhr * 0.9, cy + bhr * 0.1), bhr * 0.45, spotPaint);
  }

  void _drawHawkingRadiation(Canvas canvas, double cx, double cy, double bhr) {
    // Quantum particles evaporating from event horizon
    final rng = math.Random(7);
    final p = Paint()..style = PaintingStyle.fill;
    for (int i = 0; i < 20; i++) {
      final angle = particleT * math.pi * 4 + i * (math.pi * 2 / 20);
      final dist = bhr + 6 + math.sin(particleT * math.pi * 6 + i) * 8;
      final x = cx + dist * math.cos(angle);
      final y = cy + dist * math.sin(angle) * 0.22;
      final sz = 0.8 + rng.nextDouble() * 1.6;
      final bright = 0.3 + math.sin(particleT * math.pi * 8 + i * 2.1) * 0.4;
      p.color = (i % 3 == 0 ? DV.diskGold : (i % 3 == 1 ? DV.diskCore : DV.radSoft))
        .withOpacity(bright.clamp(0.1, 0.8));
      canvas.drawCircle(Offset(x, y), sz, p);
    }
  }

  void _drawInfallingStreaks(Canvas canvas, double cx, double cy, double bhr) {
    // Hot gas/matter spiraling into the black hole
    final rng = math.Random(42);
    final p = Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    for (int i = 0; i < 24; i++) {
      final baseAngle = diskAngle * 0.4 + i * (math.pi * 2 / 24);
      final r1 = bhr * (1.5 + rng.nextDouble() * 4.5);
      final r2 = bhr * (1.15 + rng.nextDouble() * 0.3);
      final ry1 = r1 * 0.32;
      final ry2 = r2 * 0.22;
      final x1 = cx + r1 * math.cos(baseAngle);
      final y1 = cy + ry1 * math.sin(baseAngle);
      final x2 = cx + r2 * math.cos(baseAngle + 0.22);
      final y2 = cy + ry2 * math.sin(baseAngle + 0.22);
      final colorChoice = i % 4;
      final c = colorChoice == 0 ? DV.diskCore : colorChoice == 1 ? DV.diskMid :
                colorChoice == 2 ? DV.diskOuter : DV.diskGold;
      p.color = c.withOpacity(0.12 + rng.nextDouble() * 0.28);
      p.strokeWidth = 0.6 + rng.nextDouble() * 1.0;
      canvas.drawLine(Offset(x1, y1), Offset(x2, y2), p);
    }
  }

  @override
  bool shouldRepaint(BlackHolePainter old) =>
    old.diskAngle != diskAngle || old.lensStrength != lensStrength ||
    old.jetPower != jetPower || old.particleT != particleT;
}

/// Standalone Black Hole Widget — drop anywhere
class BlackHoleWidget extends StatefulWidget {
  final double size;
  final double scale;
  const BlackHoleWidget({super.key, this.size = 300, this.scale = 1.0});
  @override State<BlackHoleWidget> createState() => _BlackHoleWidgetState();
}

class _BlackHoleWidgetState extends State<BlackHoleWidget> with TickerProviderStateMixin {
  late AnimationController _disk, _lens, _jet, _particle;

  @override
  void initState() {
    super.initState();
    _disk     = AnimationController(vsync: this, duration: const Duration(seconds: 10))..repeat();
    _lens     = AnimationController(vsync: this, duration: const Duration(milliseconds: 3500))..repeat(reverse: true);
    _jet      = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _particle = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat();
  }

  @override
  void dispose() {
    _disk.dispose(); _lens.dispose(); _jet.dispose(); _particle.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: Listenable.merge([_disk, _lens, _jet, _particle]),
    builder: (_, __) => SizedBox(
      width: widget.size, height: widget.size,
      child: CustomPaint(
        painter: BlackHolePainter(
          diskAngle:   _disk.value * math.pi * 2,
          lensStrength: _lens.value,
          jetPower:    _jet.value,
          particleT:   _particle.value,
          bhScale:     widget.scale,
        ))));
}
