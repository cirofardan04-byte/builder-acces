import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'change_password_page.dart';
import 'widgets/custom_popup.dart';

// ─── NEUBRUTALISM PALETTE ─────────────────────────────────────
class _NB {
  // Background
  static const bg = Color(0xFFFFFFFF);

  // Surfaces
  static const surface = Color(0xFFF5F3FF);
  static const card = Color(0xFFFAFAFA);

  // Borders
  static const border = Color(0xFF000000);

  // Ungu (solid, not too thick)
  static const purpleMain = Color(0xFF7C3AED);
  static const purpleMid = Color(0xFF8B5CF6);
  static const purpleLight = Color(0xFFA78BFA);
  static const purplePale = Color(0xFFEDE9FE);

  // Pink (solid, not too thick)
  static const pinkMain = Color(0xFFEC4899);
  static const pinkMid = Color(0xFFF472B6);
  static const pinkLight = Color(0xFFF9A8D4);
  static const pinkPale = Color(0xFFFCE7F3);

  // Biru (solid, not too thick)
  static const blueMain = Color(0xFF3B82F6);
  static const blueMid = Color(0xFF60A5FA);
  static const blueLight = Color(0xFF93BBFC);
  static const bluePale = Color(0xFFDBEAFE);

  // Text
  static const text = Color(0xFF1A1A1A);
  static const textSub = Color(0xFF4B4B4B);
  static const textDim = Color(0xFF888888);
  static const orange = Color(0xFFF59E0B);
  
  // Gradien
  static const LinearGradient purpleGrad = LinearGradient(
    colors: [purpleMain, purpleMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  void initState() {
    super.initState();
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) {
      return "••••••••";
    }
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _NB.bg,
      appBar: AppBar(
        backgroundColor: _NB.bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _NB.purpleMain, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "My Profile",
          style: TextStyle(
            color: _NB.text,
            fontWeight: FontWeight.bold,
            fontSize: 20,
            fontFamily: 'Orbitron',
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(2),
          child: Container(height: 2, color: _NB.border),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(color: _NB.bg),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 20),

              // --- AVATAR PROFILE ---
              Center(
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: _NB.border, width: 2),
                    boxShadow: const [
                      BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/logo.png',
                      width: 160,
                      height: 160,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                widget.username,
                style: const TextStyle(
                  color: _NB.text,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                decoration: BoxDecoration(
                  color: _NB.purplePale,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _NB.border, width: 1.5),
                ),
                child: Text(
                  widget.role.toUpperCase(),
                  style: const TextStyle(
                    color: _NB.purpleMain,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // --- INFO GRID (BOXES) ---
              Row(
                children: [
                  Expanded(
                    child: _buildInfoCard(
                      icon: Icons.person_outline,
                      label: "Username",
                      value: _censorText(widget.username),
                      color: _NB.blueMain,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: _buildInfoCard(
                      icon: Icons.lock_outline,
                      label: "Password",
                      value: _censorText(widget.password, isPassword: true),
                      color: _NB.pinkMain,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 14),

              Row(
                children: [
                  Expanded(
                    child: _buildInfoCard(
                      icon: Icons.verified_user_outlined,
                      label: "Role",
                      value: widget.role.toUpperCase(),
                      color: _NB.purpleMain,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: _buildInfoCard(
                      icon: Icons.calendar_today_outlined,
                      label: "Expired",
                      value: widget.expiredDate,
                      color: _NB.orange,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 14),

              _buildInfoCard(
                icon: Icons.vpn_key,
                label: "Session Key",
                value: "${widget.sessionKey.substring(0, 8)}...",
                color: _NB.purpleLight,
              ),

              const SizedBox(height: 40),

              // --- CHANGE PASSWORD BUTTON ---
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.lock_reset, color: Colors.white, size: 22),
                  label: const Text(
                    "CHANGE PASSWORD",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _NB.purpleMain,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: const BorderSide(color: _NB.border, width: 2),
                    ),
                    elevation: 0,
                    shadowColor: Colors.transparent,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChangePasswordPage(
                          username: widget.username,
                          sessionKey: widget.sessionKey,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: _NB.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _NB.border, width: 2),
        boxShadow: const [
          BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(3, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _NB.border, width: 1),
                ),
                child: Icon(icon, color: color, size: 16),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: _NB.textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              color: _NB.text,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: 'ShareTechMono',
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }
}