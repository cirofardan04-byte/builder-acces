import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'widgets/custom_popup.dart';

// ─── NEUBRUTALISM PALETTE ─────────────────────────────────────
class _NB {
  // Background
  static const bg = Color(0xFFFFFFFF);

  // Surfaces
  static const surface = Color(0xFFF5F3FF);
  static const card = Color(0xFFFAFAFA);

  // Borders
  static const border = Color(0xFF000000);

  // Ungu (solid, not too thick)
  static const purpleMain = Color(0xFF7C3AED);
  static const purpleMid = Color(0xFF8B5CF6);
  static const purpleLight = Color(0xFFA78BFA);
  static const purplePale = Color(0xFFEDE9FE);

  // Pink (solid, not too thick)
  static const pinkMain = Color(0xFFEC4899);
  static const pinkMid = Color(0xFFF472B6);
  static const pinkLight = Color(0xFFF9A8D4);
  static const pinkPale = Color(0xFFFCE7F3);

  // Biru (solid, not too thick)
  static const blueMain = Color(0xFF3B82F6);
  static const blueMid = Color(0xFF60A5FA);
  static const blueLight = Color(0xFF93BBFC);
  static const bluePale = Color(0xFFDBEAFE);

  // Text
  static const text = Color(0xFF1A1A1A);
  static const textSub = Color(0xFF4B4B4B);
  static const textDim = Color(0xFF888888);

  // Status
  static const green = Color(0xFF059669);
  static const red = Color(0xFFDC2626);
  static const orange = Color(0xFFF59E0B);
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  Future<void> _launchUrl(BuildContext context, String url) async {
    try {
      final Uri uri = Uri.parse(url);
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) {
      if (context.mounted) {
        CustomPopup.show(
          context,
          title: "Gagal",
          message: "Tidak dapat membuka tautan ini.",
          icon: Icons.error_outline,
          iconColor: _NB.red,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _NB.bg,
      appBar: AppBar(
        backgroundColor: _NB.bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _NB.purpleMain, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "Customer Service",
          style: TextStyle(
            color: _NB.text,
            fontWeight: FontWeight.bold,
            fontSize: 18,
            fontFamily: 'Orbitron',
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(2),
          child: Container(height: 2, color: _NB.border),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(color: _NB.bg),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Header Icon
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: _NB.purplePale,
                    shape: BoxShape.circle,
                    border: Border.all(color: _NB.border, width: 2),
                    boxShadow: const [
                      BoxShadow(
                        color: _NB.border,
                        blurRadius: 0,
                        offset: Offset(6, 6),
                      ),
                    ],
                  ),
                  child: Icon(
                    Icons.support_agent_rounded,
                    size: 60,
                    color: _NB.purpleMain,
                  ),
                ),
                const SizedBox(height: 24),
                const Text(
                  "Need Help?",
                  style: TextStyle(
                    color: _NB.text,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "Contact us through our social media platforms below.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _NB.textSub,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 40),

                // Grid Buttons
                Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: _buildContactButton(
                            context: context,
                            label: "Telegram",
                            icon: FontAwesomeIcons.telegram,
                            color: _NB.blueMain,
                            url: "https://t.me/maklowampastahu",
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: _buildContactButton(
                            context: context,
                            label: "WhatsApp",
                            icon: FontAwesomeIcons.whatsapp,
                            color: _NB.green,
                            url: "https://wa.me/628212347259",
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: _buildContactButton(
                            context: context,
                            label: "TikTok",
                            icon: FontAwesomeIcons.tiktok,
                            color: _NB.text,
                            url: "https://www.tiktok.com/@archivjaa=1&_t=ZS-932NwfrWU5o",
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: _buildContactButton(
                            context: context,
                            label: "Instagram",
                            icon: FontAwesomeIcons.instagram,
                            color: _NB.pinkMain,
                            url: "https://www.instagram.com/darkness_reals?igsh=MWM2MDl5NXg0bTJpNg==",
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 40),
                // Footer
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _NB.card,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _NB.border, width: 2),
                    boxShadow: const [
                      BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
                    ],
                  ),
                  child: Column(
                    children: [
                      const Text(
                        "© 2026 Queen Team",
                        style: TextStyle(
                          color: _NB.textSub,
                          fontSize: 12,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "All Rights Reserved",
                        style: TextStyle(
                          color: _NB.textDim,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactButton({
    required BuildContext context,
    required String label,
    required IconData icon,
    required Color color,
    required String url,
  }) {
    return InkWell(
      onTap: () => _launchUrl(context, url),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
        decoration: BoxDecoration(
          color: _NB.card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _NB.border, width: 2),
          boxShadow: const [
            BoxShadow(
              color: _NB.border,
              blurRadius: 0,
              offset: Offset(4, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(color: _NB.border, width: 1.5),
              ),
              child: FaIcon(
                icon,
                color: color,
                size: 28,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              label,
              style: TextStyle(
                color: _NB.text,
                fontSize: 16,
                fontWeight: FontWeight.w600,
                fontFamily: 'Orbitron',
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}