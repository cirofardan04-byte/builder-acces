// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'login_page.dart';
import 'set.dart';
import 'tap.dart';

// ─── NEUBRUTALISM PALETTE ─────────────────────────────────────
class _NB {
  // Background
  static const bg = Color(0xFFFFFFFF);

  // Surfaces
  static const surface = Color(0xFFF5F3FF);
  static const card = Color(0xFFFAFAFA);

  // Borders
  static const border = Color(0xFF000000);

  // Ungu (solid, not too thick)
  static const purpleMain = Color(0xFF7C3AED);
  static const purpleMid = Color(0xFF8B5CF6);
  static const purpleLight = Color(0xFFA78BFA);
  static const purplePale = Color(0xFFEDE9FE);

  // Pink (solid, not too thick)
  static const pinkMain = Color(0xFFEC4899);
  static const pinkMid = Color(0xFFF472B6);
  static const pinkLight = Color(0xFFF9A8D4);
  static const pinkPale = Color(0xFFFCE7F3);

  // Biru (solid, not too thick)
  static const blueMain = Color(0xFF3B82F6);
  static const blueMid = Color(0xFF60A5FA);
  static const blueLight = Color(0xFF93BBFC);
  static const bluePale = Color(0xFFDBEAFE);

  // Text
  static const text = Color(0xFF1A1A1A);
  static const textSub = Color(0xFF4B4B4B);
  static const textDim = Color(0xFF888888);

  // Status
  static const green = Color(0xFF059669);
  static const red = Color(0xFFDC2626);
  static const orange = Color(0xFFF59E0B);

  // Gradien
  static const LinearGradient purpleGrad = LinearGradient(
    colors: [purpleMain, purpleMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  // Entry animation
  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // Loop animation
  late AnimationController _loopController;
  late Animation<double> _floatingAnimation;

  @override
  void initState() {
    super.initState();

    // Entry animation
    _entryController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600));
    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _entryController, curve: Curves.easeOut),
    );
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero).animate(
      CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
    );

    // Loop animation
    _loopController = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _floatingAnimation = Tween<double>(begin: -10.0, end: 10.0).animate(
      CurvedAnimation(parent: _loopController, curve: Curves.easeInOut),
    );

    _entryController.forward();
  }

  @override
  void dispose() {
    _entryController.dispose();
    _loopController.dispose();
    super.dispose();
  }

  // ── Stagger Animation Helper ──────────────────────────────────────────────
  Animation<double> _stagger(double start, double end) {
    return Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryController,
        curve: Interval(start, end, curve: Curves.easeOutCubic),
      ),
    );
  }

  Widget _fadeSlide({required Animation<double> anim, double offsetY = 22, required Widget child}) {
    return AnimatedBuilder(
      animation: anim,
      builder: (_, __) => Opacity(
        opacity: anim.value,
        child: Transform.translate(
          offset: Offset(0, offsetY * (1.0 - anim.value)),
          child: child,
        ),
      ),
    );
  }

  // ── Button Builders ───────────────────────────────────────────────────────
  Widget _buildLongButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _NB.border, width: 2),
          boxShadow: const [
            BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 22),
            const SizedBox(width: 14),
            Text(label,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.8)),
            const Spacer(),
            const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white60, size: 14),
          ],
        ),
      ),
    );
  }

  Widget _buildHalfButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _NB.border, width: 2),
            boxShadow: const [
              BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(3, 3)),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Flexible(
                child: Text(label,
                    style: const TextStyle(
                        color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700, fontFamily: 'Orbitron'),
                    overflow: TextOverflow.ellipsis),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return GlobalTouchWrapper(
      child: Scaffold(
        backgroundColor: _NB.bg,
        body: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              // ── IMAGE BANNER ────────────────────────────────────────────────
              _fadeSlide(
                anim: _stagger(0.0, 0.22),
                offsetY: 0,
                child: Container(
                  width: double.infinity,
                  height: 290,
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: _NB.border, width: 2),
                    ),
                  ),
                  child: Stack(
                    children: [
                      // Gambar
                      Positioned.fill(
                        child: Image.asset(
                          "assets/images/am.jpg",
                          fit: BoxFit.cover,
                        ),
                      ),
                      // Bayangan bawah
                      Positioned(
                        bottom: 0, left: 0, right: 0,
                        child: Container(
                          height: 70,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [_NB.bg, Colors.transparent],
                            ),
                          ),
                        ),
                      ),
                      // Bayangan sisi kiri
                      Positioned(
                        top: 0, bottom: 0, left: 0,
                        child: Container(
                          width: 30,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                              colors: [Colors.black.withOpacity(0.15), Colors.transparent],
                            ),
                          ),
                        ),
                      ),
                      // Bayangan sisi kanan
                      Positioned(
                        top: 0, bottom: 0, right: 0,
                        child: Container(
                          width: 30,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.centerRight,
                              end: Alignment.centerLeft,
                              colors: [Colors.black.withOpacity(0.15), Colors.transparent],
                            ),
                          ),
                        ),
                      ),
                      // Bayangan atas
                      Positioned(
                        top: 0, left: 0, right: 0,
                        child: Container(
                          height: 40,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Colors.black.withOpacity(0.1), Colors.transparent],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 16),

                    // ── QUEEN PROJECT TITLE ────────────────────────────────────
                    _fadeSlide(
                      anim: _stagger(0.10, 0.32),
                      child: RichText(
                        text: const TextSpan(
                          style: TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron',
                              letterSpacing: 2.5),
                          children: [
                            TextSpan(text: "Pxl", style: TextStyle(color: _NB.text)),
                            TextSpan(text: "Project", style: TextStyle(color: _NB.purpleMain)),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 8),

                    // ── SUBTITLE ─────────────────────────────────────────────
                    _fadeSlide(
                      anim: _stagger(0.16, 0.38),
                      child: const Text(
                        "Aplikasi Yang Dikembangkan Gavin",
                        style: TextStyle(
                            color: _NB.textSub,
                            fontSize: 12,
                            fontFamily: 'Orbitron',
                            letterSpacing: 0.8,
                            height: 1.5),
                      ),
                    ),

                    const SizedBox(height: 22),

                    // ── INFO BOX ─────────────────────────────────────────────
                    _fadeSlide(
                      anim: _stagger(0.22, 0.44),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: _NB.card,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: _NB.border, width: 2),
                          boxShadow: const [
                            BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              const Icon(Icons.info_outline_rounded, color: _NB.purpleMain, size: 16),
                              const SizedBox(width: 8),
                              const Text("Tentang Pxl",
                                  style: TextStyle(
                                      color: _NB.text,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w800,
                                      fontFamily: 'Orbitron',
                                      letterSpacing: 0.8)),
                            ]),
                            const SizedBox(height: 10),
                            const Text(
                              "Pxl adalah platform tools canggih yang dirancang untuk memberikan performa terbaik. "
                              "Dikembangkan secara profesional oleh Gavin dengan teknologi mutakhir dan sistem keamanan tinggi.",
                              style: TextStyle(
                                  color: _NB.textSub,
                                  fontSize: 12,
                                  fontFamily: 'Orbitron',
                                  height: 1.65),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 18),

                    // ── BUTTON: SIGN IN ──────────────────────────────────────
                    _fadeSlide(
                      anim: _stagger(0.28, 0.50),
                      child: _buildLongButton(
                        icon: Icons.login_rounded,
                        label: "Sign-In To Pxl",
                        color: _NB.purpleMain,
                        onTap: () => Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (_) => const LoginPage()),
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // ── ROW: DEVELOPER + OWNER ────────────────────────────────
                    _fadeSlide(
                      anim: _stagger(0.34, 0.56),
                      child: Row(
                        children: [
                          _buildHalfButton(
                            icon: FontAwesomeIcons.telegram,
                            label: "Developer",
                            color: _NB.purpleMain,
                            onTap: () async {
                              final uri = Uri.parse("https://t.me/jaaxnv");
                              if (await canLaunchUrl(uri)) {
                                launchUrl(uri, mode: LaunchMode.externalApplication);
                              }
                            },
                          ),
                          const SizedBox(width: 12),
                          _buildHalfButton(
                            icon: FontAwesomeIcons.telegram,
                            label: "Owner",
                            color: _NB.blueMain,
                            onTap: () async {
                              final uri = Uri.parse("https://t.me/jaaxnv");
                              if (await canLaunchUrl(uri)) {
                                launchUrl(uri, mode: LaunchMode.externalApplication);
                              }
                            },
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),

                    // ── FOOTER BOX ────────────────────────────────────────────
                    _fadeSlide(
                      anim: _stagger(0.42, 0.64),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        decoration: BoxDecoration(
                          color: _NB.card,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: _NB.border, width: 2),
                          boxShadow: const [
                            BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
                          ],
                        ),
                        child: Column(
                          children: [
                            const Text(
                              "By : Gavin imut",
                              style: TextStyle(
                                  color: _NB.purpleMain,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 2),
                            ),
                            const SizedBox(height: 5),
                            const Text(
                              "© 2026 Gavin — All Rights Reserved",
                              style: TextStyle(
                                  color: _NB.textSub, fontSize: 10, fontFamily: 'Orbitron', letterSpacing: 0.8),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 36),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}