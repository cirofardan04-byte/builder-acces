import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

// Import halaman lain
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'device_dashboard.dart';
import 'partner_page.dart';
import 'set.dart';
import 'tap.dart';
import 'moderator_page.dart';
import 'widgets/custom_popup.dart';
import 'global_chat_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  // --- State Variabel ---
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // --- Variabel Banner/News ---
  late PageController _newsPageController;
  double _currentNewsPage = 0.0; 
  Timer? _newsTimer;
  VideoPlayerController? _videoController;

  // --- TEMA WARNA HIJAU ---
static const Color bgMain = Color(0xFFE8F8F0);       // hijau sangat muda
static const Color bgSurface = Color(0xFFFFFFFF);     // putih
static const Color bgCard = Color(0xFFF0FBF5);        // hijau pucat
static const Color textMain = Colors.black87;
static const Color textSub = Colors.black54;

static const Color accentWhite = Color(0xFF16A34A);   // hijau utama
static const Color borderLight = Color(0xFF22C55E);   // hijau cerah
static const Color borderGlass = Color(0xFF22C55E);   // hijau cerahbiru cerah

  @override
  void initState() {
    super.initState();
    
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController?.setVolume(1.0); // Enable sound
        _videoController?.setLooping(true);
        _videoController?.play();
      });

    // Pastikan Banner di-init SEBELUM halaman dibangun
    _initNewsBanner();
    _selectedPage = _buildNewsPage();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _initAndroidIdAndConnect();
    _loadProfileImage();
  }

  void _initNewsBanner() {
    _newsPageController = PageController(
      initialPage: 0,
      viewportFraction: 0.9,
    );

    // Listener ini akan memperbarui posisi untuk auto scroll (tanpa setState)
    _newsPageController.addListener(() {
      if (_newsPageController.hasClients && _newsPageController.page != null) {
        _currentNewsPage = _newsPageController.page!;
      }
    });

    if (newsList.isNotEmpty) {
      _newsTimer = Timer.periodic(const Duration(seconds: 5), (Timer timer) {
        if (_newsPageController.hasClients) {
          int targetIndex = (_currentNewsPage + 1).round() % newsList.length;
          _newsPageController.animateToPage(
            targetIndex,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
          );
        }
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
      Uri.parse('ws://panelpakekwoingen.ajengfeb.my.id:2078'),
    );
    channel.sink.add(
      jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }),
    );
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    CustomPopup.show(
      context,
      title: "Session Expired",
      message: message,
      icon: Icons.error_outline,
      iconColor: Colors.redAccent,
      confirmText: "OK",
      onConfirm: () {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginPage()),
          (route) => false,
        );
      },
    );
  }

  void _onBottomNavTapped(int index) {
    if (index == 1) {
      _showWhatsAppMenu();
      return;
    }
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 3) {
        _selectedPage = InfoPage(
        sessionKey: sessionKey);
      } else if (index == 4) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      }
    });
  }

  void _showWhatsAppMenu() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: Dialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: const Color(0xFFF0F7FF),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 24,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF25D366).withOpacity(0.15),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(FontAwesomeIcons.whatsapp, size: 36, color: Color(0xFF25D366)),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "WHATSAPP TOOLS",
                    style: TextStyle(
                      color: Colors.black87,
                      fontFamily: 'Orbitron',
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.0,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Choose an action to perform",
                    style: TextStyle(color: Colors.black54, fontSize: 13),
                  ),
                  const SizedBox(height: 24),
                  _buildWhatsAppOption(
                    icon: Icons.bug_report,
                    color: Colors.redAccent,
                    title: "WhatsApp Crash",
                    subtitle: "Send payloads & crash codes",
                    onTap: () {
                      Navigator.pop(context);
                      setState(() {
                        _bottomNavIndex = 1;
                        _selectedPage = HomePage(
                          username: username,
                          password: password,
                          listBug: listBug,
                          role: role,
                          expiredDate: expiredDate,
                          sessionKey: sessionKey,
                        );
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  _buildWhatsAppOption(
                    icon: Icons.devices,
                    color: Colors.greenAccent,
                    title: "Manage Sender",
                    subtitle: "Pair devices & manage sessions",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role)));
                    },
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        foregroundColor: Colors.black87,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: const Text("Cancel", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildWhatsAppOption({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black.withOpacity(0.05)),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: Colors.black54,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: Colors.black26, size: 14),
          ],
        ),
      ),
    );
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 2) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 4) {
        _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 5) {
        _selectedPage = ModeratorPage(
          sessionKey: sessionKey,
          username: username,
        );
      }
    });
    Navigator.pop(context);
  }

  // ============================================================
  // OTAX DASHBOARD HEADER + ACCESS ROLE CARD
  // ============================================================

  String _getGreetingPeriod() {
    final hour = DateTime.now().hour;
    if (hour >= 4 && hour < 6) return "Subuh";   // 04:00 - 05:59
    if (hour >= 6 && hour < 11) return "Pagi";   // 06:00 - 10:59
    if (hour >= 11 && hour < 15) return "Siang"; // 11:00 - 14:59
    if (hour >= 15 && hour < 18) return "Sore";  // 15:00 - 17:59
    return "Malam";                              // 18:00 - 03:59
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "founder":
        return const Color(0xFFD32F2F);
      case "developer":
        return const Color(0xFFD32F2F);
      case "ceo":
        return const Color(0xFFD32F2F);
      case "tk":
        return const Color(0xFFD32F2F);
      case "high owner":
        return const Color(0xFFD32F2F);
      case "owner":
        return const Color(0xFFD32F2F);
      case "moderator":
        return const Color(0xFF1976D2);
      case "partner":
        return const Color(0xFFF57C00);
      case "admin":
        return const Color(0xFF388E3C);
      case "vip":
        return const Color(0xFFD32F2F);
      case "reseller":
        return const Color(0xFF7B1FA2);
      default:
        return Colors.black54;
    }
  }

  Widget _buildOtaxDashboardBanner() {
    // Full-bleed: tanpa padding kiri/kanan & tanpa border radius agar foto
    // menyatu dengan tepi layar. Neubrutalism accent: bottom hard border.
    return Container(
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Colors.black, width: 2.5),
        ),
      ),
      child: SizedBox(
        height: 200,
        width: double.infinity,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Background foto banner
            Image.asset(
              'assets/images/banner.jpg',
              fit: BoxFit.cover,
            ),
            // Overlay gelap tipis agar teks tetap terbaca di atas foto
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.35),
                    Colors.black.withOpacity(0.55),
                  ],
                ),
              ),
            ),
            const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "Xyler Project",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 40,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                      fontFamily: 'Aktura',
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    "© By Jaa Cool",
                    style: TextStyle(
                      color: Colors.white54,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w400,
                      letterSpacing: 0.8,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRoleButtonCard({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: bgSurface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.black, width: 1.5),
            boxShadow: [
              // Neubrutalism: hard offset shadow
              const BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(4, 4)),
              BoxShadow(color: color.withOpacity(0.12), blurRadius: 12, offset: const Offset(0, 4)),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.bold, fontSize: 15)),
                    const SizedBox(height: 2),
                    Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 12)),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: color, size: 22),
            ],
          ),
        ),
      ),
    );
  }

  void _navigateToRolePage(int index) {
    setState(() {
      if (index == 1) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 2) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 4) {
        _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 5) {
        _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username);
      }
    });
  }

  List<Widget> _buildRoleActionButtons() {
    final List<Widget> buttons = [];
    final r = role.toLowerCase();

    if (r == "owner" ||
    r == "founder" ||
    r == "developer" ||
    r == "ceo" ||
    r == "tk" ||
    r == "high owner" ||
    r == "vip") {
      buttons.add(_buildRoleButtonCard(
  icon: Icons.workspace_premium,
  color: _getRoleColor(role),
  title: "Owner Page",
  subtitle: "Akses & Kelola Halaman Owner",
  onTap: () => _navigateToRolePage(3),
));
    }
    if (r == "reseller") {
      buttons.add(_buildRoleButtonCard(
        icon: Icons.storefront,
        color: _getRoleColor("reseller"),
        title: "Reseller Page",
        subtitle: "Akses & Kelola Halaman Reseller",
        onTap: () => _navigateToRolePage(1),
      ));
    }
    if (r == "admin") {
      buttons.add(_buildRoleButtonCard(
        icon: Icons.admin_panel_settings,
        color: _getRoleColor("admin"),
        title: "Admin Page",
        subtitle: "Akses & Kelola Halaman Admin",
        onTap: () => _navigateToRolePage(2),
      ));
    }
    if (r == "partner") {
      buttons.add(_buildRoleButtonCard(
        icon: FontAwesomeIcons.handshake,
        color: _getRoleColor("partner"),
        title: "Partner Page",
        subtitle: "Akses & Kelola Halaman Partner",
        onTap: () => _navigateToRolePage(4),
      ));
    }
    if (r == "moderator") {
      buttons.add(_buildRoleButtonCard(
        icon: FontAwesomeIcons.userShield,
        color: _getRoleColor("moderator"),
        title: "Moderator Page",
        subtitle: "Akses & Kelola Halaman Moderator",
        onTap: () => _navigateToRolePage(5),
      ));
    }
    // role "member" (atau role lain yang tidak dikenali) -> tidak ada tombol

    return buttons;
  }

  Widget _buildAccessRoleCard() {
    final roleButtons = _buildRoleActionButtons();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Selamat ${_getGreetingPeriod()}, $username!!",
              style: const TextStyle(color: Colors.black87, fontSize: 21, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
            ),
            const SizedBox(height: 10),
            Container(
              width: 60,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text("Access Role : ", style: TextStyle(color: Colors.black87, fontSize: 14, fontWeight: FontWeight.w600)),
                Text(
                  role.toUpperCase(),
                  style: TextStyle(
                    color: _getRoleColor(role),
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
            if (roleButtons.isNotEmpty) ...roleButtons,
            const SizedBox(height: 20),
            const Text(
              "Selamat datang kembali di Xyler Project. Kami hadir membawa pembaruan masif untuk sistem manajemen dan tools eksklusif. Nikmati navigasi baru yang lebih mulus dan performa yang ditingkatkan untuk kebutuhan operasional kamu.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                color: Colors.black87,
                fontSize: 12.5,
                height: 1.6,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Preview card global chat yang akan ditampilkan di dashboard
  Widget _buildGlobalChatPreview() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section header (konsisten dengan QUICK ACTIONS & LATEST UPDATE)
          Container(
            padding: const EdgeInsets.only(left: 10),
            decoration: const BoxDecoration(
              border: Border(left: BorderSide(color: Colors.black, width: 3.5)),
            ),
            child: Row(
              children: const [
                Icon(Icons.groups_2_rounded, color: Colors.black87, size: 20),
                SizedBox(width: 8),
                Text(
                  "GLOBAL CHAT",
                  style: TextStyle(
                    color: Colors.black87,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: 60,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.black87,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            "Ngobrol langsung dengan semua pengguna Xyler di satu ruangan.",
            style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.4),
          ),
          const SizedBox(height: 14),
          // Preview card — neubrutalism, warna bgCard
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => GlobalChatPage(
                  username: username,
                  sessionKey: sessionKey,
                  androidId: androidId, // ← FIX: pass androidId
                ),
              ),
            ),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: bgCard,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black, width: 1.5),
                boxShadow: const [
                  BoxShadow(
                      color: Colors.black, blurRadius: 0, offset: Offset(4, 4)),
                ],
              ),
              child: Row(
                children: [
                  // Avatar lingkaran
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: accentWhite.withOpacity(0.12),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.black, width: 1.2),
                    ),
                    child: const Icon(Icons.groups_2_rounded,
                        size: 22, color: accentWhite),
                  ),
                  const SizedBox(width: 14),
                  // Teks preview (username + last message placeholder)
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Community Room",
                          style: TextStyle(
                            color: Colors.black87,
                            fontWeight: FontWeight.w800,
                            fontSize: 13.5,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            // Online indicator dot
                            Container(
                              width: 7,
                              height: 7,
                              decoration: const BoxDecoration(
                                color: Colors.green,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 5),
                            const Text(
                              "Tap untuk masuk ke ruang chat",
                              style: TextStyle(
                                color: Colors.black54,
                                fontSize: 12,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  // Arrow icon
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: accentWhite.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.arrow_forward_rounded,
                        color: accentWhite, size: 20),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNewsPage() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // OTAX DASHBOARD HEADER — flush ke appbar
          _buildOtaxDashboardBanner(),

          const SizedBox(height: 24),

          // ACCESS ROLE CARD (Selamat datang + Access Role + tombol sesuai role)
          _buildAccessRoleCard(),

          const SizedBox(height: 30),

          // LATEST UPDATE (Moved Above Community Hub)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Neubrutalism section header: left border accent
                Container(
                  padding: const EdgeInsets.only(left: 10),
                  decoration: const BoxDecoration(
                    border: Border(left: BorderSide(color: Colors.black, width: 3.5)),
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.calendar_month_rounded, color: Colors.black87, size: 20),
                      SizedBox(width: 8),
                      Text("LATEST UPDATE", style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 1.2)),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: 60,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 10),
                const Text("Keep yourself informed about recent system maintenance, newly added tools, and important announcements from the administration.", style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.4)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            height: 180,
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Stack(
              children: [
                PageView.builder(
                  controller: _newsPageController,
                  itemCount: newsList.length,
                  itemBuilder: (context, index) {
                    final item = newsList[index];
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: bgCard,
                        border: Border.all(color: Colors.black, width: 1.5),
                        boxShadow: [
                          // Neubrutalism: hard offset shadow
                          const BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(4, 4)),
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            if (item['image'] != null &&
                                item['image'].toString().isNotEmpty)
                              NewsMedia(url: item['image']),
                            if (item['image'] == null)
                               Container(color: bgCard, child: const Icon(Icons.newspaper, color: textSub, size: 50)),
                            
                            Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.black.withOpacity(0.8),
                                    Colors.transparent,
                                  ],
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 30,
                              left: 20,
                              right: 16,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['title'] ?? 'No Title',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item['desc'] ?? '',
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.85),
                                      fontSize: 13,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                
                // --- EXPANDING DOTS (Efek Geser Membesar) ---
                Positioned(
                  bottom: 8,
                  left: 0,
                  right: 0,
                  child: AnimatedBuilder(
                    animation: _newsPageController,
                    builder: (context, child) {
                      double currentNewsPage = 0.0;
                      if (_newsPageController.hasClients && _newsPageController.page != null) {
                        currentNewsPage = _newsPageController.page!;
                      } else {
                        currentNewsPage = _currentNewsPage;
                      }

                      return Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(newsList.length, (index) {
                          // Hitung jarak antara halaman scroll saat ini dengan index titik
                          double diff = (index - currentNewsPage).abs();
                          
                          // Atur Ukuran: 
                          // Jika aktif (diff = 0), width = 25.
                          // Jika pasif (diff >= 1), width = 5.
                          // Di antaranya, interpolasi ukuran.
                          double width = 5.0;
                          double opacity = 0.3;

                          if (diff < 1) {
                            width = 25.0 - (diff * 20.0); // 25 -> 5
                            opacity = 1.0 - (diff * 0.7);  // 1.0 -> 0.3
                          }

                          return Container(
                            margin: const EdgeInsets.symmetric(horizontal: 2.5),
                            width: width, // Width berubah saat digeser
                            height: 5,
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(opacity),
                              borderRadius: BorderRadius.circular(5),
                            ),
                          );
                        }),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 30),

          // QUICK ACTIONS (New — ported from file 1, adapted to this app's features)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Neubrutalism section header: left border accent
                Container(
                  padding: const EdgeInsets.only(left: 10),
                  decoration: const BoxDecoration(
                    border: Border(left: BorderSide(color: Colors.black, width: 3.5)),
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.flash_on_rounded, color: Colors.black87, size: 20),
                      SizedBox(width: 8),
                      Text("QUICK ACTIONS", style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 1.2)),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: 60,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 10),
                const Text("Akses cepat ke fitur-fitur utama aplikasi.", style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.4)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 168,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              children: [
                _QuickActionCard(
                  title: "Bug Sender",
                  subtitle: "Pairing & Configuration",
                  icon: Icons.bug_report_rounded,
                  colors: const [Color(0xFFD32F2F), Color(0xFFFF6659)],
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role))),
                ),
                _QuickActionCard(
                  title: "Riwayat Aktivitas",
                  subtitle: "Lihat Histori Aktivitas Kamu",
                  icon: Icons.history_rounded,
                  colors: const [Color(0xFF1565C0), Color(0xFF64B5F6)],
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role))),
                ),
                _QuickActionCard(
                  title: "Profile Saya",
                  subtitle: "Kelola Akun & Data Kamu",
                  icon: Icons.person_rounded,
                  colors: const [Color(0xFF388E3C), Color(0xFF81C784)],
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey))),
                ),
                _QuickActionCard(
                  title: "Contact Us",
                  subtitle: "Hubungi Tim Support",
                  icon: Icons.contact_support_rounded,
                  colors: const [Color(0xFFF57C00), Color(0xFFFFB74D)],
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage())),
                ),
                _QuickActionCard(
                  title: "Info & Bantuan",
                  subtitle: "Panduan Penggunaan App",
                  icon: Icons.info_rounded,
                  colors: const [Color(0xFF7B1FA2), Color(0xFFBA68C8)],
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => InfoPage (sessionKey: sessionKey))),
                ),
              ],
            ),
          ),

          const SizedBox(height: 30),

          // GLOBAL CHAT PREVIEW CARD
          _buildGlobalChatPreview(),

          const SizedBox(height: 30),

          // COMMUNITY HUB (Moved Below Quick Actions)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Neubrutalism section header: left border accent
                Container(
                  padding: const EdgeInsets.only(left: 10),
                  decoration: const BoxDecoration(
                    border: Border(left: BorderSide(color: Colors.black, width: 3.5)),
                  ),
                  child: const Text("COMMUNITY HUB", style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 1.2)),
                ),
                const SizedBox(height: 6),
                const Text("Stay connected with the OTOMIX community. Get real-time updates, access exclusive payloads, and participate in discussions with other members.", style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.4)),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  height: 55,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(color: accentWhite.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4)),
                    ],
                  ),
                  child: ElevatedButton.icon(
                    icon: const Icon(FontAwesomeIcons.telegram, color: Colors.white, size: 20),
                    label: const Text("Join Telegram Channel", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 1.0)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accentWhite, 
                      shadowColor: Colors.transparent, 
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: () => _openUrl("https://t.me/XylerCrush"),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 100), // Added padding for floating bottom nav
        ],
      ),
    );
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgMain,
      width: MediaQuery.of(context).size.width * 0.55,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 180,
            decoration: const BoxDecoration(color: bgMain),
            child: SafeArea(
              child: Center(
                child: Image.asset(
                  'assets/images/logo.png',
                  width: 120,
                  height: 120,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: bgMain,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 10),
                children: [
                  if (role == "reseller") _buildDrawerMenuItem(icon: Icons.storefront, label: "Seller Page", onTap: () => _onSidebarTabSelected(1)),
                  if (role == "admin") _buildDrawerMenuItem(icon: Icons.admin_panel_settings, label: "Admin Page", onTap: () => _onSidebarTabSelected(2)),
                  if (role == "partner") _buildDrawerMenuItem(icon: FontAwesomeIcons.handshake, label: "Partner Page", onTap: () => _onSidebarTabSelected(4)),
                  if (role == "moderator") _buildDrawerMenuItem(icon: FontAwesomeIcons.userShield, label: "Moderator Page", onTap: () => _onSidebarTabSelected(5)),
                  if (role == "owner" ||
    role == "founder" ||
    role == "developer" ||
    role == "high owner" ||
    role == "ceo" ||
    role == "tk" ||
    role == "vip") _buildDrawerMenuItem(icon: Icons.workspace_premium, label: "Owner Page", onTap: () => _onSidebarTabSelected(3)),
                  _buildDrawerMenuItem(icon: Icons.history_rounded, label: "Riwayat Aktivitas", onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role))); }),
                  const SizedBox(height: 20),
                  _buildDrawerMenuItem(icon: Icons.logout, label: "Log Out", isLogout: true, onTap: () async { Navigator.pop(context); final prefs = await SharedPreferences.getInstance(); await prefs.clear(); if (!mounted) return; Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false); }),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({required IconData icon, required String label, required VoidCallback onTap, bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: isLogout ? Colors.redAccent : Colors.transparent, 
        borderRadius: BorderRadius.circular(12), 
        boxShadow: isLogout ? [BoxShadow(color: Colors.redAccent.withOpacity(0.3), blurRadius: 8, spreadRadius: 1)] : null,
      ),
      child: ListTile(
        leading: Icon(icon, color: isLogout ? Colors.white : textSub, size: 22),
        title: Text(label, style: TextStyle(color: isLogout ? Colors.white : textMain, fontWeight: FontWeight.bold, fontSize: 15)),
        trailing: Icon(Icons.arrow_forward_ios, color: isLogout ? Colors.white70 : const Color(0xFF555555), size: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GlobalTouchWrapper(
      child: Scaffold(
      backgroundColor: bgMain,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text(
          "👑 Xyler Project",
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w900,
            fontSize: 22,
            fontFamily: 'Orbitron',
            letterSpacing: 2.5,
          ),
        ),
        centerTitle: false,
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        actions: [
          IconButton(
            icon: const Icon(Icons.headset_mic_outlined, color: Colors.black87),
            tooltip: 'Customer Service',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage())),
          ),
          IconButton(
            icon: const Icon(FontAwesomeIcons.userCircle, color: Colors.black87),
            tooltip: 'My Profile',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey))),
          ),
        ],
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(color: bgMain),
        child: SafeArea(child: FadeTransition(opacity: _animation, child: _selectedPage)),
      ),
      extendBody: true,
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
          child: SizedBox(
            height: 76,
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.topCenter,
              children: [
                // --- Bar dasar dengan lekukan cekung di tengah ---
                Positioned.fill(
                  top: 22,
                  child: CustomPaint(
                    painter: _NotchedNavBarPainter(
                      backgroundColor: Colors.white.withOpacity(0.97),
                      borderColor: Colors.black,
                    ),
                    child: ClipPath(
                      clipper: _NotchedNavBarClipper(),
                      child: Material(
                        color: Colors.transparent,
                        child: BottomNavigationBar(
                          elevation: 0,
                          backgroundColor: Colors.transparent,
                          selectedItemColor: Colors.black87,
                          unselectedItemColor: textSub,
                          currentIndex: _bottomNavIndex,
                          onTap: _onBottomNavTapped,
                          showSelectedLabels: false,
                          showUnselectedLabels: false,
                          type: BottomNavigationBarType.fixed,
                          items: const [
                            BottomNavigationBarItem(icon: Icon(Icons.home_outlined), activeIcon: Icon(Icons.home), label: "Home"),
                            BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.whatsapp), label: "WhatsApp"),
                            BottomNavigationBarItem(icon: SizedBox.shrink(), label: ""),
                            BottomNavigationBarItem(icon: Icon(Icons.notifications_none), activeIcon: Icon(Icons.notifications), label: "Info"),
                            BottomNavigationBarItem(icon: Icon(Icons.build_circle_outlined), activeIcon: Icon(Icons.build_circle), label: "Tools"),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                // --- Tombol tengah melingkar mengambang -> DeviceDashboardPage ---
                Positioned(
                  top: 0,
                  child: GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => DeviceDashboardPage(sessionKey: sessionKey)),
                    ),
                    child: Container(
                      width: 62,
                      height: 62,
                      padding: const EdgeInsets.all(3),
                      decoration: const BoxDecoration(
                        color: bgMain,
                        shape: BoxShape.circle,
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.black, width: 1.5),
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
  Color(0xFF4ADE80),
  Color(0xFF16A34A),
],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: accentWhite.withOpacity(0.35),
                              blurRadius: 12,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: const Icon(Icons.dashboard_customize_rounded, color: Colors.white, size: 26),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      ),
    );
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _newsTimer?.cancel();
    _newsPageController.dispose();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    super.dispose();
  }
}

class _QuickActionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;
  final VoidCallback onTap;

  const _QuickActionCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 280,
        margin: const EdgeInsets.only(right: 14),
        decoration: BoxDecoration(
          color: colors.first,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Colors.black, width: 1.5),
          boxShadow: [
            // Neubrutalism: hard offset shadow
            const BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(4, 4)),
            BoxShadow(
              color: colors.first.withOpacity(0.25),
              blurRadius: 12,
              spreadRadius: 0,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -24,
              bottom: -24,
              child: Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.22),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(icon, color: Colors.white, size: 22),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          "Buka",
                          style: TextStyle(
                            color: colors.first,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title.toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.3,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 11,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Menghasilkan path bar dengan lekukan (notch) setengah lingkaran
/// yang cekung ke dalam di bagian tengah-atas, sebagai dudukan
/// untuk tombol tengah yang melingkar.
Path _buildNotchedNavBarPath(Size size) {
  const double radius = 30; // radius sudut bar
  const double notchRadius = 34; // radius lekukan cekung
  final double centerX = size.width / 2;

  final path = Path();
  path.moveTo(0, radius);
  path.quadraticBezierTo(0, 0, radius, 0);

  // Garis lurus menuju awal lekukan
  path.lineTo(centerX - notchRadius - 6, 0);

  // Lekukan cekung (busur ke bawah lalu naik lagi) membentuk "U" halus
  path.arcToPoint(
    Offset(centerX + notchRadius + 6, 0),
    radius: const Radius.circular(notchRadius),
    clockwise: false,
  );

  path.lineTo(size.width - radius, 0);
  path.quadraticBezierTo(size.width, 0, size.width, radius);
  path.lineTo(size.width, size.height - radius);
  path.quadraticBezierTo(size.width, size.height, size.width - radius, size.height);
  path.lineTo(radius, size.height);
  path.quadraticBezierTo(0, size.height, 0, size.height - radius);
  path.close();
  return path;
}

class _NotchedNavBarClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) => _buildNotchedNavBarPath(size);

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

class _NotchedNavBarPainter extends CustomPainter {
  final Color backgroundColor;
  final Color borderColor;

  _NotchedNavBarPainter({required this.backgroundColor, required this.borderColor});

  @override
  void paint(Canvas canvas, Size size) {
    final path = _buildNotchedNavBarPath(size);

    // Neubrutalism: hard offset shadow di belakang bentuk
    final shadowPath = path.shift(const Offset(4, 4));
    canvas.drawPath(shadowPath, Paint()..color = Colors.black);

    // Soft shadow tambahan
    canvas.drawShadow(path.shift(const Offset(0, 6)), Colors.black.withOpacity(0.15), 16, false);

    // Isi bar
    canvas.drawPath(path, Paint()..color = backgroundColor);

    // Border outline
    canvas.drawPath(
      path,
      Paint()
        ..color = borderColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
  }

  @override
  bool shouldRepaint(covariant _NotchedNavBarPainter oldDelegate) =>
      oldDelegate.backgroundColor != backgroundColor || oldDelegate.borderColor != borderColor;
}

class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    if (url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov")) {
      return Container(color: Colors.black, child: const Center(child: Icon(Icons.videocam_off, color: Colors.grey, size: 50)));
    }
    return Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: const Color(0xFF1C1C1E), child: const Center(child: Icon(Icons.broken_image, color: Colors.grey))));
  }
}
