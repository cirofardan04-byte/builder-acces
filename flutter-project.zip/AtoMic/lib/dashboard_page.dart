import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:disk_space_plus/disk_space_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

// Import halaman lain
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'device_dashboard.dart';
import 'partner_page.dart';
import 'set.dart';
import 'tap.dart';
import 'moderator_page.dart';
import 'widgets/custom_popup.dart';
import 'global_chat_page.dart';

// ─── NEUBRUTALISM PALETTE ─────────────────────────────────────
class _NB {
  // Background
  static const bg = Color(0xFFFFFFFF);

  // Surfaces
  static const surface = Color(0xFFF5F3FF);
  static const card = Color(0xFFFAFAFA);

  // Borders
  static const border = Color(0xFF000000);

  // Ungu (default fallback, dipakai sebelum ThemeController selesai load)
  static const purpleMain = Color(0xFF7C3AED);
  static const purpleMid = Color(0xFF8B5CF6);
  static const purpleLight = Color(0xFFA78BFA);
  static const purplePale = Color(0xFFEDE9FE);

  // Pink (solid, not too thick)
  static const pinkMain = Color(0xFFEC4899);
  static const pinkMid = Color(0xFFF472B6);
  static const pinkLight = Color(0xFFF9A8D4);
  static const pinkPale = Color(0xFFFCE7F3);

  // Biru (solid, not too thick)
  static const blueMain = Color(0xFF3B82F6);
  static const blueMid = Color(0xFF60A5FA);
  static const blueLight = Color(0xFF93BBFC);
  static const bluePale = Color(0xFFDBEAFE);

  // Text
  static const text = Color(0xFF1A1A1A);
  static const textSub = Color(0xFF4B4B4B);
  static const textDim = Color(0xFF888888);

  // Status
  static const green = Color(0xFF059669);
  static const red = Color(0xFFDC2626);
  static const orange = Color(0xFFF59E0B);
  static const amber = Color(0xFFFBBF24);

  // Gradien
  static const LinearGradient pinkGrad = LinearGradient(
    colors: [pinkMain, pinkMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient blueGrad = LinearGradient(
    colors: [blueMain, blueMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient amberGrad = LinearGradient(
    colors: [amber, orange],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── THEME PRESET MODEL ────────────────────────────────────────
class _ThemePreset {
  final String name;
  final Color main;
  final Color mid;
  final Color pale;
  const _ThemePreset({
    required this.name,
    required this.main,
    required this.mid,
    required this.pale,
  });
}

// ─── THEME CONTROLLER (Ganti Warna Dashboard) ──────────────────
// Singleton ChangeNotifier — begitu setTheme() dipanggil, seluruh
// widget yang mendengarkan (lewat addListener + setState) akan
// otomatis rebuild dengan warna baru. Pilihan warna disimpan
// permanen lewat SharedPreferences.
class ThemeController extends ChangeNotifier {
  ThemeController._internal();
  static final ThemeController instance = ThemeController._internal();

  static const String _prefsKey = 'dashboard_theme_index';

  static const List<_ThemePreset> presets = [
    _ThemePreset(name: "Ungu", main: Color(0xFF7C3AED), mid: Color(0xFF8B5CF6), pale: Color(0xFFEDE9FE)),
    _ThemePreset(name: "Biru", main: Color(0xFF3B82F6), mid: Color(0xFF60A5FA), pale: Color(0xFFDBEAFE)),
    _ThemePreset(name: "Pink", main: Color(0xFFEC4899), mid: Color(0xFFF472B6), pale: Color(0xFFFCE7F3)),
    _ThemePreset(name: "Hijau", main: Color(0xFF059669), mid: Color(0xFF34D399), pale: Color(0xFFD1FAE5)),
    _ThemePreset(name: "Amber", main: Color(0xFFF59E0B), mid: Color(0xFFFBBF24), pale: Color(0xFFFEF3C7)),
    _ThemePreset(name: "Merah", main: Color(0xFFDC2626), mid: Color(0xFFF87171), pale: Color(0xFFFEE2E2)),
  ];

  int _index = 0;
  int get index => _index;

  Color get main => presets[_index].main;
  Color get mid => presets[_index].mid;
  Color get pale => presets[_index].pale;

  LinearGradient get gradient => LinearGradient(
        colors: [main, mid],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  bool _loaded = false;
  bool get isLoaded => _loaded;

  Future<void> load() async {
    if (_loaded) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getInt(_prefsKey);
      if (saved != null && saved >= 0 && saved < presets.length) {
        _index = saved;
      }
    } catch (_) {
      // Kalau gagal baca prefs, tetap pakai default index 0
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> setTheme(int i) async {
    if (i < 0 || i >= presets.length) return;
    _index = i;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_prefsKey, i);
    } catch (_) {
      // Simpan gagal tidak masalah, warna tetap berubah untuk sesi ini
    }
  }
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  WebSocketChannel? channel;

  // --- State Variabel ---
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // --- Variabel System Status Card ---
  String _deviceModel = "Unknown";
  int _sdkInt = 0;
  int _batteryLevel = 0;
  bool _isCharging = false;
  String _networkType = "Unknown";
  double _networkSignalPct = 0;
  double _storageUsedGB = 0;
  double _storageTotalGB = 0;
  int _appMemoryMB = 0;
  Timer? _clockTimer;
  Timer? _statusPollTimer;
  String _currentTimeText = "";
  final Battery _battery = Battery();
  StreamSubscription<BatteryState>? _batterySub;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;

  // --- Variabel Banner/News ---
  late PageController _newsPageController;
  double _currentNewsPage = 0.0;
  Timer? _newsTimer;
  VideoPlayerController? _videoController;

  // --- TEMA NEUBRUTALISM ---
  static const Color bgMain = _NB.bg;
  static const Color bgSurface = _NB.surface;
  static const Color bgCard = _NB.card;
  static const Color textMain = _NB.text;
  static const Color textSub = _NB.textSub;

  static const Color borderLight = _NB.border;
  static const Color borderGlass = _NB.border;

  @override
  void initState() {
    super.initState();

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    // ── Dengarkan perubahan tema — begitu ganti warna, dashboard rebuild ──
    ThemeController.instance.addListener(_onThemeChanged);
    ThemeController.instance.load();

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController?.setVolume(1.0);
        _videoController?.setLooping(true);
        _videoController?.play();
      });

    _initNewsBanner();
    _selectedPage = _buildNewsPage();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initSystemStatus();
  }

  void _onThemeChanged() {
    if (!mounted) return;
    setState(() {
      // Rebuild seluruh tree dashboard dengan warna tema terbaru,
      // termasuk _selectedPage kalau sedang menampilkan halaman news.
      if (_bottomNavIndex == 0) {
        _selectedPage = _buildNewsPage();
      }
    });
  }

  void _initNewsBanner() {
    _newsPageController = PageController(
      initialPage: 0,
      viewportFraction: 0.9,
    );

    _newsPageController.addListener(() {
      if (_newsPageController.hasClients && _newsPageController.page != null) {
        _currentNewsPage = _newsPageController.page!;
      }
    });

    if (newsList.isNotEmpty) {
      _newsTimer = Timer.periodic(const Duration(seconds: 5), (Timer timer) {
        if (_newsPageController.hasClients) {
          int targetIndex = (_currentNewsPage + 1).round() % newsList.length;
          _newsPageController.animateToPage(
            targetIndex,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
          );
        }
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      if (!mounted) return;
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    if (mounted) {
      setState(() {
        _deviceModel = deviceInfo.model;
        _sdkInt = deviceInfo.version.sdkInt;
      });
    }
    _connectToWebSocket();
  }

  // ─── SYSTEM STATUS CARD: init & refresh data (battery, storage, network, ram, jam) ───
  Future<void> _initSystemStatus() async {
    await _refreshSystemStatus();

    // Update jam tiap detik
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        final now = DateTime.now();
        _currentTimeText =
            "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";
      });
    });

    // Refresh storage & battery level tiap 30 detik (biar hemat resource)
    _statusPollTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _refreshSystemStatus();
    });

    // Dengar perubahan status charging real-time
    _batterySub = _battery.onBatteryStateChanged.listen((state) {
      if (!mounted) return;
      setState(() {
        _isCharging = state == BatteryState.charging || state == BatteryState.full;
      });
    });

    // Dengar perubahan koneksi network real-time
    _connectivitySub = Connectivity().onConnectivityChanged.listen((results) {
      if (!mounted) return;
      setState(() {
        _networkType = _mapConnectivityResult(
          results.isNotEmpty ? results.first : ConnectivityResult.none,
        );
      });
    });
  }

  Future<void> _refreshSystemStatus() async {
    try {
      final level = await _battery.batteryLevel;
      final state = await _battery.batteryState;
      final connResult = await Connectivity().checkConnectivity();
      final diskSpace = DiskSpacePlus();

final totalMB = await diskSpace.getTotalDiskSpace ?? 0;
final freeMB = await diskSpace.getFreeDiskSpace ?? 0;

      if (!mounted) return;
      setState(() {
        _batteryLevel = level;
        _isCharging = state == BatteryState.charging || state == BatteryState.full;
        _networkType = _mapConnectivityResult(
          connResult.isNotEmpty ? connResult.first : ConnectivityResult.none,
        );
        // DiskSpacePlus mengembalikan nilai dalam MB
        _storageTotalGB = totalMB / 1024;
_storageUsedGB = (totalMB - freeMB) / 1024;
        // Estimasi memori yang dipakai proses app ini (bukan RAM total device,
        // karena Flutter tidak punya akses native ke total RAM tanpa platform channel)
        _appMemoryMB = (ProcessInfo.currentRss / (1024 * 1024)).round();
      });
    } catch (_) {
      // Kalau ada plugin yang gagal (mis. belum ditambahkan ke pubspec), diamkan saja
      // supaya dashboard tetap jalan dengan data yang tersedia.
    }
  }

  String _mapConnectivityResult(ConnectivityResult result) {
    switch (result) {
      case ConnectivityResult.wifi:
        return "WiFi";
      case ConnectivityResult.mobile:
        return "Seluler";
      case ConnectivityResult.ethernet:
        return "Ethernet";
      case ConnectivityResult.none:
        return "Offline";
      default:
        return "Unknown";
    }
  }

  // Hitung sisa hari dari expiredDate (format "M/d/yyyy"). Aman terhadap format aneh.
  ({int days, double progress}) _calculateRemaining() {
    try {
      final parts = expiredDate.split('/');
      if (parts.length != 3) return (days: 0, progress: 1.0);
      final month = int.parse(parts[0]);
      final day = int.parse(parts[1]);
      final year = int.parse(parts[2]);
      final expiry = DateTime(year, month, day);
      final now = DateTime.now();
      final remainingDays = expiry.difference(now).inDays;
      // Progress bar di-cap biar tidak error kalau expiry-nya jauh sekali (mis. 99999)
      const capDays = 365;
      final progress = remainingDays <= 0
          ? 0.0
          : (remainingDays > capDays ? 1.0 : remainingDays / capDays);
      return (days: remainingDays < 0 ? 0 : remainingDays, progress: progress);
    } catch (_) {
      return (days: 0, progress: 0.0);
    }
  }

  void _connectToWebSocket() {
  channel = WebSocketChannel.connect(
    Uri.parse('http://hamapanelbego.duckdns.top:4951'),
  );

  channel!.sink.add(
    jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }),
  );

  channel!.sink.add(
    jsonEncode({
      "type": "stats",
    }),
  );

  channel!.stream.listen((event) {
    final data = jsonDecode(event);

    if (data['type'] == 'myInfo') {
      if (data['valid'] == false) {
        if (data['reason'] == 'androidIdMismatch') {
          _handleInvalidSession(
            "Your account has logged on another device.",
          );
        } else if (data['reason'] == 'keyInvalid') {
          _handleInvalidSession(
            "Key is not valid. Please login again.",
          );
        }
      }
    }

    if (data['type'] == 'stats') {
      if (!mounted) return;

      setState(() {
        onlineUsers = data['onlineUsers'] ?? 0;
        activeConnections = data['activeConnections'] ?? 0;
      });
    }
  });
}

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    CustomPopup.show(
      context,
      title: "Session Expired",
      message: message,
      icon: Icons.error_outline,
      iconColor: _NB.red,
      confirmText: "OK",
      onConfirm: () {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginPage()),
          (route) => false,
        );
      },
    );
  }

  void _onBottomNavTapped(int index) {
    if (index == 1) {
      _showWhatsAppMenu();
      return;
    }
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 3) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 4) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      }
    });
  }

  void _showWhatsAppMenu() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: Dialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: _NB.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _NB.border, width: 2),
                boxShadow: const [
                  BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _NB.pinkPale,
                      shape: BoxShape.circle,
                      border: Border.all(color: _NB.border, width: 2),
                    ),
                    child: const Icon(FontAwesomeIcons.whatsapp, size: 36, color: _NB.pinkMain),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "WHATSAPP TOOLS",
                    style: TextStyle(
                      color: _NB.text,
                      fontFamily: 'Orbitron',
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.0,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Choose an action to perform",
                    style: TextStyle(color: _NB.textSub, fontSize: 13),
                  ),
                  const SizedBox(height: 24),
                  _buildWhatsAppOption(
                    icon: Icons.bug_report,
                    color: _NB.pinkMain,
                    title: "WhatsApp Crash",
                    subtitle: "Send payloads & crash codes",
                    onTap: () {
                      Navigator.pop(context);
                      setState(() {
                        _bottomNavIndex = 1;
                        _selectedPage = HomePage(
                          username: username,
                          password: password,
                          listBug: listBug,
                          role: role,
                          expiredDate: expiredDate,
                          sessionKey: sessionKey,
                        );
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  _buildWhatsAppOption(
                    icon: Icons.devices,
                    color: _NB.blueMain,
                    title: "Manage Sender",
                    subtitle: "Pair devices & manage sessions",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role)));
                    },
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        foregroundColor: _NB.text,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: const BorderSide(color: _NB.border, width: 2),
                        ),
                      ),
                      child: const Text("Cancel", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15, color: _NB.textSub)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildWhatsAppOption({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: _NB.border, width: 1.5),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: _NB.border, width: 1.5),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: _NB.text,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: _NB.textSub,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: _NB.textDim, size: 14),
          ],
        ),
      ),
    );
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 2) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 4) {
        _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 5) {
        _selectedPage = ModeratorPage(
          sessionKey: sessionKey,
          username: username,
        );
      }
    });
    Navigator.pop(context);
  }

  // ============================================================
  // OTAX DASHBOARD HEADER + ACCESS ROLE CARD
  // ============================================================

  String _getGreetingPeriod() {
    final hour = DateTime.now().hour;
    if (hour >= 4 && hour < 6) return "Subuh";
    if (hour >= 6 && hour < 11) return "Pagi";
    if (hour >= 11 && hour < 15) return "Siang";
    if (hour >= 15 && hour < 18) return "Sore";
    return "Malam";
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "founder":
      case "developer":
      case "ceo":
      case "tk":
      case "high owner":
      case "owner":
      case "vip":
        return ThemeController.instance.main;
      case "moderator":
        return _NB.blueMain;
      case "partner":
        return _NB.pinkMain;
      case "admin":
        return ThemeController.instance.mid;
      case "reseller":
        return _NB.blueMid;
      default:
        return _NB.textSub;
    }
  }

  // ============================================================
  // BANNER — NEUBRUTALISM VERSION
  // ============================================================
  Widget _buildOtaxDashboardBanner() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: _NB.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _NB.border, width: 2.5),
          boxShadow: const [
            BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(6, 6)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(13.5),
          child: Stack(
            children: [
              // ── FOTO BANNER ──────────────────────────────────
              SizedBox(
                height: 190,
                width: double.infinity,
                child: Image.asset(
                  'assets/images/banner.jpg',
                  fit: BoxFit.cover,
                ),
              ),

              // ── OVERLAY GRADIENT RINGAN (biar teks kebaca) ───
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.05),
                        Colors.black.withOpacity(0.55),
                      ],
                    ),
                  ),
                ),
              ),

              // ── BADGE "ONLINE" ala sticker neubrutalism ──────
              Positioned(
                top: 14,
                left: 14,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: _NB.card,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _NB.border, width: 1.5),
                    boxShadow: const [
                      BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(2.5, 2.5)),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 7,
                        height: 7,
                        decoration: const BoxDecoration(
                          color: _NB.green,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Text(
                        "ONLINE",
                        style: TextStyle(
                          color: _NB.text,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // ── BADGE CROWN kanan atas (warna ikut tema) ─────
              Positioned(
                top: 14,
                right: 14,
                child: Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: ThemeController.instance.main,
                    shape: BoxShape.circle,
                    border: Border.all(color: _NB.border, width: 1.5),
                    boxShadow: const [
                      BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(2.5, 2.5)),
                    ],
                  ),
                  child: const Icon(Icons.workspace_premium_rounded, color: Colors.white, size: 18),
                ),
              ),

              // ── TITLE CARD (kartu putih solid di bawah foto) ─
              Positioned(
                left: 14,
                right: 14,
                bottom: 14,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _NB.border, width: 2),
                    boxShadow: const [
                      BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(3, 3)),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "PXL PROJECT V3",
                            style: TextStyle(
                              color: _NB.text,
                              fontSize: 19,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            "© By Jaa Cool",
                            style: TextStyle(
                              color: _NB.textSub,
                              fontSize: 10,
                              letterSpacing: 0.6,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: ThemeController.instance.pale,
                          shape: BoxShape.circle,
                          border: Border.all(color: _NB.border, width: 1.5),
                        ),
                        child: Icon(Icons.bolt_rounded, color: ThemeController.instance.main, size: 18),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRoleButtonCard({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _NB.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _NB.border, width: 2),
            boxShadow: const [
              BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: _NB.border, width: 1.5),
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(color: _NB.text, fontWeight: FontWeight.bold, fontSize: 15)),
                    const SizedBox(height: 2),
                    Text(subtitle, style: const TextStyle(color: _NB.textSub, fontSize: 12)),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: color, size: 22),
            ],
          ),
        ),
      ),
    );
  }

  void _navigateToRolePage(int index) {
    setState(() {
      if (index == 1) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 2) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 4) {
        _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      } else if (index == 5) {
        _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username);
      }
    });
  }

  List<Widget> _buildRoleActionButtons() {
    final List<Widget> buttons = [];
    final r = role.toLowerCase();

    if (r == "owner" ||
        r == "founder" ||
        r == "developer" ||
        r == "ceo" ||
        r == "tk" ||
        r == "high owner" ||
        r == "vip") {
      buttons.add(_buildRoleButtonCard(
        icon: Icons.workspace_premium,
        color: ThemeController.instance.main,
        title: "Create Account",
        subtitle: "Khusus Role Owner Ke Atas",
        onTap: () => _navigateToRolePage(3),
      ));
    }
    if (r == "reseller" || r == "founder") {
      buttons.add(_buildRoleButtonCard(
        icon: Icons.storefront,
        color: _NB.blueMain,
        title: "Reseller Page",
        subtitle: "Akses & Kelola Halaman Reseller",
        onTap: () => _navigateToRolePage(1),
      ));
    }
    if (r == "founder" || r == "admin") {
      buttons.add(_buildRoleButtonCard(
        icon: Icons.admin_panel_settings,
        color: ThemeController.instance.mid,
        title: "Admin Page",
        subtitle: "Akses & Kelola Halaman Admin",
        onTap: () => _navigateToRolePage(2),
      ));
    }
    if (r == "founder" || r == "partner") {
      buttons.add(_buildRoleButtonCard(
        icon: FontAwesomeIcons.handshake,
        color: _NB.pinkMain,
        title: "Partner Page",
        subtitle: "Akses & Kelola Halaman Partner",
        onTap: () => _navigateToRolePage(4),
      ));
    }
    if (r == "founder" || r == "moderator") {
      buttons.add(_buildRoleButtonCard(
        icon: FontAwesomeIcons.userShield,
        color: _NB.blueMain,
        title: "Moderator Page",
        subtitle: "Akses & Kelola Halaman Moderator",
        onTap: () => _navigateToRolePage(5),
      ));
    }
    return buttons;
  }

  Widget _buildAccessRoleCard() {
    final roleButtons = _buildRoleActionButtons();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Selamat ${_getGreetingPeriod()}, $username!!",
              style: const TextStyle(color: _NB.text, fontSize: 21, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
            ),
            const SizedBox(height: 10),
            Container(
              width: 60,
              height: 4,
              decoration: BoxDecoration(
                color: _NB.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text("Access Role : ", style: TextStyle(color: _NB.textSub, fontSize: 14, fontWeight: FontWeight.w600)),
                Text(
                  role.toUpperCase(),
                  style: TextStyle(
                    color: _getRoleColor(role),
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
            if (roleButtons.isNotEmpty) ...roleButtons,
            const SizedBox(height: 20),
            const Text(
              "Selamat datang kembali di Pxl Project. Kami hadir membawa pembaruan masif untuk sistem manajemen dan tools eksklusif. Nikmati navigasi baru yang lebih mulus dan performa yang ditingkatkan untuk kebutuhan operasional kamu.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                color: _NB.text,
                fontSize: 12.5,
                height: 1.6,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── SYSTEM STATUS CARD (Role, Expired, Online, Device, Battery, Network, RAM, Storage, System, Session, Conn, Time) ───
  Widget _buildSystemStatusCard() {
    final remaining = _calculateRemaining();
    final shortSession = sessionKey.length > 8 ? sessionKey.substring(0, 8) : sessionKey;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: _NB.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _NB.border, width: 2),
          boxShadow: const [
            BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(5, 5)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: ThemeController.instance.main,
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      "DASHBOARD",
                      style: TextStyle(
                        color: _NB.text,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: _NB.green.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _NB.green, width: 1.5),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.check_circle, size: 14, color: _NB.green),
                      SizedBox(width: 4),
                      Text("ACTIVE", style: TextStyle(color: _NB.green, fontWeight: FontWeight.w800, fontSize: 11)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),

            // Remaining time
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("Remaining Time", style: TextStyle(color: _NB.textSub, fontSize: 12, fontWeight: FontWeight.w600)),
                Text(
                  "${remaining.days} Days Left",
                  style: TextStyle(color: ThemeController.instance.main, fontSize: 12, fontWeight: FontWeight.w800),
                ),
              ],
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: remaining.progress.clamp(0.0, 1.0),
                minHeight: 8,
                backgroundColor: _NB.surface,
                valueColor: AlwaysStoppedAnimation(ThemeController.instance.main),
              ),
            ),
            const SizedBox(height: 18),

            // Grid stats
            _statusGridRow([
              _MiniStatBox(icon: Icons.badge_outlined, label: "ROLE", value: role.toUpperCase()),
              _MiniStatBox(icon: Icons.event_busy_outlined, label: "EXPIRED", value: expiredDate),
              _MiniStatBox(icon: Icons.people_alt_outlined, label: "ONLINE", value: "$onlineUsers Users"),
            ]),
            const SizedBox(height: 10),
            _statusGridRow([
              _MiniStatBox(icon: Icons.phone_android_rounded, label: "DEVICE", value: _deviceModel),
              _MiniStatBox(
                icon: _isCharging ? Icons.battery_charging_full_rounded : Icons.battery_std_rounded,
                label: "BATTERY",
                value: "$_batteryLevel%${_isCharging ? ' ⚡' : ''}",
              ),
              _MiniStatBox(icon: Icons.wifi_rounded, label: "NETWORK", value: _networkType),
            ]),
            const SizedBox(height: 10),
            _statusGridRow([
              _MiniStatBox(icon: Icons.memory_rounded, label: "APP RAM", value: "$_appMemoryMB MB"),
              _MiniStatBox(
                icon: Icons.storage_rounded,
                label: "STORAGE",
                value: "${_storageUsedGB.toStringAsFixed(1)}/${_storageTotalGB.toStringAsFixed(0)} GB",
              ),
              _MiniStatBox(icon: Icons.system_security_update_good_rounded, label: "SYSTEM", value: "API $_sdkInt"),
            ]),
            const SizedBox(height: 10),
            _statusGridRow([
              _MiniStatBox(icon: Icons.vpn_key_rounded, label: "SESSION", value: shortSession),
              _MiniStatBox(icon: Icons.cable_rounded, label: "CONN", value: "$activeConnections Active"),
              _MiniStatBox(icon: Icons.access_time_rounded, label: "TIME", value: _currentTimeText),
            ]),
            const SizedBox(height: 16),

            // Badge LIVE
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _NB.green,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _NB.border, width: 1.5),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.circle, size: 8, color: Colors.white),
                  SizedBox(width: 6),
                  Text("LIVE", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusGridRow(List<Widget> children) {
    return Row(
      children: [
        for (int i = 0; i < children.length; i++) ...[
          if (i != 0) const SizedBox(width: 10),
          Expanded(child: children[i]),
        ],
      ],
    );
  }

  // Preview card global chat yang akan ditampilkan di dashboard
  Widget _buildGlobalChatPreview() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.only(left: 10),
            decoration: const BoxDecoration(
              border: Border(left: BorderSide(color: _NB.border, width: 3.5)),
            ),
            child: Row(
              children: const [
                Icon(Icons.groups_2_rounded, color: _NB.text, size: 20),
                SizedBox(width: 8),
                Text(
                  "GLOBAL CHAT",
                  style: TextStyle(
                    color: _NB.text,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: 60,
            height: 4,
            decoration: BoxDecoration(
              color: _NB.border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            "Ngobrol langsung dengan semua pengguna Pxl di satu ruangan.",
            style: TextStyle(color: _NB.textSub, fontSize: 12, height: 1.4),
          ),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => GlobalChatPage(
                  username: username,
                  sessionKey: sessionKey,
                  androidId: androidId,
                ),
              ),
            ),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: _NB.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _NB.border, width: 2),
                boxShadow: const [
                  BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: ThemeController.instance.pale,
                      shape: BoxShape.circle,
                      border: Border.all(color: _NB.border, width: 1.5),
                    ),
                    child: Icon(Icons.groups_2_rounded,
                        size: 22, color: ThemeController.instance.main),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Community Room",
                          style: TextStyle(
                            color: _NB.text,
                            fontWeight: FontWeight.w800,
                            fontSize: 13.5,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            Container(
                              width: 7,
                              height: 7,
                              decoration: const BoxDecoration(
                                color: _NB.green,
                                shape: BoxShape.circle,
                                border: Border.fromBorderSide(BorderSide(color: _NB.border, width: 0.5)),
                              ),
                            ),
                            const SizedBox(width: 5),
                            const Text(
                              "Tap untuk masuk ke ruang chat",
                              style: TextStyle(
                                color: _NB.textSub,
                                fontSize: 12,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: ThemeController.instance.pale,
                      shape: BoxShape.circle,
                      border: Border.all(color: _NB.border, width: 1.5),
                    ),
                    child: Icon(Icons.arrow_forward_rounded,
                        color: ThemeController.instance.main, size: 20),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNewsPage() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _buildOtaxDashboardBanner(),
          const SizedBox(height: 24),
          _buildAccessRoleCard(),
          const SizedBox(height: 24),
          _buildSystemStatusCard(),
          const SizedBox(height: 30),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.only(left: 10),
                  decoration: const BoxDecoration(
                    border: Border(left: BorderSide(color: _NB.border, width: 3.5)),
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.calendar_month_rounded, color: _NB.text, size: 20),
                      SizedBox(width: 8),
                      Text("LATEST UPDATE", style: TextStyle(color: _NB.text, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 1.2)),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: 60,
                  height: 4,
                  decoration: BoxDecoration(
                    color: _NB.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 10),
                const Text("Keep yourself informed about recent system maintenance, newly added tools, and important announcements from the administration.", style: TextStyle(color: _NB.textSub, fontSize: 12, height: 1.4)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            height: 180,
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Stack(
              children: [
                PageView.builder(
                  controller: _newsPageController,
                  itemCount: newsList.length,
                  itemBuilder: (context, index) {
                    final item = newsList[index];
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: _NB.card,
                        border: Border.all(color: _NB.border, width: 2),
                        boxShadow: const [
                          BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            if (item['image'] != null &&
                                item['image'].toString().isNotEmpty)
                              NewsMedia(url: item['image']),
                            if (item['image'] == null)
                              Container(color: _NB.card, child: const Icon(Icons.newspaper, color: _NB.textDim, size: 50)),
                            Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.black.withOpacity(0.8),
                                    Colors.transparent,
                                  ],
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 30,
                              left: 20,
                              right: 16,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['title'] ?? 'No Title',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item['desc'] ?? '',
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.85),
                                      fontSize: 13,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                Positioned(
                  bottom: 8,
                  left: 0,
                  right: 0,
                  child: AnimatedBuilder(
                    animation: _newsPageController,
                    builder: (context, child) {
                      double currentNewsPage = 0.0;
                      if (_newsPageController.hasClients && _newsPageController.page != null) {
                        currentNewsPage = _newsPageController.page!;
                      } else {
                        currentNewsPage = _currentNewsPage;
                      }

                      return Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(newsList.length, (index) {
                          double diff = (index - currentNewsPage).abs();
                          double width = 5.0;
                          double opacity = 0.3;

                          if (diff < 1) {
                            width = 25.0 - (diff * 20.0);
                            opacity = 1.0 - (diff * 0.7);
                          }

                          return Container(
                            margin: const EdgeInsets.symmetric(horizontal: 2.5),
                            width: width,
                            height: 5,
                            decoration: BoxDecoration(
                              color: _NB.border.withOpacity(opacity),
                              borderRadius: BorderRadius.circular(5),
                            ),
                          );
                        }),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.only(left: 10),
                  decoration: const BoxDecoration(
                    border: Border(left: BorderSide(color: _NB.border, width: 3.5)),
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.flash_on_rounded, color: _NB.text, size: 20),
                      SizedBox(width: 8),
                      Text("QUICK ACTIONS", style: TextStyle(color: _NB.text, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 1.2)),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: 60,
                  height: 4,
                  decoration: BoxDecoration(
                    color: _NB.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 10),
                const Text("Akses cepat ke fitur-fitur utama aplikasi.", style: TextStyle(color: _NB.textSub, fontSize: 12, height: 1.4)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 168,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              children: [
                _QuickActionCard(
                  title: "Bug Sender",
                  subtitle: "Pairing & Configuration",
                  icon: Icons.bug_report_rounded,
                  colors: const [_NB.pinkMain, _NB.pinkMid],
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role))),
                ),
                _QuickActionCard(
                  title: "Riwayat Aktivitas",
                  subtitle: "Lihat Histori Aktivitas Kamu",
                  icon: Icons.history_rounded,
                  colors: const [_NB.blueMain, _NB.blueMid],
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role))),
                ),
                _QuickActionCard(
                  title: "Profile Saya",
                  subtitle: "Kelola Akun & Data Kamu",
                  icon: Icons.person_rounded,
                  colors: [ThemeController.instance.main, ThemeController.instance.mid],
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey))),
                ),
                _QuickActionCard(
                  title: "Contact Us",
                  subtitle: "Hubungi Tim Support",
                  icon: Icons.contact_support_rounded,
                  colors: const [_NB.pinkMain, _NB.pinkMid],
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage())),
                ),
                _QuickActionCard(
                  title: "Info & Bantuan",
                  subtitle: "Panduan Penggunaan App",
                  icon: Icons.info_rounded,
                  colors: const [_NB.blueMain, _NB.blueMid],
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => InfoPage(sessionKey: sessionKey))),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
          _buildGlobalChatPreview(),
          const SizedBox(height: 30),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.only(left: 10),
                  decoration: const BoxDecoration(
                    border: Border(left: BorderSide(color: _NB.border, width: 3.5)),
                  ),
                  child: const Text("COMMUNITY HUB", style: TextStyle(color: _NB.text, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 1.2)),
                ),
                const SizedBox(height: 6),
                const Text("Stay connected with the OTOMIX community. Get real-time updates, access exclusive payloads, and participate in discussions with other members.", style: TextStyle(color: _NB.textSub, fontSize: 12, height: 1.4)),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  height: 55,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(color: ThemeController.instance.main.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4)),
                    ],
                  ),
                  child: ElevatedButton.icon(
                    icon: const Icon(FontAwesomeIcons.telegram, color: Colors.white, size: 20),
                    label: const Text("Join Telegram Channel", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 1.0)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ThemeController.instance.main,
                      shadowColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: const BorderSide(color: _NB.border, width: 2),
                      ),
                    ),
                    onPressed: () => _openUrl("https://t.me/alexandernotdev"),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 100),
        ],
      ),
    );
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: _NB.bg,
      width: MediaQuery.of(context).size.width * 0.55,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 180,
            decoration: BoxDecoration(
              color: _NB.bg,
              border: Border(
                bottom: BorderSide(color: _NB.border, width: 2),
              ),
            ),
            child: SafeArea(
              child: Center(
                child: Image.asset(
                  'assets/images/logo.png',
                  width: 120,
                  height: 120,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: _NB.bg,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 10),
                children: [
                  if (role == "reseller") _buildDrawerMenuItem(icon: Icons.storefront, label: "Seller Page", onTap: () => _onSidebarTabSelected(1)),
                  if (role == "admin") _buildDrawerMenuItem(icon: Icons.admin_panel_settings, label: "Admin Page", onTap: () => _onSidebarTabSelected(2)),
                  if (role == "partner") _buildDrawerMenuItem(icon: FontAwesomeIcons.handshake, label: "Partner Page", onTap: () => _onSidebarTabSelected(4)),
                  if (role == "moderator") _buildDrawerMenuItem(icon: FontAwesomeIcons.userShield, label: "Moderator Page", onTap: () => _onSidebarTabSelected(5)),
                  if (role == "owner" ||
                      role == "founder" ||
                      role == "developer" ||
                      role == "high owner" ||
                      role == "ceo" ||
                      role == "tk" ||
                      role == "vip") _buildDrawerMenuItem(icon: Icons.workspace_premium, label: "Owner Page", onTap: () => _onSidebarTabSelected(3)),
                  _buildDrawerMenuItem(icon: Icons.history_rounded, label: "Riwayat Aktivitas", onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role))); }),
                  const SizedBox(height: 20),
                  _buildDrawerMenuItem(icon: Icons.logout, label: "Log Out", isLogout: true, onTap: () async { Navigator.pop(context); final prefs = await SharedPreferences.getInstance(); await prefs.clear(); if (!mounted) return; Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false); }),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({required IconData icon, required String label, required VoidCallback onTap, bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: isLogout ? _NB.red : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        border: isLogout ? Border.all(color: _NB.border, width: 2) : null,
        boxShadow: isLogout ? [BoxShadow(color: _NB.red.withOpacity(0.3), blurRadius: 8, spreadRadius: 1)] : null,
      ),
      child: ListTile(
        leading: Icon(icon, color: isLogout ? Colors.white : _NB.textSub, size: 22),
        title: Text(label, style: TextStyle(color: isLogout ? Colors.white : _NB.text, fontWeight: FontWeight.bold, fontSize: 15)),
        trailing: Icon(Icons.arrow_forward_ios, color: isLogout ? Colors.white70 : _NB.textDim, size: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        onTap: onTap,
      ),
    );
  }

  // ============================================================
  // THEME SWITCHER — FAB & BOTTOM SHEET
  // ============================================================
  Widget _buildThemeFab() {
    return GestureDetector(
      onTap: _showThemeSheet,
      child: Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: ThemeController.instance.main,
          border: Border.all(color: _NB.border, width: 2),
          boxShadow: const [
            BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(3, 3)),
          ],
        ),
        child: const Icon(Icons.palette_rounded, color: Colors.white, size: 22),
      ),
    );
  }

  void _showThemeSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (sheetContext, setModalState) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 38,
                      height: 4,
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: Colors.black12,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                  const Text(
                    "GANTI WARNA DASHBOARD",
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      letterSpacing: 1,
                      color: _NB.text,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    "Pilih skema warna, seluruh tampilan akan berubah otomatis.",
                    style: TextStyle(fontSize: 11, color: _NB.textSub),
                  ),
                  const SizedBox(height: 18),
                  Wrap(
                    spacing: 18,
                    runSpacing: 14,
                    children: List.generate(ThemeController.presets.length, (i) {
                      final preset = ThemeController.presets[i];
                      final active = ThemeController.instance.index == i;
                      return GestureDetector(
                        onTap: () {
                          ThemeController.instance.setTheme(i);
                          setModalState(() {});
                        },
                        child: Column(
                          children: [
                            Container(
                              width: 46,
                              height: 46,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: preset.main,
                                border: Border.all(
                                  color: active ? Colors.black : Colors.transparent,
                                  width: 2.5,
                                ),
                              ),
                              child: active
                                  ? const Icon(Icons.check_rounded, color: Colors.white, size: 20)
                                  : null,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              preset.name,
                              style: const TextStyle(
                                fontSize: 9.5,
                                fontWeight: FontWeight.w600,
                                color: _NB.textSub,
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GlobalTouchWrapper(
      child: Scaffold(
        backgroundColor: _NB.bg,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const Text(
            "👑 PXL PROJECT",
            style: TextStyle(
              color: _NB.text,
              fontWeight: FontWeight.w900,
              fontSize: 22,
              fontFamily: 'Orbitron',
              letterSpacing: 2.5,
            ),
          ),
          centerTitle: false,
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: const IconThemeData(color: _NB.text),
          actions: [
            IconButton(
              icon: const Icon(Icons.headset_mic_outlined, color: _NB.text),
              tooltip: 'Customer Service',
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage())),
            ),
            IconButton(
              icon: const Icon(FontAwesomeIcons.userCircle, color: _NB.text),
              tooltip: 'My Profile',
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey))),
            ),
          ],
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(color: _NB.bg),
          child: Stack(
            children: [
              SafeArea(child: FadeTransition(opacity: _animation, child: _selectedPage)),

              // ── TOMBOL GANTI WARNA (Theme Switcher FAB) ──────
              Positioned(
                right: 18,
                bottom: 110,
                child: SafeArea(
                  top: false,
                  child: _buildThemeFab(),
                ),
              ),
            ],
          ),
        ),
        extendBody: true,
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
            child: SizedBox(
              height: 76,
              child: Stack(
                clipBehavior: Clip.none,
                alignment: Alignment.topCenter,
                children: [
                  Positioned.fill(
                    top: 22,
                    child: CustomPaint(
                      painter: _NotchedNavBarPainter(
                        backgroundColor: Colors.white.withOpacity(0.97),
                        borderColor: _NB.border,
                      ),
                      child: ClipPath(
                        clipper: _NotchedNavBarClipper(),
                        child: Material(
                          color: Colors.transparent,
                          child: BottomNavigationBar(
                            elevation: 0,
                            backgroundColor: Colors.transparent,
                            selectedItemColor: ThemeController.instance.main,
                            unselectedItemColor: _NB.textSub,
                            currentIndex: _bottomNavIndex,
                            onTap: _onBottomNavTapped,
                            showSelectedLabels: false,
                            showUnselectedLabels: false,
                            type: BottomNavigationBarType.fixed,
                            items: const [
                              BottomNavigationBarItem(icon: Icon(Icons.home_outlined), activeIcon: Icon(Icons.home), label: "Home"),
                              BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.whatsapp), label: "WhatsApp"),
                              BottomNavigationBarItem(icon: SizedBox.shrink(), label: ""),
                              BottomNavigationBarItem(icon: Icon(Icons.notifications_none), activeIcon: Icon(Icons.notifications), label: "Info"),
                              BottomNavigationBarItem(icon: Icon(Icons.build_circle_outlined), activeIcon: Icon(Icons.build_circle), label: "Tools"),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 0,
                    child: GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => DeviceDashboardPage(sessionKey: sessionKey)),
                      ),
                      child: Container(
                        width: 62,
                        height: 62,
                        padding: const EdgeInsets.all(3),
                        decoration: const BoxDecoration(
                          color: _NB.bg,
                          shape: BoxShape.circle,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: _NB.border, width: 2),
                            gradient: ThemeController.instance.gradient,
                            boxShadow: [
                              BoxShadow(
                                color: ThemeController.instance.main.withOpacity(0.35),
                                blurRadius: 12,
                                offset: const Offset(0, 5),
                              ),
                            ],
                          ),
                          child: const Icon(Icons.dashboard_customize_rounded, color: Colors.white, size: 26),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    ThemeController.instance.removeListener(_onThemeChanged);
    _videoController?.dispose();
    _newsTimer?.cancel();
    _clockTimer?.cancel();
    _statusPollTimer?.cancel();
    _batterySub?.cancel();
    _connectivitySub?.cancel();
    _newsPageController.dispose();
    channel?.sink.close(status.goingAway);
    _controller.dispose();
    super.dispose();
  }
}

class _MiniStatBox extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _MiniStatBox({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: _NB.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _NB.border, width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 13, color: ThemeController.instance.main),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: _NB.textDim,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.4,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              color: _NB.text,
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

class _QuickActionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;
  final VoidCallback onTap;

  const _QuickActionCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 280,
        margin: const EdgeInsets.only(right: 14),
        decoration: BoxDecoration(
          color: colors.first,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _NB.border, width: 2),
          boxShadow: const [
            BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -24,
              bottom: -24,
              child: Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.22),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: _NB.border, width: 1.5),
                        ),
                        child: Icon(icon, color: Colors.white, size: 22),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: _NB.border, width: 1.5),
                        ),
                        child: Text(
                          "Buka",
                          style: TextStyle(
                            color: colors.first,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title.toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.3,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 11,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Path _buildNotchedNavBarPath(Size size) {
  const double radius = 30;
  const double notchRadius = 34;
  final double centerX = size.width / 2;

  final path = Path();
  path.moveTo(0, radius);
  path.quadraticBezierTo(0, 0, radius, 0);
  path.lineTo(centerX - notchRadius - 6, 0);
  path.arcToPoint(
    Offset(centerX + notchRadius + 6, 0),
    radius: const Radius.circular(notchRadius),
    clockwise: false,
  );
  path.lineTo(size.width - radius, 0);
  path.quadraticBezierTo(size.width, 0, size.width, radius);
  path.lineTo(size.width, size.height - radius);
  path.quadraticBezierTo(size.width, size.height, size.width - radius, size.height);
  path.lineTo(radius, size.height);
  path.quadraticBezierTo(0, size.height, 0, size.height - radius);
  path.close();
  return path;
}

class _NotchedNavBarClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) => _buildNotchedNavBarPath(size);

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

class _NotchedNavBarPainter extends CustomPainter {
  final Color backgroundColor;
  final Color borderColor;

  _NotchedNavBarPainter({required this.backgroundColor, required this.borderColor});

  @override
  void paint(Canvas canvas, Size size) {
    final path = _buildNotchedNavBarPath(size);

    final shadowPath = path.shift(const Offset(4, 4));
    canvas.drawPath(shadowPath, Paint()..color = _NB.border);

    canvas.drawShadow(path.shift(const Offset(0, 6)), Colors.black.withOpacity(0.15), 16, false);

    canvas.drawPath(path, Paint()..color = backgroundColor);

    canvas.drawPath(
      path,
      Paint()
        ..color = borderColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );
  }

  @override
  bool shouldRepaint(covariant _NotchedNavBarPainter oldDelegate) =>
      oldDelegate.backgroundColor != backgroundColor || oldDelegate.borderColor != borderColor;
}

class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    if (url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov")) {
      return Container(color: Colors.black, child: const Center(child: Icon(Icons.videocam_off, color: Colors.grey, size: 50)));
    }
    return Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: const Color(0xFF1C1C1E), child: const Center(child: Icon(Icons.broken_image, color: Colors.grey))));
  }
}