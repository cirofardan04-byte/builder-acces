import 'package:flutter/material.dart';
import 'set.dart';
import 'tap.dart';

class SplashVideoPage extends StatefulWidget {
  final Widget nextPage;
  final String username;

  const SplashVideoPage({
    super.key,
    required this.nextPage,
    required this.username,
  });

  @override
  State<SplashVideoPage> createState() => _SplashVideoPageState();
}

class _OnboardStep {
  final String badge;
  final String title;
  final String subtitle;
  final String buttonLabel;
  final bool filledButton;

  const _OnboardStep({
    required this.badge,
    required this.title,
    required this.subtitle,
    required this.buttonLabel,
    this.filledButton = false,
  });
}

class _SplashVideoPageState extends State<SplashVideoPage>
    with TickerProviderStateMixin {
  late final PageController _pageController;
  late final AnimationController _introController;
  late final AnimationController _pulseController;

  double _page = 0;
  bool _navigated = false;

  // ─── TEMA WARNA UNGU ─────────────────────────────────────────────
static const Color bgMain     = Color(0xFFE8DDF5);
static const Color bgCard     = Color(0xFFFFFFFF);
static const Color accentGreen = Color(0xFF6A1B9A);
static const Color borderGreen = Color(0xFFAB47BC);
static const Color textMain   = Colors.black87;
static const Color textSub    = Colors.black54;

  late final List<_OnboardStep> _steps = [
    _OnboardStep(
      badge: "Selamat Datang 👋",
      title: "Selamat Datang Di Apk Pxl\n${widget.username.toUpperCase()}",
      subtitle: "Nikmati Pengalaman Terbaik Bersama Kami",
      buttonLabel: "LANJUT",
    ),
    const _OnboardStep(
      badge: "TERIMA KASIH YA !!",
      title: "SETIA DENGAN KAMI",
      subtitle:
          "Terima kasih telah mensupport kami, walaupun terkadang project kami sering ampas / error, tapi kalian hebat selalu setia dengan Pxl Project",
      buttonLabel: "LANJUT",
    ),
    const _OnboardStep(
      badge: "ARE YOU READY??",
      title: "ENTER DASHBOARD",
      subtitle: "Putar musiknya rayakan bersama bro!!",
      buttonLabel: "MULAI SEKARANG",
      filledButton: true,
    ),
  ];

  @override
  void initState() {
    super.initState();

    _pageController = PageController()
      ..addListener(() {
        setState(() {
          _page = _pageController.page ?? 0;
        });
      });

    _introController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..forward();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pageController.dispose();
    _introController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  int get _currentIndex => _page.round().clamp(0, _steps.length - 1);

  void _next() {
    if (_currentIndex < _steps.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 550),
        curve: Curves.easeOutCubic,
      );
    } else {
      _goNext();
    }
  }

  void _skip() => _goNext();

  void _goNext() {
    if (_navigated) return;
    _navigated = true;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 650),
        pageBuilder: (_, animation, __) => widget.nextPage,
        transitionsBuilder: (_, animation, __, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );
          return FadeTransition(
            opacity: curved,
            child: ScaleTransition(
              scale: Tween(begin: 0.97, end: 1.0).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  // interval helper – animasi masuk bertahap (staggered)
  Animation<double> _staggered(double start, double end) {
    return CurvedAnimation(
      parent: _introController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bgFade     = _staggered(0.0,  0.55);
    final topFade    = _staggered(0.15, 0.65);
    final cardFade   = _staggered(0.30, 0.85);
    final bottomFade = _staggered(0.45, 1.0);

    return GlobalTouchWrapper(
      child: Scaffold(
        backgroundColor: bgMain,
        body: Stack(
          fit: StackFit.expand,
          children: [
            // ── BACKGROUND SOLID BIRU MUDA (senada dengan dashboard) ──────────
            FadeTransition(
              opacity: bgFade,
              child: Container(color: bgMain),
            ),

            // ── OVERLAY GRADIENT LEMBUT (variasi tone biru, bukan gelap) ─────
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: const [0.0, 0.35, 0.65, 1.0],
                    colors: [
                      borderGreen.withOpacity(0.10),
                      bgMain,
                      bgMain,
                      Color(0xFFF7F0FC),
                    ],
                  ),
                ),
              ),
            ),

            // ── AMBIENT GLOW KIRI (efek cahaya biru lembut) ───────────────────
            Positioned(
              left: -80,
              top: MediaQuery.of(context).size.height * 0.15,
              child: Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      borderGreen.withOpacity(0.18),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),

            // ── KONTEN UTAMA ─────────────────────────────────────────────────
            SafeArea(
              child: Column(
                children: [
                  // ── LOGO (icon) & TOMBOL LEWATI ────────────────────────────
                  FadeTransition(
                    opacity: topFade,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0, -0.3),
                        end: Offset.zero,
                      ).animate(topFade),
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Logo icon
                            Container(
                              width: 42,
                              height: 42,
                              decoration: BoxDecoration(
                                color: bgCard,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: Colors.black,
                                  width: 1.5,
                                ),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Colors.black,
                                    blurRadius: 0,
                                    offset: Offset(3, 3),
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.bolt_rounded,
                                color: accentGreen,
                                size: 22,
                              ),
                            ),

                            // Tombol LEWATI
                            GestureDetector(
                              onTap: _skip,
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 8),
                                decoration: BoxDecoration(
                                  color: bgCard,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: Colors.black,
                                    width: 1.5,
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Colors.black,
                                      blurRadius: 0,
                                      offset: Offset(3, 3),
                                    ),
                                  ],
                                ),
                                child: Text(
                                  "LEWATI",
                                  style: TextStyle(
                                    fontFamily: 'Orbitron',
                                    color: textMain,
                                    fontSize: 12,
                                    letterSpacing: 1,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const Spacer(),

                  // ── KARTU ONBOARDING (PageView) ────────────────────────────
                  FadeTransition(
                    opacity: cardFade,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0, 0.15),
                        end: Offset.zero,
                      ).animate(cardFade),
                      child: SizedBox(
                        height: 245,
                        child: PageView.builder(
                          controller: _pageController,
                          physics: const BouncingScrollPhysics(),
                          itemCount: _steps.length,
                          itemBuilder: (context, index) {
                            final distance =
                                (index - _page).abs().clamp(0.0, 1.0);
                            final scale   = 1.0 - (distance * 0.08);
                            final opacity = 1.0 - (distance * 0.6);

                            return Transform.scale(
                              scale: scale,
                              child: Opacity(
                                opacity: opacity.clamp(0.0, 1.0),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                  child: _buildCard(_steps[index], index),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 22),

                  // ── HINT SWIPE + DOTS ────────────────────────────────────
                  FadeTransition(
                    opacity: bottomFade,
                    child: Column(
                      children: [
                        Text(
                          "Geser untuk lanjut",
                          style: TextStyle(
                            fontFamily: 'Orbitron',
                            color: textSub,
                            fontSize: 11,
                            letterSpacing: 0.6,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(_steps.length, (i) {
                            final active = i == _currentIndex;
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 350),
                              curve: Curves.easeOutCubic,
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              width:  active ? 22 : 7,
                              height: 7,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                                color: active
                                    ? accentGreen
                                    : Colors.black.withOpacity(0.18),
                                boxShadow: active
                                    ? [
                                        BoxShadow(
                                          color: accentGreen.withOpacity(0.5),
                                          blurRadius: 6,
                                          spreadRadius: 0.5,
                                        ),
                                      ]
                                    : null,
                              ),
                            );
                          }),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 18),

                  // ── TOMBOL AKSI (LANJUT / MULAI SEKARANG) ───────────────
                  FadeTransition(
                    opacity: bottomFade,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                      child: GestureDetector(
                        onTap: _next,
                        child: AnimatedBuilder(
                          animation: _pulseController,
                          builder: (context, child) {
                            final pulse    = _pulseController.value;
                            final isFilled = _steps[_currentIndex].filledButton;
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 450),
                              curve: Curves.easeOutCubic,
                              width: double.infinity,
                              height: 52,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                color: isFilled
                                    ? Color.lerp(
                                        accentGreen, borderGreen, pulse * 0.4)
                                    : bgCard,
                                border: Border.all(
                                  color: Colors.black,
                                  width: 1.5,
                                ),
                                boxShadow: [
                                  // Neubrutalism: hard offset shadow (senada dashboard)
                                  const BoxShadow(
                                    color: Colors.black,
                                    blurRadius: 0,
                                    offset: Offset(4, 4),
                                  ),
                                  if (isFilled)
                                    BoxShadow(
                                      color: accentGreen.withOpacity(
                                          0.25 + 0.10 * pulse),
                                      blurRadius: 14 + 4 * pulse,
                                      spreadRadius: 0,
                                    ),
                                ],
                              ),
                              child: AnimatedSwitcher(
                                duration: const Duration(milliseconds: 300),
                                child: Text(
                                  _steps[_currentIndex].buttonLabel,
                                  key: ValueKey(
                                      _steps[_currentIndex].buttonLabel),
                                  style: TextStyle(
                                    fontFamily: 'Orbitron',
                                    color: isFilled ? Colors.white : textMain,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(_OnboardStep step, int index) {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 18, 24, 20),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.black,
          width: 1.5,
        ),
        boxShadow: [
          // Neubrutalism: hard offset shadow (senada dashboard)
          const BoxShadow(
            color: Colors.black,
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: borderGreen.withOpacity(0.18),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── GARIS ATAS KARTU (aksen biru) ──────────────────────────────
          Container(
            width: 34,
            height: 3,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [borderGreen, accentGreen],
              ),
              borderRadius: BorderRadius.circular(6),
            ),
          ),
          const SizedBox(height: 16),

          // ── BADGE ────────────────────────────────────────────────────
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: accentGreen.withOpacity(0.10),
              border: Border.all(color: accentGreen.withOpacity(0.45)),
            ),
            child: Text(
              step.badge,
              style: const TextStyle(
                fontFamily: 'Orbitron',
                color: accentGreen,
                fontSize: 11,
                letterSpacing: 1,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(height: 14),

          // ── JUDUL ────────────────────────────────────────────────────
          Text(
            step.title,
            textAlign: TextAlign.center,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontFamily: 'Orbitron',
              color: textMain,
              fontSize: 20,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.2,
              height: 1.35,
            ),
          ),
          const SizedBox(height: 10),

          // ── SUBJUDUL ─────────────────────────────────────────────────
          Text(
            step.subtitle,
            textAlign: TextAlign.center,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontFamily: 'Orbitron',
              color: textSub,
              fontSize: 12.5,
              height: 1.5,
              letterSpacing: 0.3,
            ),
          ),
          const SizedBox(height: 12),

          // ── INDIKATOR HALAMAN "1 / 3" ─────────────────────────────
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.05),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              "${index + 1} / ${_steps.length}",
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: textSub,
                fontSize: 10.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
