import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'widgets/custom_popup.dart';

// ─── NEUBRUTALISM PALETTE ─────────────────────────────────────
class _NB {
  // Background
  static const bg = Color(0xFFFFFFFF);

  // Surfaces
  static const surface = Color(0xFFF5F3FF);
  static const card = Color(0xFFFAFAFA);

  // Borders
  static const border = Color(0xFF000000);

  // Ungu (solid, not too thick)
  static const purpleMain = Color(0xFF7C3AED);
  static const purpleMid = Color(0xFF8B5CF6);
  static const purpleLight = Color(0xFFA78BFA);
  static const purplePale = Color(0xFFEDE9FE);

  // Pink (solid, not too thick)
  static const pinkMain = Color(0xFFEC4899);
  static const pinkMid = Color(0xFFF472B6);
  static const pinkLight = Color(0xFFF9A8D4);
  static const pinkPale = Color(0xFFFCE7F3);

  // Biru (solid, not too thick)
  static const blueMain = Color(0xFF3B82F6);
  static const blueMid = Color(0xFF60A5FA);
  static const blueLight = Color(0xFF93BBFC);
  static const bluePale = Color(0xFFDBEAFE);

  // Text
  static const text = Color(0xFF1A1A1A);
  static const textSub = Color(0xFF4B4B4B);
  static const textDim = Color(0xFF888888);

  // Status
  static const green = Color(0xFF059669);
  static const red = Color(0xFFDC2626);
  static const orange = Color(0xFFF59E0B);

  // Gradien
  static const LinearGradient purpleGrad = LinearGradient(
    colors: [purpleMain, purpleMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['vip', 'reseller', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://hamapanelbego.duckdns.top:4951/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    if (filteredList.isEmpty) return [];
    final start = (currentPage - 1) * itemsPerPage;
    if (start >= filteredList.length) return [];
    final end = start + itemsPerPage;
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://hamapanelbego.duckdns.top:4951/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('http://hamapanelbego.duckdns.top:4951/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('http://hamapanelbego.duckdns.top:4951/editUser?key=$sessionKey&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    CustomPopup.show(
      context,
      title: title,
      message: message,
      icon: title.toLowerCase().contains("sukses") ? Icons.check_circle_outline : Icons.info_outline,
      iconColor: title.toLowerCase().contains("sukses") ? _NB.green : _NB.blueMain,
    );
  }

  // ============================================================
  // BUILD INPUT
  // ============================================================
  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: _NB.text,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 4),
        TextField(
          controller: controller,
          keyboardType: type,
          style: const TextStyle(color: _NB.text, fontSize: 14),
          decoration: InputDecoration(
            hintStyle: TextStyle(color: _NB.textDim),
            prefixIcon: Icon(icon, color: _NB.purpleMain, size: 18),
            filled: true,
            fillColor: _NB.surface,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: _NB.border, width: 2),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: _NB.border, width: 2),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: _NB.purpleMain, width: 2),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // NEUBRUTALISM CARD
  // ============================================================
  Widget _buildNeubrutalismCard({required Widget child, Color? accentColor}) {
    final color = accentColor ?? _NB.purpleMain;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _NB.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _NB.border, width: 2),
        boxShadow: const [
          BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
        ],
      ),
      child: child,
    );
  }

  // ============================================================
  // NEUBRUTALISM BUTTON
  // ============================================================
  Widget _buildNeubrutalismButton({
    required String text,
    required Color color,
    required VoidCallback onTap,
    IconData? icon,
    bool fullWidth = false,
  }) {
    return SizedBox(
      width: fullWidth ? double.infinity : null,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: const BorderSide(color: _NB.border, width: 2),
          ),
          elevation: 0,
          shadowColor: Colors.transparent,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 16, color: Colors.white),
              const SizedBox(width: 8),
            ],
            Text(
              text,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 13,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // POPUPS
  // ============================================================
  void _showCreateAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Dialog(
              backgroundColor: Colors.transparent,
              elevation: 0,
              child: _buildNeubrutalismCard(
                accentColor: _NB.green,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: _NB.green.withOpacity(0.12),
                              shape: BoxShape.circle,
                              border: Border.all(color: _NB.border, width: 1.5),
                            ),
                            child: const Icon(FontAwesomeIcons.userPlus, color: _NB.green, size: 22),
                          ),
                          const SizedBox(width: 14),
                          const Text(
                            "CREATE ACCOUNT",
                            style: TextStyle(
                              color: _NB.text,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      _buildInput(
                        label: "Username Baru",
                        controller: createUsernameController,
                        icon: FontAwesomeIcons.user,
                      ),
                      const SizedBox(height: 12),
                      _buildInput(
                        label: "Password",
                        controller: createPasswordController,
                        icon: FontAwesomeIcons.lock,
                      ),
                      const SizedBox(height: 12),
                      _buildInput(
                        label: "Durasi (Hari)",
                        controller: createDayController,
                        icon: FontAwesomeIcons.calendarDay,
                        type: TextInputType.number,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14),
                              decoration: BoxDecoration(
                                color: _NB.surface,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: _NB.border, width: 2),
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: newUserRole,
                                  isExpanded: true,
                                  dropdownColor: _NB.card,
                                  style: const TextStyle(
                                    color: _NB.text,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  icon: Icon(Icons.keyboard_arrow_down, color: _NB.purpleMain, size: 18),
                                  items: roleOptions.map((role) {
                                    return DropdownMenuItem(
                                      value: role,
                                      child: Text(role.toUpperCase()),
                                    );
                                  }).toList(),
                                  onChanged: (val) => setModalState(() => newUserRole = val ?? 'member'),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          _buildNeubrutalismButton(
                            text: "BUAT AKUN",
                            color: _NB.green,
                            icon: FontAwesomeIcons.userPlus,
                            onTap: () {
                              Navigator.pop(ctx);
                              _createAccount();
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }
      ),
    );
  }

  void _showDeleteAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: _buildNeubrutalismCard(
            accentColor: _NB.red,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _NB.red.withOpacity(0.12),
                        shape: BoxShape.circle,
                        border: Border.all(color: _NB.border, width: 1.5),
                      ),
                      child: const Icon(FontAwesomeIcons.userSlash, color: _NB.red, size: 22),
                    ),
                    const SizedBox(width: 14),
                    const Text(
                      "DELETE USER",
                      style: TextStyle(
                        color: _NB.text,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                _buildInput(
                  label: "Username Target",
                  controller: deleteController,
                  icon: FontAwesomeIcons.user,
                ),
                const SizedBox(height: 16),
                _buildNeubrutalismButton(
                  text: "HAPUS AKUN",
                  color: _NB.red,
                  icon: FontAwesomeIcons.userSlash,
                  fullWidth: true,
                  onTap: () {
                    Navigator.pop(ctx);
                    _deleteUser();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _NB.bg,
      appBar: AppBar(
        title: const Text(
          "ADMIN PANEL",
          style: TextStyle(
            color: _NB.text,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
          ),
        ),
        backgroundColor: _NB.bg,
        elevation: 0,
        centerTitle: false,
        iconTheme: const IconThemeData(color: _NB.text),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(2),
          child: Container(height: 2, color: _NB.border),
        ),
      ),
      body: isLoading && fullUserList.isEmpty
          ? const Center(
              child: SizedBox(
                width: 40,
                height: 40,
                child: CircularProgressIndicator(
                  color: _NB.purpleMain,
                  strokeWidth: 3,
                ),
              ),
            )
          : SafeArea(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    // ===== DELETE USER =====
                    _buildNeubrutalismCard(
                      accentColor: _NB.red,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: _NB.red.withOpacity(0.1),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: _NB.border, width: 1.5),
                                ),
                                child: const Icon(Icons.delete_forever, color: _NB.red, size: 20),
                              ),
                              const SizedBox(width: 12),
                              const Text(
                                "DELETE USER",
                                style: TextStyle(
                                  color: _NB.text,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          _buildInput(
                            label: "Username Target",
                            controller: deleteController,
                            icon: FontAwesomeIcons.user,
                          ),
                          const SizedBox(height: 12),
                          _buildNeubrutalismButton(
                            text: "HAPUS AKUN",
                            color: _NB.red,
                            icon: FontAwesomeIcons.userSlash,
                            fullWidth: true,
                            onTap: _deleteUser,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // ===== CREATE ACCOUNT =====
                    _buildNeubrutalismCard(
                      accentColor: _NB.green,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: _NB.green.withOpacity(0.1),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: _NB.border, width: 1.5),
                                ),
                                child: const Icon(Icons.person_add, color: _NB.green, size: 20),
                              ),
                              const SizedBox(width: 12),
                              const Text(
                                "CREATE ACCOUNT",
                                style: TextStyle(
                                  color: _NB.text,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          _buildInput(
                            label: "Username Baru",
                            controller: createUsernameController,
                            icon: FontAwesomeIcons.user,
                          ),
                          const SizedBox(height: 12),
                          _buildInput(
                            label: "Password",
                            controller: createPasswordController,
                            icon: FontAwesomeIcons.lock,
                          ),
                          const SizedBox(height: 12),
                          _buildInput(
                            label: "Durasi (Hari)",
                            controller: createDayController,
                            icon: FontAwesomeIcons.calendarDay,
                            type: TextInputType.number,
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 14),
                                  decoration: BoxDecoration(
                                    color: _NB.surface,
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: _NB.border, width: 2),
                                  ),
                                  child: DropdownButtonHideUnderline(
                                    child: DropdownButton<String>(
                                      value: newUserRole,
                                      isExpanded: true,
                                      dropdownColor: _NB.card,
                                      style: const TextStyle(
                                        color: _NB.text,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      icon: Icon(Icons.keyboard_arrow_down, color: _NB.purpleMain, size: 18),
                                      items: roleOptions.map((role) {
                                        return DropdownMenuItem(
                                          value: role,
                                          child: Text(role.toUpperCase()),
                                        );
                                      }).toList(),
                                      onChanged: (val) => setState(() => newUserRole = val ?? 'member'),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              _buildNeubrutalismButton(
                                text: "BUAT AKUN",
                                color: _NB.green,
                                icon: FontAwesomeIcons.userPlus,
                                onTap: _createAccount,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // ===== USER DIRECTORY =====
                    _buildNeubrutalismCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: _NB.purplePale,
                                  shape: BoxShape.circle,
                                  border: Border.all(color: _NB.border, width: 1.5),
                                ),
                                child: const Icon(Icons.people, color: _NB.purpleMain, size: 20),
                              ),
                              const SizedBox(width: 12),
                              const Text(
                                "MEMBER",
                                style: TextStyle(
                                  color: _NB.text,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            decoration: BoxDecoration(
                              color: _NB.surface,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _NB.border, width: 2),
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                value: selectedRole,
                                isExpanded: true,
                                dropdownColor: _NB.card,
                                style: const TextStyle(
                                  color: _NB.text,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500,
                                ),
                                icon: Icon(Icons.keyboard_arrow_down, color: _NB.purpleMain, size: 18),
                                items: roleOptions.map((role) {
                                  return DropdownMenuItem(
                                    value: role,
                                    child: Text(role.toUpperCase()),
                                  );
                                }).toList(),
                                onChanged: (val) {
                                  if (val != null) {
                                    setState(() {
                                      selectedRole = val;
                                      _filterAndPaginate();
                                    });
                                  }
                                },
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          if (filteredList.isEmpty && !isLoading)
                            const Center(
                              child: Padding(
                                padding: EdgeInsets.symmetric(vertical: 20),
                                child: Text(
                                  "Belum ada user di kategori ini.",
                                  style: TextStyle(color: _NB.textSub, fontSize: 13),
                                ),
                              ),
                            ),
                          ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                          const SizedBox(height: 12),
                          Center(child: _buildPagination()),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
    );
  }

  // ============================================================
  // USER ITEM
  // ============================================================
  Widget _buildUserItem(Map user) {
    final roleColor = _getRoleColor(user['role'] ?? 'member');
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _NB.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _NB.border, width: 2),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: roleColor.withOpacity(0.12),
              shape: BoxShape.circle,
              border: Border.all(color: _NB.border, width: 1.5),
            ),
            child: Icon(Icons.person, color: roleColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'] ?? 'Unknown',
                  style: const TextStyle(
                    color: _NB.text,
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
                Text(
                  "ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate'] ?? '-'}",
                  style: const TextStyle(
                    color: _NB.textSub,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: _NB.red, size: 20),
            onPressed: () {
              deleteController.text = user['username'];
              _showDeleteAccountPopup();
            },
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
        ],
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'vip':
        return _NB.pinkMain;
      case 'reseller':
        return _NB.blueMain;
      case 'member':
        return _NB.green;
      default:
        return _NB.textSub;
    }
  }

  // ============================================================
  // PAGINATION
  // ============================================================
  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isSelected = currentPage == page;
        return InkWell(
          onTap: () => setState(() => currentPage = page),
          borderRadius: BorderRadius.circular(6),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: isSelected ? _NB.purpleMain : Colors.transparent,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: isSelected ? _NB.purpleMain : _NB.border,
                width: 2,
              ),
            ),
            child: Text(
              "$page",
              style: TextStyle(
                color: isSelected ? Colors.white : _NB.textSub,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
          ),
        );
      }),
    );
  }
}