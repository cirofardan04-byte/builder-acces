import 'package:flutter/material.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'set.dart';
import 'tap.dart';
import 'landing_page.dart';
import 'owner_page.dart';

// ─── NEUBRUTALISM PALETTE ─────────────────────────────────────
class _NB {
  // Background
  static const bg = Color(0xFFFFFFFF);

  // Surfaces
  static const surface = Color(0xFFF5F3FF);
  static const card = Color(0xFFFAFAFA);

  // Borders
  static const border = Color(0xFF000000);

  // Ungu (solid, not too thick)
  static const purpleMain = Color(0xFF7C3AED);
  static const purpleMid = Color(0xFF8B5CF6);
  static const purpleLight = Color(0xFFA78BFA);
  static const purplePale = Color(0xFFEDE9FE);

  // Pink (solid, not too thick)
  static const pinkMain = Color(0xFFEC4899);
  static const pinkMid = Color(0xFFF472B6);
  static const pinkLight = Color(0xFFF9A8D4);
  static const pinkPale = Color(0xFFFCE7F3);

  // Biru (solid, not too thick)
  static const blueMain = Color(0xFF3B82F6);
  static const blueMid = Color(0xFF60A5FA);
  static const blueLight = Color(0xFF93BBFC);
  static const bluePale = Color(0xFFDBEAFE);

  // Text
  static const text = Color(0xFF1A1A1A);
  static const textSub = Color(0xFF4B4B4B);
  static const textDim = Color(0xFF888888);

  // Status
  static const green = Color(0xFF059669);
  static const red = Color(0xFFDC2626);
  static const orange = Color(0xFFF59E0B);

  // Gradien
  static const LinearGradient purpleGrad = LinearGradient(
    colors: [purpleMain, purpleMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient pinkGrad = LinearGradient(
    colors: [pinkMain, pinkMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient blueGrad = LinearGradient(
    colors: [blueMain, blueMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PXL PROJECT V3',
      theme: ThemeData(
        brightness: Brightness.light,
        fontFamily: 'ShareTechMono',

        scaffoldBackgroundColor: _NB.bg,

        colorScheme: const ColorScheme.light().copyWith(
          primary: _NB.purpleMain,
          secondary: _NB.purpleMid,
          background: _NB.bg,
          surface: _NB.card,
          onPrimary: Colors.white,
          onBackground: _NB.text,
          onSurface: _NB.text,
        ),

        primaryColor: _NB.purpleMain,

        appBarTheme: const AppBarTheme(
          backgroundColor: _NB.bg,
          foregroundColor: _NB.text,
          iconTheme: IconThemeData(
            color: _NB.text,
          ),
          elevation: 0,
        ),

        iconTheme: const IconThemeData(
          color: _NB.text,
        ),

        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: _NB.purpleMain,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: const BorderSide(color: _NB.border, width: 2),
            ),
            elevation: 0,
            shadowColor: Colors.transparent,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          ),
        ),

        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: _NB.purpleMain,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),

        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: _NB.purpleMain,
            side: const BorderSide(
              color: _NB.border,
              width: 2,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 0,
          ),
        ),

        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: _NB.purpleMain,
          foregroundColor: Colors.white,
        ),

        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: _NB.surface,

          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(
              color: _NB.purpleMain,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(10),
          ),

          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(
              color: _NB.border,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(10),
          ),

          errorBorder: OutlineInputBorder(
            borderSide: const BorderSide(
              color: _NB.red,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(10),
          ),

          focusedErrorBorder: OutlineInputBorder(
            borderSide: const BorderSide(
              color: _NB.red,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(10),
          ),

          labelStyle: const TextStyle(
            color: _NB.textSub,
          ),
          hintStyle: const TextStyle(
            color: _NB.textDim,
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),

        snackBarTheme: const SnackBarThemeData(
          backgroundColor: _NB.text,
          contentTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 14,
          ),
          behavior: SnackBarBehavior.floating,
          elevation: 0,
        ),

        cardTheme: const CardThemeData(
          color: Color(0xFFFAFAFA),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(12)),
            side: BorderSide(color: Color(0xFF000000), width: 2),
          ),
          elevation: 0,
          margin: EdgeInsets.all(8),
        ),

        dialogTheme: const DialogThemeData(
          backgroundColor: Color(0xFFFAFAFA),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(12)),
            side: BorderSide(color: Color(0xFF000000), width: 2),
          ),
          elevation: 0,
        ),

        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Color(0xFFFAFAFA),
          selectedItemColor: Color(0xFF7C3AED),
          unselectedItemColor: Color(0xFF4B4B4B),
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          showSelectedLabels: false,
          showUnselectedLabels: false,
        ),
      ),

      // Global Touch Wrapper
      builder: (context, child) {
        return GlobalTouchWrapper(
          child: child!,
        );
      },

      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => LandingPage());

          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());

          case '/dashboard':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args['username'],
                password: args['password'],
                role: args['role'],
                sessionKey: args['key'],
                expiredDate: args['expiredDate'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
                news: List<Map<String, dynamic>>.from(args['news'] ?? []),
              ),
            );

          case '/home':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => HomePage(
                username: args['username'],
                password: args['password'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                role: args['role'],
                expiredDate: args['expiredDate'],
                sessionKey: args['sessionKey'],
              ),
            );

          case '/seller':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => SellerPage(
                keyToken: args['keyToken'],
              ),
            );

          case '/admin':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => AdminPage(
                sessionKey: args['sessionKey'],
              ),
            );

          case '/owner':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => OwnerPage(
                sessionKey: args['sessionKey'],
                username: args['username'],
              ),
            );

          default:
            return MaterialPageRoute(
              builder: (_) => Scaffold(
                backgroundColor: _NB.bg,
                body: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: _NB.card,
                          shape: BoxShape.circle,
                          border: Border.all(color: _NB.border, width: 2),
                          boxShadow: const [
                            BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
                          ],
                        ),
                        child: const Icon(
                          Icons.error_outline,
                          color: _NB.red,
                          size: 48,
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "404 - Page Not Found",
                        style: TextStyle(
                          color: _NB.text,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "Halaman yang kamu cari tidak tersedia.",
                        style: TextStyle(
                          color: _NB.textSub,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
        }
      },
    );
  }
}