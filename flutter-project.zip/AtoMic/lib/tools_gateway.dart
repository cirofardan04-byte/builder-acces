import 'dart:ui';
import 'package:flutter/material.dart';
import 'widgets/custom_popup.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';
import 'hentai_page.dart' as hentai;
import 'spam_pair.dart';
import 'campuran.dart';

// ─── NEUBRUTALISM PALETTE ─────────────────────────────────────
class _NB {
  // Background
  static const bg = Color(0xFFFFFFFF);

  // Surfaces
  static const surface = Color(0xFFF5F3FF);
  static const card = Color(0xFFFAFAFA);

  // Borders
  static const border = Color(0xFF000000);

  // Ungu (solid, not too thick)
  static const purpleMain = Color(0xFF7C3AED);
  static const purpleMid = Color(0xFF8B5CF6);
  static const purpleLight = Color(0xFFA78BFA);
  static const purplePale = Color(0xFFEDE9FE);

  // Pink (solid, not too thick)
  static const pinkMain = Color(0xFFEC4899);
  static const pinkMid = Color(0xFFF472B6);
  static const pinkLight = Color(0xFFF9A8D4);
  static const pinkPale = Color(0xFFFCE7F3);

  // Biru (solid, not too thick)
  static const blueMain = Color(0xFF3B82F6);
  static const blueMid = Color(0xFF60A5FA);
  static const blueLight = Color(0xFF93BBFC);
  static const bluePale = Color(0xFFDBEAFE);

  // Text
  static const text = Color(0xFF1A1A1A);
  static const textSub = Color(0xFF4B4B4B);
  static const textDim = Color(0xFF888888);

  // Status colors
  static const red = Color(0xFFDC2626);
  static const orange = Color(0xFFF59E0B);
  static const green = Color(0xFF059669);

  // Gradien
  static const LinearGradient purpleGrad = LinearGradient(
    colors: [purpleMain, purpleMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient pinkGrad = LinearGradient(
    colors: [pinkMain, pinkMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient blueGrad = LinearGradient(
    colors: [blueMain, blueMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _NB.bg,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: _buildToolsBanner(),
            ),
            SliverPadding(
              padding: const EdgeInsets.all(16),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.1,
                ),
                delegate: SliverChildListDelegate([
                  _buildToolGridItem(
                    context: context,
                    icon: Icons.flash_on,
                    label: "DDOS Tools",
                    subtitle: "Attack & Server",
                    color: _NB.pinkMain,
                    onTap: () => _showCategoryDialog(
                      context: context,
                      title: "DDOS Tools",
                      icon: Icons.flash_on,
                      color: _NB.pinkMain,
                      children: [
                        _buildSubItem(
                          context: context,
                          icon: Icons.flash_on,
                          label: "Attack Panel",
                          color: _NB.pinkMain,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => AttackPanel(
                                  sessionKey: sessionKey,
                                  listDoos: listDoos,
                                ),
                              ),
                            );
                          },
                        ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.dns,
                          label: "Manage Server",
                          color: _NB.pinkMain,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ManageServerPage(keyToken: sessionKey),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  _buildToolGridItem(
                    context: context,
                    icon: Icons.wifi,
                    label: "Network",
                    subtitle: "WiFi & Spam",
                    color: _NB.orange,
                    onTap: () => _showCategoryDialog(
                      context: context,
                      title: "Network",
                      icon: Icons.wifi,
                      color: _NB.orange,
                      children: [
                        _buildSubItem(
                          context: context,
                          icon: Icons.newspaper_outlined,
                          label: "Spam NGL",
                          color: _NB.orange,
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => const NglPage()));
                          },
                        ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.wifi_off,
                          label: "WiFi Killer (Internal)",
                          color: _NB.orange,
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => const WifiKillerPage()));
                          },
                        ),
                        if (userRole == "vip" || userRole == "owner")
                          _buildSubItem(
                            context: context,
                            icon: Icons.router,
                            label: "WiFi Killer (External)",
                            color: _NB.orange,
                            onTap: () {
                              Navigator.push(context, MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: sessionKey)));
                            },
                          ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.message,
                          label: "Spam Pairing",
                          color: _NB.orange,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ReportPage(
                                  username: "User",
                                  sessionKey: sessionKey,
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  _buildToolGridItem(
                    context: context,
                    icon: Icons.search,
                    label: "OSINT",
                    subtitle: "Investigation",
                    color: _NB.blueMain,
                    onTap: () => _showCategoryDialog(
                      context: context,
                      title: "OSINT",
                      icon: Icons.search,
                      color: _NB.blueMain,
                      children: [
                        _buildSubItem(
                          context: context,
                          icon: Icons.badge,
                          label: "NIK Detail",
                          color: _NB.blueMain,
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
                          },
                        ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.domain,
                          label: "Domain OSINT",
                          color: _NB.blueMain,
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
                          },
                        ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.person_search,
                          label: "Phone Lookup",
                          color: _NB.blueMain,
                          onTap: () => _showComingSoon(context),
                        ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.email,
                          label: "Email OSINT",
                          color: _NB.blueMain,
                          onTap: () => _showComingSoon(context),
                        ),
                      ],
                    ),
                  ),
                  _buildToolGridItem(
                    context: context,
                    icon: Icons.download,
                    label: "Downloader",
                    subtitle: "Social Media",
                    color: _NB.purpleMain,
                    onTap: () => _showCategoryDialog(
                      context: context,
                      title: "Downloader",
                      icon: Icons.download,
                      color: _NB.purpleMain,
                      children: [
                        _buildSubItem(
                          context: context,
                          icon: Icons.video_library,
                          label: "TikTok Downloader",
                          color: _NB.purpleMain,
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
                          },
                        ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.camera_alt,
                          label: "Instagram Downloader",
                          color: _NB.purpleMain,
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
                          },
                        ),
                      ],
                    ),
                  ),
                  _buildToolGridItem(
                    context: context,
                    icon: Icons.build,
                    label: "Utilities",
                    subtitle: "Extra Tools",
                    color: _NB.green,
                    onTap: () => _showCategoryDialog(
                      context: context,
                      title: "Utilities",
                      icon: Icons.build,
                      color: _NB.green,
                      children: [
                        _buildSubItem(
                          context: context,
                          icon: Icons.qr_code,
                          label: "QR Generator",
                          color: _NB.green,
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
                          },
                        ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.security,
                          label: "IP Scanner",
                          color: _NB.green,
                          onTap: () => _showComingSoon(context),
                        ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.network_check,
                          label: "Port Scanner",
                          color: _NB.green,
                          onTap: () => _showComingSoon(context),
                        ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.bolt,
                          label: "CD Ultimate Panel",
                          color: _NB.green,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const CDUltimatePanel(),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  _buildToolGridItem(
                    context: context,
                    icon: Icons.movie_filter,
                    label: "Watch",
                    subtitle: "Entertainment & Media",
                    color: _NB.pinkMain,
                    onTap: () => _showCategoryDialog(
                      context: context,
                      title: "Watch",
                      icon: Icons.movie_filter,
                      color: _NB.pinkMain,
                      children: [
                        _buildSubItem(
                          context: context,
                          icon: Icons.live_tv,
                          label: "Anime Streaming",
                          color: _NB.pinkMain,
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeAnimePage()));
                          },
                        ),
                        _buildSubItem(
                          context: context,
                          icon: Icons.local_fire_department,
                          label: "Hentai Media",
                          color: _NB.pinkMain,
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => const hentai.HomeScreen()));
                          },
                        ),
                      ],
                    ),
                  ),
                  _buildToolGridItem(
                    context: context,
                    icon: Icons.rocket_launch,
                    label: "Quick Access",
                    subtitle: "Favorites",
                    color: _NB.orange,
                    onTap: () => _showComingSoon(context),
                  ),
                ]),
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(height: 24),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToolsBanner() {
    return Container(
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: _NB.border, width: 3),
        ),
      ),
      child: SizedBox(
        height: 160,
        width: double.infinity,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // ─── Background Image ──────────────────────────────────────────
            Image.asset(
              'assets/images/banner.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: _NB.purplePale,
                child: const Center(
                  child: Icon(Icons.image, color: _NB.textDim, size: 50),
                ),
              ),
            ),
            // ─── Overlay ──────────────────────────────────────────────────
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.3),
                    Colors.black.withOpacity(0.55),
                  ],
                ),
              ),
            ),
            // ─── Isi Banner ──────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Dekorasi Neubrutalism ──
                  Row(
                    children: [
                      Container(
                        width: 48,
                        height: 4,
                        color: _NB.purpleMain,
                      ),
                      const SizedBox(width: 12),
                      Container(
                        width: 24,
                        height: 4,
                        color: _NB.pinkMain,
                      ),
                      const SizedBox(width: 12),
                      Container(
                        width: 12,
                        height: 4,
                        color: _NB.blueMain,
                      ),
                      const Spacer(),
                      // ── Badge "Queen" ──
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.3),
                            width: 1.5,
                          ),
                        ),
                        child: const Text(
                          "QUEEN",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 2,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  // ── Judul Utama ──
                  const Text(
                    "Queen Tools",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      fontFamily: 'Aktura',
                    ),
                  ),
                  const SizedBox(height: 4),
                  // ── Subtitle ──
                  Row(
                    children: [
                      Container(
                        width: 32,
                        height: 2,
                        color: _NB.purpleMain,
                      ),
                      const SizedBox(width: 10),
                      const Text(
                        "Tools Queen",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          letterSpacing: 0.8,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  // ── Bottom Decoration ──
                  Row(
                    children: [
                      Container(
                        width: 60,
                        height: 3,
                        color: _NB.purpleMain.withOpacity(0.6),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        width: 30,
                        height: 3,
                        color: _NB.pinkMain.withOpacity(0.6),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        width: 15,
                        height: 3,
                        color: _NB.blueMain.withOpacity(0.6),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // ─── Corner Decoration (Neubrutalism) ──────────────────────
            Positioned(
              bottom: 12,
              right: 16,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _NB.purpleMain.withOpacity(0.8),
                  border: Border.all(color: Colors.white, width: 1.5),
                ),
                child: const Text(
                  "⚡",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToolGridItem({
    required BuildContext context,
    required IconData icon,
    required String label,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: _NB.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _NB.border, width: 2),
          boxShadow: const [
            BoxShadow(
              color: _NB.border,
              blurRadius: 0,
              offset: Offset(4, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: _NB.border, width: 1.5),
                ),
                child: Icon(
                  icon,
                  color: color,
                  size: 32,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: _NB.text,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _NB.textSub,
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSubItem({
    required BuildContext context,
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: _NB.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _NB.border, width: 2),
        boxShadow: const [
          BoxShadow(
            color: _NB.border,
            blurRadius: 0,
            offset: Offset(3, 3),
          ),
        ],
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _NB.border, width: 1.5),
              ),
              child: Icon(
                icon,
                color: color,
                size: 20,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  color: _NB.text,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: _NB.textDim,
              size: 14,
            ),
          ],
        ),
      ),
    );
  }

  void _showCategoryDialog({
    required BuildContext context,
    required String title,
    required IconData icon,
    required Color color,
    required List<Widget> children,
  }) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _NB.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _NB.border, width: 2),
              boxShadow: const [
                BoxShadow(
                  color: _NB.border,
                  blurRadius: 0,
                  offset: Offset(6, 6),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.12),
                        shape: BoxShape.circle,
                        border: Border.all(color: _NB.border, width: 1.5),
                      ),
                      child: Icon(
                        icon,
                        color: color,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Text(
                      title,
                      style: const TextStyle(
                        color: _NB.text,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 0.5,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.pop(ctx),
                      icon: Icon(
                        Icons.close_rounded,
                        color: _NB.textDim,
                        size: 22,
                      ),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                ...children,
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    CustomPopup.show(
      context,
      title: "Coming Soon",
      message: "Fitur ini masih dalam tahap pengembangan.",
      icon: Icons.info_outline,
      iconColor: _NB.blueMain,
    );
  }
}