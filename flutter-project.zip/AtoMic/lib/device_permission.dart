import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ─── NEUBRUTALISM PALETTE ─────────────────────────────────────
class _NB {
  // Background
  static const bg = Color(0xFFFFFFFF);

  // Surfaces
  static const surface = Color(0xFFF5F3FF);
  static const card = Color(0xFFFAFAFA);

  // Borders
  static const border = Color(0xFF000000);

  // Ungu (solid, not too thick)
  static const purpleMain = Color(0xFF7C3AED);
  static const purpleMid = Color(0xFF8B5CF6);
  static const purpleLight = Color(0xFFA78BFA);
  static const purplePale = Color(0xFFEDE9FE);

  // Pink (solid, not too thick)
  static const pinkMain = Color(0xFFEC4899);
  static const pinkMid = Color(0xFFF472B6);
  static const pinkLight = Color(0xFFF9A8D4);
  static const pinkPale = Color(0xFFFCE7F3);

  // Biru (solid, not too thick)
  static const blueMain = Color(0xFF3B82F6);
  static const blueMid = Color(0xFF60A5FA);
  static const blueLight = Color(0xFF93BBFC);
  static const bluePale = Color(0xFFDBEAFE);

  // Text
  static const text = Color(0xFF1A1A1A);
  static const textSub = Color(0xFF4B4B4B);
  static const textDim = Color(0xFF888888);

  // Status
  static const green = Color(0xFF059669);
  static const red = Color(0xFFDC2626);
  static const orange = Color(0xFFF59E0B);

  // Gradien
  static const LinearGradient purpleGrad = LinearGradient(
    colors: [purpleMain, purpleMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── Config ───────────────────────────────────────────────────────────────────
const _kBase = 'http://hamapanelbego.duckdns.top:4951';

// ─── Permission Store ────────────────────────────────────────────────────────
class DevicePermissionStore {

  static Future<PermissionResult> getFor(String username, String sessionKey) async {
    if (username.toLowerCase() == 'owner') {
      return PermissionResult(approved: true, allDevices: true, devices: []);
    }
    try {
      final res = await http.get(
        Uri.parse('$_kBase/devicePerms?key=$sessionKey&username=${Uri.encodeComponent(username)}'),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['valid'] == true) {
          return PermissionResult(
            approved: d['approved'] == true,
            allDevices: d['allDevices'] == true,
            devices: List<String>.from(d['devices'] ?? []),
          );
        }
      }
    } catch (e) {
      debugPrint('[DevicePerm] getFor error: $e');
    }
    return PermissionResult(approved: false, allDevices: false, devices: []);
  }

  static Future<bool> setPerm(String ownerKey, String username,
      {required bool approved, required bool allDevices, required List<String> devices}) async {
    try {
      final res = await http.post(
        Uri.parse('$_kBase/setDevicePerm?key=$ownerKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': username,
          'approved': approved,
          'allDevices': allDevices,
          'devices': devices,
        }),
      ).timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      return d['valid'] == true;
    } catch (e) {
      debugPrint('[DevicePerm] setPerm error: $e');
      return false;
    }
  }

  static Future<bool> removePerm(String ownerKey, String username) async {
    return setPerm(ownerKey, username,
        approved: false, allDevices: false, devices: []);
  }

  static Future<Map<String, dynamic>> getAll(String ownerKey) async {
    try {
      final res = await http.get(
        Uri.parse('$_kBase/listDevicePerms?key=$ownerKey'),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['valid'] == true) return Map<String, dynamic>.from(d['perms'] ?? {});
      }
    } catch (e) {
      debugPrint('[DevicePerm] getAll error: $e');
    }
    return {};
  }
}

class PermissionResult {
  final bool approved, allDevices;
  final List<String> devices;
  PermissionResult({required this.approved, required this.allDevices, required this.devices});
  bool canSee(String? deviceId) {
    if (!approved) return false;
    if (allDevices) return true;
    return deviceId != null && devices.contains(deviceId);
  }
}

// ─── Owner Permission Manager ─────────────────────────────────────────────────
class DevicePermissionManagerPage extends StatefulWidget {
  final String sessionKey;
  final List<dynamic> allDevices;
  const DevicePermissionManagerPage({
    super.key, required this.sessionKey, required this.allDevices});
  @override State<DevicePermissionManagerPage> createState() => _DPMState();
}

class _DPMState extends State<DevicePermissionManagerPage> {
  Map<String, dynamic> _perms = {};
  String _selectedUser = '';
  final _inputCtrl = TextEditingController();
  String _inputVal = '';
  bool _loading = true;
  bool _saving = false;

  @override void initState() { super.initState(); _load(); }
  @override void dispose() { _inputCtrl.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    final data = await DevicePermissionStore.getAll(widget.sessionKey);
    setState(() { _perms = data; _loading = false; });
  }

  List<String> get _users => _perms.keys.toList();
  bool _approved(String u) => _perms[u]?['approved'] == true;
  bool _hasAll(String u) => _perms[u]?['allDevices'] == true;
  List<String> _devices(String u) => List<String>.from(_perms[u]?['devices'] ?? []);

  Future<void> _addUser(String username) async {
    if (username.trim().isEmpty) return;
    final key = username.trim().toLowerCase();
    final ok = await DevicePermissionStore.setPerm(
      widget.sessionKey, key,
      approved: true, allDevices: true, devices: [],
    );
    if (ok) {
      await _load();
      setState(() { _selectedUser = key; _inputVal = ''; _inputCtrl.clear(); });
    }
  }

  Future<void> _update(String u, {bool? approved, bool? allDevices, List<String>? devices}) async {
    setState(() => _saving = true);
    final ok = await DevicePermissionStore.setPerm(
      widget.sessionKey, u,
      approved: approved ?? _approved(u),
      allDevices: allDevices ?? _hasAll(u),
      devices: devices ?? _devices(u),
    );
    if (ok) await _load();
    setState(() => _saving = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: _NB.bg,
    appBar: AppBar(
      backgroundColor: _NB.bg,
      elevation: 0,
      title: const Text(
        'Kelola Akses Device',
        style: TextStyle(color: _NB.text, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 0.5),
      ),
      iconTheme: const IconThemeData(color: _NB.purpleMain),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(2),
        child: Container(height: 2, color: _NB.border),
      ),
      actions: [
        if (_saving) const Padding(
          padding: EdgeInsets.only(right: 16),
          child: SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(
              color: _NB.purpleMain,
              strokeWidth: 2.5,
            ),
          ),
        ),
      ],
    ),
    body: _loading
        ? const Center(
            child: SizedBox(
              width: 40,
              height: 40,
              child: CircularProgressIndicator(
                color: _NB.purpleMain,
                strokeWidth: 3,
              ),
            ),
          )
        : Column(children: [
      // ─ Add user ──────────────────────────────────────────────────────
      Padding(padding: const EdgeInsets.all(14), child: Row(children: [
        Expanded(child: Container(
          decoration: BoxDecoration(
            color: _NB.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _NB.border, width: 2),
            boxShadow: const [
              BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(3, 3)),
            ],
          ),
          child: TextField(
            controller: _inputCtrl,
            onChanged: (v) => setState(() => _inputVal = v),
            style: const TextStyle(color: _NB.text, fontSize: 13),
            decoration: const InputDecoration(
              hintText: 'Ketik username...',
              hintStyle: TextStyle(color: _NB.textDim),
              prefixIcon: Icon(Icons.person_rounded, color: _NB.purpleMain, size: 18),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(vertical: 11, horizontal: 4),
            ),
          ),
        )),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => _addUser(_inputVal),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
            decoration: BoxDecoration(
              color: _NB.purpleMain,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _NB.border, width: 2),
              boxShadow: const [
                BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(3, 3)),
              ],
            ),
            child: const Text(
              'Tambah',
              style: TextStyle(color: _NB.bg, fontSize: 13, fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ])),

      if (_users.isEmpty)
        Expanded(child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _NB.card,
              shape: BoxShape.circle,
              border: Border.all(color: _NB.border, width: 2),
              boxShadow: const [
                BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
              ],
            ),
            child: Icon(Icons.group_off_rounded, color: _NB.textDim, size: 48),
          ),
          const SizedBox(height: 16),
          const Text(
            'Belum ada user ditambahkan',
            style: TextStyle(color: _NB.text, fontSize: 15, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          const Text(
            'Ketik username untuk memberi akses',
            style: TextStyle(color: _NB.textSub, fontSize: 12),
          ),
        ])))
      else
        Expanded(child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(14, 0, 14, 20), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
          // User chips
          const Text(
            'Pilih User:',
            style: TextStyle(color: _NB.textSub, fontSize: 11, letterSpacing: 1, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: _users.map((u) {
            final active = u == _selectedUser;
            final appr = _approved(u);
            return GestureDetector(
              onTap: () => setState(() => _selectedUser = u),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  color: active ? _NB.purpleMain : _NB.card,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: active ? _NB.purpleMain : (appr ? _NB.green : _NB.border),
                    width: 2,
                  ),
                  boxShadow: active ? const [
                    BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(2, 2)),
                  ] : null,
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  CircleAvatar(
                    radius: 3.5,
                    backgroundColor: appr ? _NB.green : _NB.red,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    u,
                    style: TextStyle(
                      color: active ? _NB.bg : _NB.text,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ]),
              ),
            );
          }).toList()),

          if (_selectedUser.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _NB.card,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _NB.border, width: 2),
                boxShadow: const [
                  BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
                ],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Header + hapus
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Row(children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: _NB.purplePale,
                        shape: BoxShape.circle,
                        border: Border.all(color: _NB.border, width: 1.5),
                      ),
                      child: const Icon(Icons.person_rounded, color: _NB.purpleMain, size: 16),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      _selectedUser,
                      style: const TextStyle(color: _NB.text, fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                  ]),
                  GestureDetector(
                    onTap: () async {
                      await DevicePermissionStore.removePerm(widget.sessionKey, _selectedUser);
                      setState(() => _selectedUser = '');
                      await _load();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: _NB.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: _NB.red.withOpacity(0.3),
                          width: 2,
                        ),
                      ),
                      child: const Text(
                        'Hapus',
                        style: TextStyle(
                          color: _NB.red,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ]),
                const Divider(color: _NB.border, height: 20, thickness: 1.5),
                // Toggle approve
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text(
                      'Setujui Akses',
                      style: TextStyle(color: _NB.text, fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                    Text(
                      _approved(_selectedUser)
                          ? 'User dapat akses device'
                          : 'Akses ditolak',
                      style: TextStyle(
                        color: _approved(_selectedUser) ? _NB.green : _NB.red,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ]),
                  Switch(
                    value: _approved(_selectedUser),
                    activeColor: _NB.purpleMain,
                    inactiveThumbColor: _NB.textDim,
                    onChanged: (v) => _update(_selectedUser, approved: v),
                  ),
                ]),
              ])),
            ])),

            // Device checklist
            if (_approved(_selectedUser) && !_hasAll(_selectedUser)) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _NB.card,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _NB.border, width: 2),
                  boxShadow: const [
                    BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4)),
                  ],
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const Text(
                      'Pilih Device',
                      style: TextStyle(color: _NB.textSub, fontSize: 11, letterSpacing: 1, fontWeight: FontWeight.w600),
                    ),
                    const Spacer(),
                    Text(
                      '${_devices(_selectedUser).length} dipilih',
                      style: const TextStyle(color: _NB.purpleMain, fontSize: 11, fontWeight: FontWeight.w600),
                    ),
                  ]),
                  const SizedBox(height: 10),
                  if (widget.allDevices.isEmpty)
                    const Center(child: Padding(padding: EdgeInsets.symmetric(vertical: 16),
                      child: Text('Belum ada device', style: TextStyle(color: _NB.textDim))))
                  else
                    ...widget.allDevices.map((d) {
                      final id = d['id']?.toString() ?? '';
                      final model = d['model']?.toString() ?? 'Unknown';
                      final ip = d['ip']?.toString() ?? '-';
                      final allowed = _devices(_selectedUser).contains(id);
                      return Container(margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: allowed ? _NB.purplePale : _NB.surface,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: allowed ? _NB.purpleMain : _NB.border,
                            width: 2,
                          ),
                          boxShadow: allowed ? const [
                            BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(2, 2)),
                          ] : null,
                        ),
                        child: Row(children: [
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: allowed ? _NB.purplePale : _NB.surface,
                              shape: BoxShape.circle,
                              border: Border.all(color: _NB.border, width: 1.5),
                            ),
                            child: Icon(
                              Icons.phone_android_rounded,
                              color: allowed ? _NB.purpleMain : _NB.textDim,
                              size: 16,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(
                              model,
                              style: TextStyle(
                                color: allowed ? _NB.text : _NB.textSub,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'ID: $id  •  IP: $ip',
                              style: const TextStyle(color: _NB.textDim, fontSize: 10),
                            ),
                          ])),
                          Checkbox(
                            value: allowed,
                            activeColor: _NB.purpleMain,
                            checkColor: _NB.bg,
                            side: const BorderSide(color: _NB.border, width: 2),
                            onChanged: (v) async {
                              final cur = List<String>.from(_devices(_selectedUser));
                              if (v == true) { if (!cur.contains(id)) cur.add(id); }
                              else cur.remove(id);
                              await _update(_selectedUser, devices: cur);
                            },
                          ),
                        ]));
                    }).toList(),
                ])),
            ],
          ],
        ]))),
    ]),
  );
}