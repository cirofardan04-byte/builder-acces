import 'package:flutter/material.dart';
import 'set.dart';

class GlobalTouchWrapper extends StatelessWidget {
  final Widget child;
  const GlobalTouchWrapper({super.key, required this.child});

  void _showTouchEffect(BuildContext context, Offset position) {
    if (!GlobalSettings.isTouchEffectOn.value) return;

    final overlayState = Overlay.of(context);
    late OverlayEntry overlayEntry;

    overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        left: position.dx - 25,
        top: position.dy - 25,
        child: TweenAnimationBuilder<double>(
          tween: Tween(begin: 1.0, end: 0.0),
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeOut,
          builder: (context, opacity, child) {
            return Transform.scale(
              scale: 1.0 + (1.0 - opacity),
              child: Opacity(
                opacity: opacity,
                child: SizedBox(
                  width: 50,
                  height: 50,
                  child: Image.asset(
                    'assets/images/p.png',
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.touch_app, 
                      color: Colors.white54, 
                      size: 30,
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
    overlayState.insert(overlayEntry);
    Future.delayed(const Duration(milliseconds: 600), () => overlayEntry.remove());
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: GlobalSettings.isTouchEffectOn,
      builder: (context, isOn, _) {
        if (!isOn) return child;
        return Listener(
          behavior: HitTestBehavior.translucent,
          onPointerDown: (event) => _showTouchEffect(context, event.position),
          child: child,
        );
      },
    );
  }
}