import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ─── NEUBRUTALISM PALETTE ─────────────────────────────────────
class _NB {
  // Background
  static const bg = Color(0xFFFFFFFF);

  // Surfaces
  static const surface = Color(0xFFF5F3FF);
  static const card = Color(0xFFFAFAFA);

  // Borders
  static const border = Color(0xFF000000);

  // Ungu (solid, not too thick)
  static const purpleMain = Color(0xFF7C3AED);
  static const purpleMid = Color(0xFF8B5CF6);
  static const purpleLight = Color(0xFFA78BFA);
  static const purplePale = Color(0xFFEDE9FE);

  // Pink (solid, not too thick)
  static const pinkMain = Color(0xFFEC4899);
  static const pinkMid = Color(0xFFF472B6);
  static const pinkLight = Color(0xFFF9A8D4);
  static const pinkPale = Color(0xFFFCE7F3);

  // Biru (solid, not too thick)
  static const blueMain = Color(0xFF3B82F6);
  static const blueMid = Color(0xFF60A5FA);
  static const blueLight = Color(0xFF93BBFC);
  static const bluePale = Color(0xFFDBEAFE);

  // Text
  static const text = Color(0xFF1A1A1A);
  static const textSub = Color(0xFF4B4B4B);
  static const textDim = Color(0xFF888888);

  // Status
  static const green = Color(0xFF059669);
  static const red = Color(0xFFDC2626);
  static const orange = Color(0xFFF59E0B);

  // Gradien
  static const LinearGradient purpleGrad = LinearGradient(
    colors: [purpleMain, purpleMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient pinkGrad = LinearGradient(
    colors: [pinkMain, pinkMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient blueGrad = LinearGradient(
    colors: [blueMain, blueMid],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class GlobalChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String androidId;

  const GlobalChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.androidId,
  });

  @override
  State<GlobalChatPage> createState() => _GlobalChatPageState();
}

class _GlobalChatPageState extends State<GlobalChatPage>
    with SingleTickerProviderStateMixin {
  // --- NEUBRUTALISM THEME ---
  static const Color bgMain = _NB.bg;
  static const Color bgSurface = _NB.surface;
  static const Color bgCard = _NB.card;
  static const Color textMain = _NB.text;
  static const Color textSub = _NB.textSub;

  static const Color accent = _NB.purpleMain;
  static const Color borderColor = _NB.border;

  late WebSocketChannel _channel;
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<Map<String, dynamic>> _messages = [];
  bool _isConnected = false;
  bool _isConnecting = true;
  int _onlineCount = 0;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _fadeAnimation =
        CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut);
    _fadeController.forward();
    _connectWebSocket();
  }

  void _connectWebSocket() {
    if (mounted) setState(() { _isConnecting = true; _isConnected = false; });
    try {
      _channel = WebSocketChannel.connect(
        Uri.parse('http://hamapanelbego.duckdns.top:4951'),
      );

      _channel.sink.add(jsonEncode({
        "type": "validate",
        "key": widget.sessionKey,
        "androidId": widget.androidId,
      }));

      _channel.stream.listen(
        (event) {
          if (!mounted) return;
          final data = jsonDecode(event);

          if (data['type'] == 'myInfo') {
            if (data['valid'] == true) {
              _channel.sink.add(jsonEncode({
                "type": "joinChat",
                "room": "global",
                "username": widget.username,
              }));
              _channel.sink.add(jsonEncode({"type": "stats"}));
            } else {
              setState(() { _isConnected = false; _isConnecting = false; });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Sesi tidak valid, silakan login ulang.'),
                  backgroundColor: _NB.red,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(8)),
                    side: BorderSide(color: _NB.border, width: 2),
                  ),
                ),
              );
              Navigator.pop(context);
            }
            return;
          }

          if (data['type'] == 'forceLogout') {
            setState(() { _isConnected = false; _isConnecting = false; });
            Navigator.pop(context);
            return;
          }

          if (data['type'] == 'stats') {
            setState(() => _onlineCount = data['onlineUsers'] ?? 0);
          }

          if (data['type'] == 'chatHistory' && data['room'] == 'global') {
            final history = data['messages'] as List<dynamic>? ?? [];
            setState(() {
              _isConnected = true;
              _isConnecting = false;
              _messages.clear();
              for (final msg in history) {
                _messages.add({
                  'username': msg['username'] ?? 'Unknown',
                  'message': msg['message'] ?? '',
                  'timestamp': msg['timestamp'] ?? '',
                  'isSelf': msg['username'] == widget.username,
                });
              }
            });
            Future.delayed(const Duration(milliseconds: 100), _scrollToBottom);
          }

          if (data['type'] == 'chatMessage' && data['room'] == 'global') {
            setState(() {
              _isConnected = true;
              _isConnecting = false;
              _messages.add({
                'username': data['username'] ?? 'Unknown',
                'message': data['message'] ?? '',
                'timestamp': data['timestamp'] ?? DateTime.now().toIso8601String(),
                'isSelf': data['username'] == widget.username,
              });
            });
            _scrollToBottom();
          }

          if (data['type'] == 'userJoined' && data['room'] == 'global') {
            setState(() {
              _isConnected = true;
              _isConnecting = false;
              _onlineCount = data['onlineInRoom'] ?? _onlineCount;
              _messages.add({
                'username': '',
                'message': '${data['username']} joined the chat',
                'timestamp': DateTime.now().toIso8601String(),
                'isSelf': false,
                'isSystem': true,
              });
            });
            _scrollToBottom();
          }

          if (data['type'] == 'userLeft' && data['room'] == 'global') {
            setState(() {
              _onlineCount = data['onlineInRoom'] ?? _onlineCount;
              _messages.add({
                'username': '',
                'message': '${data['username']} left the chat',
                'timestamp': DateTime.now().toIso8601String(),
                'isSelf': false,
                'isSystem': true,
              });
            });
            _scrollToBottom();
          }
        },
        onError: (_) {
          if (mounted) setState(() { _isConnected = false; _isConnecting = false; });
        },
        onDone: () {
          if (mounted) setState(() { _isConnected = false; _isConnecting = false; });
        },
      );
    } catch (_) {
      if (mounted) setState(() { _isConnected = false; _isConnecting = false; });
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendMessage() {
    final text = _messageController.text.trim();
    if (text.isEmpty || !_isConnected) return;

    _channel.sink.add(jsonEncode({
      "type": "chatMessage",
      "room": "global",
      "username": widget.username,
      "message": text,
    }));

    _messageController.clear();
  }

  void _reconnect() {
    try { _channel.sink.close(status.goingAway); } catch (_) {}
    _connectWebSocket();
  }

  String _formatTime(String timestamp) {
    try {
      final dt = DateTime.parse(timestamp).toLocal();
      final h = dt.hour.toString().padLeft(2, '0');
      final m = dt.minute.toString().padLeft(2, '0');
      return '$h:$m';
    } catch (_) { return ''; }
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _fadeController.dispose();
    try { _channel.sink.close(status.goingAway); } catch (_) {}
    super.dispose();
  }

  // ================================================================
  // BUILD
  // ================================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _NB.bg,
      appBar: _buildAppBar(),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          children: [
            _buildStatusBar(),
            Expanded(child: _buildMessageList()),
            _buildInputArea(),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      automaticallyImplyLeading: true,
      backgroundColor: _NB.card,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _NB.text, size: 20),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: _NB.purplePale,
              shape: BoxShape.circle,
              border: Border.all(color: _NB.border, width: 1.5),
            ),
            child: const Icon(Icons.groups_2_rounded, color: _NB.purpleMain, size: 20),
          ),
          const SizedBox(width: 10),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "GLOBAL CHAT",
                style: TextStyle(
                  color: _NB.text,
                  fontFamily: 'Orbitron',
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
              Text(
                "Pxl Community",
                style: TextStyle(
                  color: _NB.textSub,
                  fontSize: 11,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ],
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(2),
        child: Container(height: 2, color: _NB.border),
      ),
      actions: [
        if (!_isConnected && !_isConnecting)
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: _NB.purpleMain),
            tooltip: 'Reconnect',
            onPressed: _reconnect,
          ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildStatusBar() {
    Color dotColor;
    String label;

    if (_isConnecting) {
      dotColor = _NB.orange;
      label = "Connecting...";
    } else if (_isConnected) {
      dotColor = _NB.green;
      label = "$_onlineCount online";
    } else {
      dotColor = _NB.red;
      label = "Disconnected";
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: _NB.surface,
        border: Border(
          bottom: BorderSide(color: _NB.border.withOpacity(0.3), width: 1.5),
        ),
      ),
      child: Row(
        children: [
          _AnimatedDot(color: dotColor),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(color: _NB.textSub, fontSize: 12, fontFamily: 'ShareTechMono')),
          const Spacer(),
          if (_isConnected)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(
                color: _NB.purplePale,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _NB.border, width: 1.5),
              ),
              child: const Row(
                children: [
                  Icon(Icons.lock_open_rounded, size: 11, color: _NB.purpleMain),
                  SizedBox(width: 4),
                  Text("Public Room", style: TextStyle(color: _NB.purpleMain, fontSize: 10.5, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMessageList() {
    if (_isConnecting) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 40,
              height: 40,
              child: CircularProgressIndicator(
                color: _NB.purpleMain,
                strokeWidth: 3,
              ),
            ),
            SizedBox(height: 16),
            Text("Connecting to Global Chat...", style: TextStyle(color: _NB.textSub, fontFamily: 'ShareTechMono', fontSize: 13)),
          ],
        ),
      );
    }

    if (!_isConnected && _messages.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: _NB.card,
                shape: BoxShape.circle,
                border: Border.all(color: _NB.border, width: 2),
                boxShadow: const [BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(4, 4))],
              ),
              child: const Icon(Icons.wifi_off_rounded, color: _NB.textSub, size: 36),
            ),
            const SizedBox(height: 16),
            const Text("Failed to connect", style: TextStyle(color: _NB.text, fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 6),
            const Text("Tap refresh to try again", style: TextStyle(color: _NB.textSub, fontSize: 13)),
          ],
        ),
      );
    }

    if (_messages.isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.chat_bubble_outline_rounded, color: _NB.purpleLight, size: 48),
            SizedBox(height: 12),
            Text("No messages yet", style: TextStyle(color: _NB.textSub, fontSize: 14)),
            SizedBox(height: 4),
            Text("Be the first to say something!", style: TextStyle(color: _NB.textSub, fontSize: 12)),
          ],
        ),
      );
    }

    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final msg = _messages[index];
        if (msg['isSystem'] == true) return _buildSystemMessage(msg['message']);
        return _buildChatBubble(msg, index);
      },
    );
  }

  Widget _buildSystemMessage(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            color: _NB.purplePale,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: _NB.border, width: 1),
          ),
          child: Text(text, style: const TextStyle(color: _NB.textSub, fontSize: 11.5, fontFamily: 'ShareTechMono')),
        ),
      ),
    );
  }

  Widget _buildChatBubble(Map<String, dynamic> msg, int index) {
    final bool isSelf = msg['isSelf'] == true;
    final String username = msg['username'] ?? '';
    final String message = msg['message'] ?? '';
    final String time = _formatTime(msg['timestamp'] ?? '');

    bool showHeader = true;
    if (!isSelf && index > 0) {
      final prev = _messages[index - 1];
      if (prev['isSystem'] != true && prev['isSelf'] != true && prev['username'] == username) {
        showHeader = false;
      }
    }

    final bubbleColor = isSelf ? _NB.purpleMain : _NB.card;
    final textColor = isSelf ? Colors.white : _NB.text;

    return Padding(
      padding: EdgeInsets.only(top: showHeader ? 10 : 2, bottom: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: isSelf ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isSelf) ...[
            if (showHeader)
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: _NB.purplePale,
                  shape: BoxShape.circle,
                  border: Border.all(color: _NB.border, width: 1.5),
                ),
                child: const Icon(Icons.person_rounded, size: 18, color: _NB.purpleMain),
              )
            else
              const SizedBox(width: 34),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isSelf ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                if (!isSelf && showHeader)
                  Padding(
                    padding: const EdgeInsets.only(left: 4, bottom: 4),
                    child: Text(
                      username,
                      style: const TextStyle(color: _NB.purpleMain, fontWeight: FontWeight.w800, fontSize: 12, fontFamily: 'Orbitron', letterSpacing: 0.3),
                    ),
                  ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.65),
                  decoration: BoxDecoration(
                    color: bubbleColor,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(12),
                      topRight: const Radius.circular(12),
                      bottomLeft: Radius.circular(isSelf ? 12 : 4),
                      bottomRight: Radius.circular(isSelf ? 4 : 12),
                    ),
                    border: Border.all(color: _NB.border, width: 2),
                    boxShadow: const [BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(3, 3))],
                  ),
                  child: Text(message, style: TextStyle(color: textColor, fontSize: 14, height: 1.4)),
                ),
                const SizedBox(height: 3),
                Text(time, style: const TextStyle(color: _NB.textSub, fontSize: 10, fontFamily: 'ShareTechMono')),
              ],
            ),
          ),
          if (isSelf) const SizedBox(width: 4),
        ],
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
      decoration: BoxDecoration(
        color: _NB.card,
        border: Border(
          top: BorderSide(color: _NB.border, width: 2),
        ),
        boxShadow: const [BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(0, -2))],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: _NB.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _NB.border, width: 2),
                  boxShadow: const [BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(2, 2))],
                ),
                child: TextField(
                  controller: _messageController,
                  enabled: _isConnected,
                  maxLines: null,
                  keyboardType: TextInputType.multiline,
                  textInputAction: TextInputAction.newline,
                  style: const TextStyle(color: _NB.text, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: _isConnected ? "Type a message..." : "Not connected",
                    hintStyle: const TextStyle(color: _NB.textSub, fontSize: 14),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  ),
                  onSubmitted: (_) => _sendMessage(),
                ),
              ),
            ),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: _isConnected ? _sendMessage : null,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: _isConnected ? _NB.purpleMain : _NB.textDim,
                  shape: BoxShape.circle,
                  border: Border.all(color: _NB.border, width: 2),
                  boxShadow: _isConnected
                      ? const [BoxShadow(color: _NB.border, blurRadius: 0, offset: Offset(3, 3))]
                      : null,
                ),
                child: Icon(Icons.send_rounded, color: _isConnected ? Colors.white : _NB.card, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// ANIMATED STATUS DOT
// ================================================================

class _AnimatedDot extends StatefulWidget {
  final Color color;
  const _AnimatedDot({required this.color});

  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(duration: const Duration(milliseconds: 900), vsync: this)
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(
          color: widget.color.withOpacity(_anim.value),
          shape: BoxShape.circle,
          border: Border.all(color: _NB.border, width: 1),
          boxShadow: [BoxShadow(color: widget.color.withOpacity(_anim.value * 0.6), blurRadius: 4, spreadRadius: 1)],
        ),
      ),
    );
  }
}
