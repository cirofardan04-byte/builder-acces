import 'dart:ui';
import 'package:flutter/material.dart';
import 'widgets/custom_popup.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';
import 'hentai_page.dart' as hentai;

class HexagonPainter extends CustomPainter {
  final Color color;
  HexagonPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final path = Path();
    final w = size.width;
    final h = size.height;

    path.moveTo(w * 0.5, 0);
    path.lineTo(w, h * 0.25);
    path.lineTo(w, h * 0.75);
    path.lineTo(w * 0.5, h);
    path.lineTo(0, h * 0.75);
    path.lineTo(0, h * 0.25);
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class HexagonWidget extends StatelessWidget {
  final double size;
  final Color color;
  const HexagonWidget({super.key, required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: HexagonPainter(color: color),
      ),
    );
  }
}

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF080808),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // === HEADER ===
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1F080A),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFF7F1D1D), width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFEF4444).withOpacity(0.15),
                          blurRadius: 8,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child: const HexagonWidget(size: 16, color: Color(0xFFEF4444)),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        "TOOLKIT",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2.0,
                        ),
                      ),
                      SizedBox(height: 2),
                      Text(
                        "Cybersecurity & OSINT Suite",
                        style: TextStyle(
                          color: Color(0xFF71717A),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  // Badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1F080A),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF7F1D1D), width: 1),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            color: Color(0xFFEF4444),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          "37 tools",
                          style: TextStyle(
                            color: Color(0xFFFCA5A5),
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // === SEARCH BAR ===
              Container(
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFF18181B),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF27272A), width: 1),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: const [
                    Icon(Icons.search, color: Color(0xFF71717A), size: 18),
                    SizedBox(width: 12),
                    Text(
                      "Search tools...",
                      style: TextStyle(
                        color: Color(0xFF71717A),
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // === GRID OF CATEGORIES ===
              GridView.count(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                crossAxisCount: 2,
                childAspectRatio: 0.82,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: [
                  // 1. DDoS Tools
                  _buildCategoryCard(
                    context: context,
                    title: "DDoS Tools",
                    subtitle: "Attack & Server",
                    icon: Icons.bolt,
                    themeColor: const Color(0xFFEF4444),
                    bgColor: const Color(0xFF181111),
                    borderColor: const Color(0xFF2D1515),
                    count: 2,
                    tools: [
                      _buildToolItem(
                        context: context,
                        icon: Icons.flash_on,
                        label: "Attack Panel",
                        themeColor: const Color(0xFFEF4444),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => AttackPanel(
                                sessionKey: sessionKey,
                                listDoos: listDoos,
                              ),
                            ),
                          );
                        },
                      ),
                      _buildToolItem(
                        context: context,
                        icon: Icons.dns,
                        label: "Manage Server",
                        themeColor: const Color(0xFFEF4444),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ManageServerPage(keyToken: sessionKey),
                            ),
                          );
                        },
                      ),
                    ],
                  ),

                  // 2. Network
                  _buildCategoryCard(
                    context: context,
                    title: "Network",
                    subtitle: "WiFi & Spam",
                    icon: Icons.settings_input_antenna,
                    themeColor: const Color(0xFFF97316),
                    bgColor: const Color(0xFF1A1411),
                    borderColor: const Color(0xFF2D1B15),
                    count: 3,
                    tools: [
                      _buildToolItem(
                        context: context,
                        icon: Icons.newspaper_outlined,
                        label: "Spam NGL",
                        themeColor: const Color(0xFFF97316),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => NglPage()));
                        },
                      ),
                      _buildToolItem(
                        context: context,
                        icon: Icons.wifi_off,
                        label: "WiFi Killer (Internal)",
                        themeColor: const Color(0xFFF97316),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => WifiKillerPage()));
                        },
                      ),
                      if (userRole == "vip" || userRole == "owner")
                        _buildToolItem(
                          context: context,
                          icon: Icons.router,
                          label: "WiFi Killer (External)",
                          themeColor: const Color(0xFFF97316),
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: sessionKey)));
                          },
                        ),
                    ],
                  ),

                  // 3. OSINT
                  _buildCategoryCard(
                    context: context,
                    title: "OSINT",
                    subtitle: "Investigation",
                    icon: Icons.alternate_email,
                    themeColor: const Color(0xFF06B6D4),
                    bgColor: const Color(0xFF11181A),
                    borderColor: const Color(0xFF15282D),
                    count: 5,
                    tools: [
                      _buildToolItem(
                        context: context,
                        icon: Icons.badge,
                        label: "NIK Detail",
                        themeColor: const Color(0xFF06B6D4),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
                        },
                      ),
                      _buildToolItem(
                        context: context,
                        icon: Icons.domain,
                        label: "Domain OSINT",
                        themeColor: const Color(0xFF06B6D4),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
                        },
                      ),
                      _buildToolItem(
                        context: context,
                        icon: Icons.person_search,
                        label: "Phone Lookup",
                        themeColor: const Color(0xFF06B6D4),
                        onTap: () => _showComingSoon(context),
                      ),
                      _buildToolItem(
                        context: context,
                        icon: Icons.email,
                        label: "Email OSINT",
                        themeColor: const Color(0xFF06B6D4),
                        onTap: () => _showComingSoon(context),
                      ),
                    ],
                  ),

                  // 4. Downloader
                  _buildCategoryCard(
                    context: context,
                    title: "Downloader",
                    subtitle: "Social Media",
                    icon: Icons.cloud_download,
                    themeColor: const Color(0xFFD946EF),
                    bgColor: const Color(0xFF18111A),
                    borderColor: const Color(0xFF28152D),
                    count: 2,
                    tools: [
                      _buildToolItem(
                        context: context,
                        icon: Icons.video_library,
                        label: "TikTok Downloader",
                        themeColor: const Color(0xFFD946EF),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
                        },
                      ),
                      _buildToolItem(
                        context: context,
                        icon: Icons.camera_alt,
                        label: "Instagram Downloader",
                        themeColor: const Color(0xFFD946EF),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
                        },
                      ),
                    ],
                  ),

                  // 5. Utilities
                  _buildCategoryCard(
                    context: context,
                    title: "Utilities",
                    subtitle: "Extra Tools",
                    icon: Icons.construction,
                    themeColor: const Color(0xFF22C55E),
                    bgColor: const Color(0xFF111A13),
                    borderColor: const Color(0xFF152D1B),
                    count: 5,
                    tools: [
                      _buildToolItem(
                        context: context,
                        icon: Icons.qr_code,
                        label: "QR Generator",
                        themeColor: const Color(0xFF22C55E),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
                        },
                      ),
                      _buildToolItem(
                        context: context,
                        icon: Icons.security,
                        label: "IP Scanner",
                        themeColor: const Color(0xFF22C55E),
                        onTap: () => _showComingSoon(context),
                      ),
                      _buildToolItem(
                        context: context,
                        icon: Icons.network_check,
                        label: "Port Scanner",
                        themeColor: const Color(0xFF22C55E),
                        onTap: () => _showComingSoon(context),
                      ),
                    ],
                  ),

                  // 6. Security
                  _buildCategoryCard(
                    context: context,
                    title: "Security",
                    subtitle: "Breach & Scan",
                    icon: Icons.shield,
                    themeColor: const Color(0xFFEAB308),
                    bgColor: const Color(0xFF1A1911),
                    borderColor: const Color(0xFF2D2A15),
                    count: 7,
                    tools: [
                      _buildToolItem(
                        context: context,
                        icon: Icons.live_tv,
                        label: "Anime Streaming",
                        themeColor: const Color(0xFFEAB308),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeAnimePage()));
                        },
                      ),
                      _buildToolItem(
                        context: context,
                        icon: Icons.local_fire_department,
                        label: "Hentai Media",
                        themeColor: const Color(0xFFEAB308),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const hentai.HomeScreen()));
                        },
                      ),
                    ],
                  ),

                  // 7. Games
                  _buildCategoryCard(
                    context: context,
                    title: "Games",
                    subtitle: "Entertainment",
                    icon: Icons.videogame_asset,
                    themeColor: const Color(0xFF8B5CF6),
                    bgColor: const Color(0xFF14111A),
                    borderColor: const Color(0xFF20152D),
                    count: 2,
                    tools: [
                      _buildToolItem(
                        context: context,
                        icon: Icons.star_border,
                        label: "Add Quick Access",
                        themeColor: const Color(0xFF8B5CF6),
                        onTap: () => _showComingSoon(context),
                      ),
                    ],
                  ),

                  // 8. Converter
                  _buildCategoryCard(
                    context: context,
                    title: "Converter",
                    subtitle: "Data Formats",
                    icon: Icons.swap_horiz,
                    themeColor: const Color(0xFF3B82F6),
                    bgColor: const Color(0xFF11141A),
                    borderColor: const Color(0xFF151E2D),
                    count: 8,
                    tools: [
                      _buildToolItem(
                        context: context,
                        icon: Icons.swap_horiz,
                        label: "Format Converter",
                        themeColor: const Color(0xFF3B82F6),
                        onTap: () => _showComingSoon(context),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomBar(),
    );
  }

  Widget _buildCategoryCard({
    required BuildContext context,
    required String title,
    required String subtitle,
    required IconData icon,
    required Color themeColor,
    required Color bgColor,
    required Color borderColor,
    required int count,
    required List<Widget> tools,
  }) {
    return GestureDetector(
      onTap: () => _showToolsDialog(context, title, subtitle, icon, themeColor, tools),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderColor, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: themeColor.withOpacity(0.03),
              blurRadius: 10,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Top Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Icon Container
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: themeColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: themeColor.withOpacity(0.2), width: 1),
                  ),
                  child: Icon(icon, color: themeColor, size: 18),
                ),
                // Count Badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: themeColor.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: themeColor.withOpacity(0.2), width: 1),
                  ),
                  child: Text(
                    '$count',
                    style: TextStyle(
                      color: themeColor,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Bottom Section
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.4),
                    fontSize: 10,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Horizontal bar indicator
                    Container(
                      width: 28,
                      height: 3,
                      decoration: BoxDecoration(
                        color: themeColor,
                        borderRadius: BorderRadius.circular(1.5),
                      ),
                    ),
                    // Arrow
                    Icon(
                      Icons.arrow_forward,
                      color: themeColor.withOpacity(0.6),
                      size: 14,
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showToolsDialog(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon,
    Color themeColor,
    List<Widget> tools,
  ) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (BuildContext ctx) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
          child: Dialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF0D0D0E),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: themeColor.withOpacity(0.3), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: themeColor.withOpacity(0.1),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: themeColor.withOpacity(0.1),
                      shape: BoxShape.circle,
                      border: Border.all(color: themeColor.withOpacity(0.3)),
                    ),
                    child: Icon(icon, color: themeColor, size: 28),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 20),
                  ConstrainedBox(
                    constraints: BoxConstraints(
                      maxHeight: MediaQuery.of(context).size.height * 0.4,
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: tools,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildToolItem({
    required BuildContext context,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required Color themeColor,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF151518),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: themeColor.withOpacity(0.15)),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            Navigator.pop(context); // Close dialog first
            onTap();
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              children: [
                Icon(icon, color: themeColor, size: 18),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Icon(Icons.arrow_forward_ios, color: themeColor.withOpacity(0.5), size: 12),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      height: 72,
      decoration: const BoxDecoration(
        color: Color(0xFF09090B),
        border: Border(
          top: BorderSide(color: Color(0xFF18181B), width: 1.5),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Icon(Icons.home_filled, color: Color(0xFF52525B), size: 22),
          const Icon(Icons.phone_android, color: Color(0xFF52525B), size: 22),
          const Icon(Icons.chat_bubble_outline, color: Color(0xFF52525B), size: 22),
          const Icon(Icons.notifications_none, color: Color(0xFF52525B), size: 22),
          // TOOLS Button
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF3F1618),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF7F1D1D), width: 1.5),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.construction, color: Colors.white, size: 16),
                SizedBox(width: 8),
                Text(
                  "TOOLS",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    CustomPopup.show(
      context,
      title: "Coming Soon",
      message: "Fitur ini masih dalam tahap pengembangan.",
      icon: Icons.info_outline,
    );
  }
}